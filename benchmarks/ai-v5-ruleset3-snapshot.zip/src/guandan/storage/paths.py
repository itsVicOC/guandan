"""路径管理：获取存储目录和文件路径。

存储结构：
~/.guandan/
├── profile.json      # 用户配置和统计
├── savegame.json     # 当前未完成的对局（单个）
└── history/          # 历史对局记录（多个）
    ├── 2026-06-05_143521_game001.json
    └── ...
"""
from __future__ import annotations

import os
import re
from pathlib import Path

_GAME_ID_PATTERN = re.compile(r"^[A-Za-z0-9][A-Za-z0-9_-]{0,127}$")


def validate_game_id(game_id: object) -> str:
    """Return a filesystem-safe game identifier or reject it."""
    if not isinstance(game_id, str) or _GAME_ID_PATTERN.fullmatch(game_id) is None:
        raise ValueError("game_id must use 1-128 ASCII letters, digits, underscores or hyphens")
    return game_id


def get_storage_dir() -> Path:
    """获取存储目录 ~/.guandan/

    目录不存在时自动创建。

    Returns:
        存储目录路径
    """
    configured = os.environ.get("GUANDAN_DATA_DIR")
    storage_dir = Path(configured).expanduser() if configured else Path.home() / ".guandan"
    storage_dir.mkdir(parents=True, exist_ok=True)
    return storage_dir


def get_profile_path() -> Path:
    """获取用户配置文件路径 ~/.guandan/profile.json

    Returns:
        配置文件路径
    """
    return get_storage_dir() / "profile.json"


def get_savegame_path() -> Path:
    """获取存档文件路径 ~/.guandan/savegame.json

    Returns:
        存档文件路径
    """
    return get_storage_dir() / "savegame.json"


def get_history_dir() -> Path:
    """获取历史记录目录 ~/.guandan/history/

    目录不存在时自动创建。

    Returns:
        历史记录目录路径
    """
    history_dir = get_storage_dir() / "history"
    history_dir.mkdir(parents=True, exist_ok=True)
    return history_dir


__all__ = [
    "get_history_dir",
    "get_profile_path",
    "get_savegame_path",
    "get_storage_dir",
    "validate_game_id",
]
