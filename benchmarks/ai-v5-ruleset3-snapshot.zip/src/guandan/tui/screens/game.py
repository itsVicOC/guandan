"""牌桌屏（M1 核心，M2 接入 AI 包，M5 存储集成，M6 TUI 优化）。"""
from __future__ import annotations

from typing import List, Optional, Sequence

from rich.cells import cell_len
from rich.markup import escape
from rich.text import Text
from textual import work
from textual.app import ComposeResult
from textual.binding import Binding
from textual.containers import Grid, Horizontal, Vertical
from textual.screen import Screen
from textual.timer import Timer
from textual.widgets import Button, Footer, Header, Static

from ...engine.card import RANK_A, Card, Suit
from ...engine.events import (
    Pass,
    TurnPlayed,
)
from ...engine.hand import Pattern, PatternType, comparison_rank, sort_cards
from ...engine.rules.tributes import apply_tribute_flow
from ...engine.state import (
    SEAT_NAMES,
    GameState,
)
from ...engine.trick import (
    current_trick_actions,
)
from ...storage.savegame import SaveConflictError
from ...ui.background import TurnResult, run_turn
from ...ui.hand_organizer import HandOrganizer, remap_selected_indices
from ...ui.session import GameSession, card_indices_for_selection
from ..layout import RECOMMENDED_COLUMNS


class OpponentWidget(Static):
    """显示对手一方的信息：名字 + 剩余张数 + AI 等级。"""

    DEFAULT_CSS = """
    OpponentWidget {
        width: 1fr;
        height: 4;
        content-align: center middle;
        border: round #60765f;
        background: #111815;
        color: #eee8d9;
        padding: 0 1;
    }
    """

    def __init__(self, player: int, seat_name: str, ai_label: str, **kwargs) -> None:
        super().__init__("[X] AI\n27 张", **kwargs)
        self._player = player
        self._seat_name = seat_name
        self._ai_label = ai_label
        self._hand_size = 27
        self._finished = False
        self._is_turn = False

    def on_mount(self) -> None:
        self._do_render()

    def update_state(
        self, hand_size: int, finished: bool, is_turn: bool
    ) -> None:
        self._hand_size = hand_size
        self._finished = finished
        self._is_turn = is_turn
        self._do_render()

    def _do_render(self) -> None:
        marker = " [bold #ffd978]行动中[/bold #ffd978]" if self._is_turn else ""
        done = "[green]已出完[/green]" if self._finished else f"{self._hand_size:2d} 张"
        claim = _claim_badge(self._hand_size) if not self._finished else ""
        text = (
            f"[bold #ffd978]{self._seat_name}家[/bold #ffd978] "
            f"[dim]{self._ai_label}[/dim]{marker}\n"
            f"{done}{claim}"
        )
        self.update(text)


def _tui_card(card: Card, *, selected: bool = False, cursor: bool = False, wild: bool = False) -> str:
    """终端专用牌面：用中文花色、符号和固定底色降低对终端配色的依赖。"""
    if card.is_big_joker:
        body = "大王"
        style = "bold #101010 on #ffd84d"
    elif card.is_small_joker:
        body = "小王"
        style = "bold #101010 on #ffd84d"
    else:
        suit_meta = {
            Suit.HEARTS: ("红", "♥", "bold #fff4f4 on #7a1f1f"),
            Suit.DIAMONDS: ("方", "♦", "bold #fff4ff on #733078"),
            Suit.SPADES: ("黑", "♠", "bold #101010 on #e5e5e5"),
            Suit.CLUBS: ("梅", "♣", "bold #10201c on #65d4bf"),
        }[card.suit]
        suit_text, suit_symbol, style = suit_meta
        body = f"{suit_text}{_rank_label(card)}{suit_symbol}"

    label = f"{body}配" if wild else body

    if selected and cursor:
        return _styled_card("bold #101010 on #ffd84d", f"▶{label}✓")
    if selected:
        return _styled_card("bold #101010 on #ffd84d", f"✓{label}✓")
    if cursor:
        return _styled_card("bold #ffffff on #2457d6", f"▶{label}◀")
    if wild:
        return _styled_card("bold #101010 on #75d575", f"★{label}")
    return _styled_card(style, f" {label} ")


def _styled_card(style: str, text: str) -> str:
    return f"[{style}]{escape(text)}[/]"


def _rank_label(card: Card) -> str:
    if card.rank == 14:
        return "A"
    if card.rank == 13:
        return "K"
    if card.rank == 12:
        return "Q"
    if card.rank == 11:
        return "J"
    return str(card.rank)


def _rank_value_label(rank: int) -> str:
    if rank == 101:
        return "大王"
    if rank == 100:
        return "小王"
    if rank == 14:
        return "A"
    if rank == 13:
        return "K"
    if rank == 12:
        return "Q"
    if rank == 11:
        return "J"
    return str(rank)


def _claim_badge(hand_size: int) -> str:
    if hand_size == 1:
        label = "报单"
    elif hand_size == 2:
        label = "报双"
    elif 0 < hand_size <= 10:
        label = f"报{hand_size}张"
    else:
        return ""
    return f"  [bold #ffe89a on #604814] {label} [/bold #ffe89a on #604814]"


def _pattern_type_label(pattern_type: PatternType) -> str:
    return {
        PatternType.SINGLE: "单张",
        PatternType.PAIR: "对子",
        PatternType.TRIPLE: "三张",
        PatternType.TRIPLE_PAIR: "三带二",
        PatternType.STRAIGHT: "顺子",
        PatternType.PAIR_SEQUENCE: "连对",
        PatternType.TRIPLE_SEQUENCE: "钢板",
        PatternType.BOMB: "炸弹",
        PatternType.STRAIGHT_FLUSH: "同花顺",
        PatternType.FOUR_JOKERS: "四王炸",
    }[pattern_type]


def _cards_text(cards: Sequence[Card]) -> str:
    return " ".join(card.compact for card in cards)


def _pattern_summary(pattern: Pattern, level: int) -> str:
    base_rank = _rank_value_label(pattern.rank)
    effective = comparison_rank(pattern, level)
    rank_text = f"{base_rank}(级牌)" if effective != pattern.rank else base_rank
    return (
        f"{_pattern_type_label(pattern.type)}"
        f" · 主牌 {rank_text}"
        f" · 张数 {len(pattern.cards)}"
        f" · [{_cards_text(pattern.cards)}]"
    )


def _play_rejection_message(selected: list[Card], pattern: Pattern, table_top: Pattern, level: int) -> str:
    return (
        "不能压过桌面："
        f"你选 [{_cards_text(selected)}]，识别为 {_pattern_summary(pattern, level)}；"
        f"桌面最大为 {_pattern_summary(table_top, level)}；"
        f"当前级牌 {_rank_value_label(level)} 会参与单/对/三/三带二/炸弹点数比较"
    )


def _wild_card_from_hands(level: int, hands: list[list[Card]]) -> Optional[Card]:
    for hand in hands:
        for card in hand:
            if card.rank == level and card.suit == Suit.HEARTS:
                return card
    return None


class PlayerStatusWidget(Static):
    """显示玩家自己的状态。"""

    DEFAULT_CSS = """
    PlayerStatusWidget {
        width: 1fr;
        height: 4;
        content-align: center middle;
        border: round #d6b35a;
        background: #18211d;
        color: #eee8d9;
        padding: 0 1;
    }
    """

    def update_state(self, seat_name: str, hand_size: int, is_turn: bool) -> None:
        marker = " [bold #ffd978]行动中[/bold #ffd978]" if is_turn else ""
        self.update(
            f"[bold #ffd978]{seat_name}家[/bold #ffd978] [dim]你[/dim]{marker}\n"
            f"{hand_size:2d} 张{_claim_badge(hand_size)}"
        )


class TableWidget(Static):
    """中央出牌区。"""

    DEFAULT_CSS = """
    TableWidget {
        height: 12;
        border: round #d6b35a;
        padding: 1 2;
        background: #121a17;
        color: #eee8d9;
    }
    """

    def __init__(self, **kwargs) -> None:
        super().__init__("（空）", **kwargs)
        self._table_patterns: List[Pattern] = []
        self._players: List[int] = []
        self._passed: List[int] = []  # 对当前桌顶已过牌的玩家
        self._seat_actions: dict[int, tuple[str, Pattern | None]] = {}
        self._tribute_notice = ""

    def on_mount(self) -> None:
        self._do_render()

    def update_table(
        self,
        patterns: List[Pattern],
        players: List[int],
        passed: Optional[List[int]] = None,
        seat_actions: Optional[dict[int, tuple[str, Pattern | None]]] = None,
        tribute_notice: str = "",
    ) -> None:
        self._table_patterns = patterns
        self._players = players
        self._passed = passed if passed is not None else []
        self._seat_actions = dict(seat_actions or {})
        self._tribute_notice = tribute_notice
        self._do_render()

    def _pattern_str(self, p: Pattern) -> str:
        if p.type == PatternType.SINGLE:
            return _tui_card(p.cards[0])
        if p.type == PatternType.PAIR:
            return f"对{_tui_card(p.cards[0])}"
        cards_str = " ".join(_tui_card(c) for c in p.cards)
        return f"{_pattern_type_label(p.type)}  {cards_str}"

    def _do_render(self) -> None:
        top_player = self._players[-1] if self._table_patterns and self._players else None
        title = "[bold #d6b35a]当前轮[/bold #d6b35a]"
        if top_player is not None:
            title += f" · [bold]最大 {SEAT_NAMES[top_player]}家[/bold]"
        lines = [title]
        if self._tribute_notice:
            lines.append(f"[bold #f6d779]{escape(self._tribute_notice)}[/bold #f6d779]")
        if not self._table_patterns and not self._passed and not self._seat_actions:
            lines.extend(("", "[dim]桌面空，等待先手出牌[/dim]"))
            self.update("\n".join(lines))
            return

        actions = dict(self._seat_actions)
        if not actions:
            actions.update({player: ("pass", None) for player in self._passed})
            actions.update(
                {player: ("play", pattern) for player, pattern in zip(self._players, self._table_patterns)}
            )

        for who in (0, 3, 2, 1):
            action = actions.get(who)
            seat = f"[#9fb7a6]{SEAT_NAMES[who]}:[/#9fb7a6]"
            marker = " [bold #ffd978]最大[/bold #ffd978]" if who == top_player else ""
            if action is None:
                lines.append(f"  {seat}{marker} [dim]--[/dim]")
                continue
            kind, pattern = action
            if kind == "pass":
                lines.append(f"  {seat}{marker} [dim]过牌[/dim]")
            elif pattern is not None:
                lines.append(f"  {seat}{marker} {self._pattern_str(pattern)}")
            else:
                lines.append(f"  {seat}{marker} [dim]--[/dim]")
        self.update("\n".join(lines))


class HandWidget(Static):
    """占位：玩家手牌。所有交互状态由 GameScreen 持有。"""

    pass


class GameScreen(Screen):
    """牌桌屏。"""

    DEFAULT_CSS = """
    GameScreen {
        background: #101512;
        color: #eee8d9;
    }

    #game-shell {
        width: 100%;
        height: 1fr;
        padding: 0 1;
        background: #101512;
    }

    #table-layout {
        height: auto;
        grid-size: 3 3;
        grid-columns: 1fr 2fr 1fr;
        grid-rows: 4 12 4;
        grid-gutter: 1 1;
        padding: 1 0;
    }
    #opp-opposite {
        column-span: 3;
    }
    #status-bar {
        height: 4;
        padding: 0 2;
        border: round #60765f;
        background: #18211d;
        color: #cdd7c8;
    }
    #my-hand {
        min-height: 9;
        padding: 1 2;
        border: round #d6b35a;
        background: #0d1412;
        color: #eee8d9;
    }
    #round-actions {
        height: 3;
        align: center middle;
        padding: 0 2;
        background: #101512;
    }
    #btn-next-game {
        width: 22;
        margin-right: 1;
    }
    #btn-organize-hand {
        width: 16;
        margin-right: 1;
    }
    #btn-lock-hand {
        width: 16;
        margin-right: 1;
    }
    #btn-game-back {
        width: 16;
    }
    #action-log {
        height: 4;
        padding: 0 2;
        border: tall #344237;
        background: #121a17;
        color: #9fb7a6;
    }
    """

    BINDINGS = [
        Binding("left", "cursor_left", "←", priority=True),
        Binding("right", "cursor_right", "→", priority=True),
        Binding("up", "cursor_left", "←", priority=True),
        Binding("down", "cursor_right", "→", priority=True),
        Binding("space", "toggle_select", "选牌", priority=True),
        Binding("enter", "play", "出牌", priority=True),
        Binding("p", "pass", "过牌", priority=True),
        Binding("t", "hint", "提示", priority=True),
        Binding("s", "organize_hand", "理牌", priority=True),
        Binding("shift+s", "reset_organize", "默认", priority=True),
        Binding("g", "select_group", "整组", priority=True),
        Binding("k", "toggle_lock", "锁牌", priority=True),
        Binding("n", "next_game", "下一局", priority=True),
        Binding("r", "retry_background", "重试", priority=True),
        ("?", "rules", "规则"),
        ("escape", "back", "返回"),
    ]

    def __init__(
        self,
        *args,
        session: GameSession | None = None,
        difficulty: int = 2,
        level: int = 2,
        human: int = 0,
        existing_state: Optional[GameState] = None,
        game_id: Optional[str] = None,
        match_id: Optional[str] = None,
        round_index: int = 1,
        elapsed_seconds: int = 0,
        seed: Optional[int] = None,
        **kwargs,
    ) -> None:
        super().__init__(*args, **kwargs)
        self.session = session or GameSession(
            difficulty=difficulty,
            level=level,
            human=human,
            existing_state=existing_state,
            game_id=game_id,
            match_id=match_id,
            round_index=round_index,
            elapsed_seconds=elapsed_seconds,
            seed=seed,
        )
        self.message = ""
        # 交互状态（不放在 widget 上以避免 textual 命名冲突）
        self._hand_cards: List[Card] = []
        self._hand_selected_indices: set[int] = set()
        self._hand_cursor = 0
        self._hand_group_starts: frozenset[int] = frozenset()
        self._hand_organizer = HandOrganizer()
        self._ai_running = False
        self._saving = False
        self._leave_requested = False
        self._quit_after_save = False
        self._failed_turn: TurnResult | None = None
        self._tribute_timer: Timer | None = None

    @property
    def difficulty(self) -> int:
        return self.session.difficulty

    @property
    def level(self) -> int:
        return self.session.level

    @property
    def human(self) -> int:
        return self.session.human

    @property
    def state(self) -> Optional[GameState]:
        return self.session.state

    @state.setter
    def state(self, value: Optional[GameState]) -> None:
        self.session.state = value

    @property
    def _strategy(self):
        return self.session.strategy

    @property
    def _ai_rng(self):
        return self.session.ai_rng

    @_ai_rng.setter
    def _ai_rng(self, value) -> None:
        self.session.ai_rng = value

    @property
    def _last_action(self) -> str:
        return self.session.last_action

    @_last_action.setter
    def _last_action(self, value: str) -> None:
        self.session.last_action = value

    @property
    def _game_saved(self) -> bool:
        return self.session.game_saved

    @_game_saved.setter
    def _game_saved(self, value: bool) -> None:
        self.session.game_saved = value

    @property
    def _displayed_table_actions(self) -> dict[int, tuple[str, Pattern | None]]:
        return self.session.displayed_table_actions

    @_displayed_table_actions.setter
    def _displayed_table_actions(self, value: dict[int, tuple[str, Pattern | None]]) -> None:
        self.session.displayed_table_actions = value

    @property
    def _last_display_turn(self) -> Optional[int]:
        return self.session.last_display_turn

    @_last_display_turn.setter
    def _last_display_turn(self, value: Optional[int]) -> None:
        self.session.last_display_turn = value

    def compose(self) -> ComposeResult:
        ai_label = f"AI·{self._strategy.name}"
        seats = self._visual_seats()
        yield Header()
        with Vertical(id="game-shell"):
            yield Static("status", id="status-bar")
            with Grid(id="table-layout"):
                yield OpponentWidget(seats["opposite"], SEAT_NAMES[seats["opposite"]], ai_label, id="opp-opposite")
                yield OpponentWidget(seats["left"], SEAT_NAMES[seats["left"]], ai_label, id="opp-left")
                yield TableWidget(id="table")
                yield OpponentWidget(seats["right"], SEAT_NAMES[seats["right"]], ai_label, id="opp-right")
                yield Static("")
                yield PlayerStatusWidget("", id="player-south")
                yield Static("")
            yield Static("hand", id="my-hand")
            with Horizontal(id="round-actions"):
                yield Button("S  智能理牌", id="btn-organize-hand", disabled=True)
                yield Button("K  锁定牌型", id="btn-lock-hand", disabled=True)
                yield Button("N  下一局", id="btn-next-game", variant="success", disabled=True)
                yield Button("返回大厅", id="btn-game-back", variant="default")
            yield Static("ready", id="action-log")
        yield Footer()

    def on_mount(self) -> None:
        self.session.ensure_started()
        self._refresh_all()
        if self.session.is_next_game_pending():
            self._tribute_timer = self.set_timer(0.3, self._begin_next_game_tribute)
        else:
            self.set_timer(0.3, self._maybe_ai_turn)

    def _state(self) -> GameState:
        return self.session.display_state()

    def _visual_seats(self) -> dict[str, int]:
        """返回以当前玩家为底部视角的左右和对面座位。"""
        return self.session.visual_seats()

    def _refresh_all(self) -> None:
        s = self._state()
        tribute_pending = self.session.is_next_game_pending()
        seats = self._visual_seats()
        for p, wid in [
            (seats["left"], "opp-left"),
            (seats["opposite"], "opp-opposite"),
            (seats["right"], "opp-right"),
        ]:
            w = self.query_one(f"#{wid}", OpponentWidget)
            w.update_state(
                hand_size=len(s.hands[p]),
                finished=p in s.finish_order,
                is_turn=not tribute_pending and s.turn_index == p,
            )
        self.query_one("#player-south", PlayerStatusWidget).update_state(
            SEAT_NAMES[self.human],
            len(s.hands[self.human]),
            not tribute_pending and s.turn_index == self.human,
        )
        # 更新玩家手牌（在自己管理的状态 + 外部渲染）
        previous_cards = tuple(self._hand_cards)
        previous_indices = set(self._hand_selected_indices)
        cursor_card = (
            self._hand_cards[self._hand_cursor]
            if self._hand_cursor < len(self._hand_cards) else None
        )
        cursor_occurrence = (
            self._hand_cards[:self._hand_cursor + 1].count(cursor_card) - 1
            if cursor_card is not None else 0
        )
        base_cards = sort_cards(s.hands[self.human])
        self._hand_organizer.sync(
            base_cards, s.wild_card, s.level, hand_id=self.session.game_id
        )
        arranged = not tribute_pending and not s.finished
        self._hand_cards = list(self._hand_organizer.cards) if arranged else base_cards
        self._hand_group_starts = (
            self._hand_organizer.group_starts if arranged else frozenset()
        )
        self._hand_selected_indices = remap_selected_indices(
            previous_cards, previous_indices, self._hand_cards
        )
        if cursor_card in self._hand_cards:
            matching = [
                index for index, card in enumerate(self._hand_cards) if card == cursor_card
            ]
            self._hand_cursor = matching[min(cursor_occurrence, len(matching) - 1)]
        else:
            self._hand_cursor = min(self._hand_cursor, max(0, len(self._hand_cards) - 1))
        self._do_render_hand()
        tbl = self.query_one("#table", TableWidget)
        # 提取对当前桌顶已过牌的玩家
        table_players = self._current_table_players()
        passed_players = self._locked_passed_players()
        seat_actions = self._table_display_actions(table_players, passed_players)
        tbl.update_table(
            s.table,
            table_players,
            passed=passed_players,
            seat_actions=seat_actions,
            tribute_notice=self.session.tribute_notice(),
        )
        # 状态信息写入 screen title
        turn_name = SEAT_NAMES[s.turn_index]
        if self.session.is_next_game_pending():
            choice = self.session.pending_next_game_choice()
            if choice is None:
                self.sub_title = "新局手牌已发放 · 即将开始贡还牌"
            else:
                verb = "进贡" if choice.kind == "tribute" else "还贡"
                self.sub_title = f"贡还牌阶段 · 请选择{verb}牌"
        elif s.finished:
            order_str = " > ".join(SEAT_NAMES[p] for p in s.finish_order)
            if s.match_finished and s.winner_team is not None:
                winner = "东西" if s.winner_team == 0 else "南北"
                self.sub_title = (
                    f"比赛结束！本局级牌 {_rank_value_label(s.level)} · "
                    f"{winner}方获胜 · 名次：{order_str}"
                )
            else:
                next_level = self._next_round_level(s)
                a_notice = ""
                if s.ruleset_version >= 3:
                    final_levels = s.team_levels_final or s.team_levels
                    for team, name in enumerate(("东西", "南北")):
                        if s.team_levels[team] == RANK_A:
                            failures = s.a_failure_counts[team] if final_levels[team] == RANK_A else 3
                            a_notice += f" · {name}队未过 A {failures}/3"
                self.sub_title = (
                    f"本局结束！本局级牌 {_rank_value_label(s.level)} · 名次：{order_str} · "
                    f"下一局级牌 {_rank_value_label(next_level)}{a_notice} · 按 N 继续"
                )
        elif s.turn_index == self.human:
            hand_size = len(s.hands[self.human])
            self.sub_title = f"轮到你（{turn_name}）· {hand_size} 张"
        else:
            self.sub_title = f"等待 {turn_name} 出牌中..."
        self._render_status()
        self._refresh_round_actions()
        self.query_one("#action-log", Static).update(self._last_action)

    def _render_status(self) -> None:
        s = self._state()
        wild = _tui_card(s.wild_card, wild=True) if s.wild_card is not None else "无"
        leader = (
            SEAT_NAMES[s.leader]
            if not self.session.is_next_game_pending() and s.leader is not None
            else "-"
        )
        table_players = self._current_table_players()
        top_player = SEAT_NAMES[table_players[-1]] if s.table and table_players else "-"
        finished = " > ".join(SEAT_NAMES[p] for p in s.finish_order) or "-"
        levels = self._visible_team_levels(s)
        if self.session.is_next_game_pending():
            current = "贡还牌阶段"
        elif s.finished:
            current = "比赛结束" if s.match_finished else "本局结束"
        else:
            current = f"{SEAT_NAMES[s.turn_index]}家"
        round_index = self.session.round_index + int(self.session.is_next_game_pending())
        if self.session.is_next_game_pending():
            phase = "发牌中"
        elif s.finished:
            phase = "比赛结束" if s.match_finished else "本局结束"
        elif any(isinstance(event, (TurnPlayed, Pass)) for event in s.history):
            phase = "进行中"
        else:
            phase = "本局开始"
        text = (
            f"[bold #ffd978]第 {round_index} 局 · {phase} · 本局级牌 "
            f"{_rank_value_label(s.level)}[/bold #ffd978]   "
            f"[bold #ffd978]逢人配[/bold #ffd978] {wild}   "
            f"[bold #ffd978]当前[/bold #ffd978] {current}   "
            f"[bold #ffd978]AI[/bold #ffd978] {self._strategy.name}\n"
            f"先手 {leader}家 · 最大 {top_player}家 · 队伍级数 东西:{levels[0]} 南北:{levels[1]} · 名次 {finished}"
        )
        if s.finished:
            if s.match_finished and s.winner_team is not None:
                winner = "东西" if s.winner_team == 0 else "南北"
                text += f" · 比赛结束：{winner}方获胜"
            else:
                text += f" · 下一局级牌 {_rank_value_label(self._next_round_level(s))}"
        self.query_one("#status-bar", Static).update(text)

    def _do_render_hand(self) -> None:
        if not self._hand_cards:
            partner_cards = self.session.visible_partner_hand()
            if partner_cards:
                cards = sort_cards(partner_cards)
                max_width = self._hand_row_width()
                partner_rows: list[str] = []
                partner_row: list[str] = []
                row_width = 0
                for card in cards:
                    part = _tui_card(card, wild=card == self._state().wild_card)
                    width = cell_len(Text.from_markup(part).plain)
                    if partner_row and row_width + 1 + width > max_width:
                        partner_rows.append(" ".join(partner_row))
                        partner_row = []
                        row_width = 0
                    partner_row.append(part)
                    row_width += width + (1 if len(partner_row) > 1 else 0)
                if partner_row:
                    partner_rows.append(" ".join(partner_row))
                self.query_one("#my-hand", Static).update(
                    f"[bold #d6b35a]对家剩余手牌 · {len(cards)} 张[/bold #d6b35a]\n"
                    + "\n".join(partner_rows)
                )
                return
            self.query_one("#my-hand", Static).update(
                "[bold #d6b35a]你的手牌[/bold #d6b35a]\n[dim]本局已结束，点击“下一局”继续。[/dim]"
            )
            return
        parts: list[str] = []
        for i, c in enumerate(self._hand_cards):
            selected = i in self._hand_selected_indices
            cursor = i == self._hand_cursor
            wild = c == self._state().wild_card
            parts.append(_tui_card(c, selected=selected, cursor=cursor, wild=wild))

        def visible_width(markup: str) -> int:
            return cell_len(Text.from_markup(markup).plain)

        groups = self._hand_organizer.display_groups if not self.session.is_next_game_pending() else ()
        segments: list[str] = []
        if groups:
            position = 0
            for group in groups:
                group_parts = parts[position:position + len(group.cards)]
                position += len(group.cards)
                prefix = "[bold #ffd978]🔒[/bold #ffd978]" if group.locked else ""
                segment = prefix + "".join(group_parts)
                if visible_width(segment) <= self._hand_row_width():
                    segments.append(segment)
                    continue
                # Keep each card intact if a large stack needs another row.
                chunk = prefix
                for part in group_parts:
                    joined = chunk + part
                    if chunk and visible_width(joined) > self._hand_row_width():
                        segments.append(chunk)
                        chunk = part
                    else:
                        chunk = joined
                if chunk:
                    segments.append(chunk)
        else:
            segments = parts
        rows: list[str] = []
        row: list[str] = []
        row_width = 0
        max_width = self._hand_row_width()
        for segment in segments:
            part_width = visible_width(segment)
            if row and row_width + 4 + part_width > max_width:
                rows.append("    ".join(row))
                row = []
                row_width = 0
            row.append(segment)
            row_width += part_width + (4 if len(row) > 1 else 0)
        if row:
            rows.append("    ".join(row))
        selected_count = len(self._hand_selected_indices)
        cursor_pos = self._hand_cursor + 1 if self._hand_cards else 0
        organize_status = (
            f" · 理牌 {self._hand_organizer.status}"
            if self._hand_organizer.status
            and not self.session.is_next_game_pending()
            and not self._state().finished else ""
        )
        narrow = self._hand_row_width() < 90
        guide = (
            "←→光标 · 空格选牌 · G整组 · K锁牌 · S理牌 · 回车出牌" if narrow else
            "←→光标 · 空格选牌 · G整组选牌 · K锁/解锁 · S换理牌 · 回车出牌"
        )
        header = (
            "[bold #d6b35a]你的手牌[/bold #d6b35a]  "
            f"[#cdd7c8]光标 {cursor_pos}/{len(self._hand_cards)} · 已选 {selected_count} 张{organize_status}[/#cdd7c8]\n"
            f"[dim]{guide}[/dim]"
        )
        self.query_one("#my-hand", Static).update(f"{header}\n" + "\n".join(rows))

    def _hand_row_width(self) -> int:
        """Leave room for the hand border and padding in narrow terminals."""
        size = getattr(self.app, "size", None)
        width = size.width if size is not None else RECOMMENDED_COLUMNS
        return max(40, width - 10)

    def _refresh_round_actions(self) -> None:
        s = self._state()
        next_button = self.query_one("#btn-next-game", Button)
        organize_button = self.query_one("#btn-organize-hand", Button)
        lock_button = self.query_one("#btn-lock-hand", Button)
        back_button = self.query_one("#btn-game-back", Button)
        tribute_pending = self.session.is_next_game_pending()
        back_button.disabled = self._ai_running or self._saving
        next_button.disabled = self._saving or tribute_pending or not s.finished or s.match_finished
        organize_button.disabled = (
            tribute_pending or s.finished or not s.hands[self.human]
            or not self._hand_organizer.available
        )
        lock_action = self._hand_organizer.lock_action(self._lock_indices())
        lock_button.label = "K  解除锁定" if lock_action == "unlock" else "K  锁定牌型"
        lock_button.disabled = tribute_pending or s.finished or lock_action is None
        if tribute_pending:
            next_button.label = "已发牌"
        elif s.finished and s.match_finished:
            next_button.label = "比赛已结束"
        elif s.finished:
            next_button.label = f"N  下一局 · 级牌 {_rank_value_label(self._next_round_level(s))}"
        else:
            next_button.label = "N  下一局"

    def _next_round_level(self, state: GameState) -> int:
        return self.session.next_round_level(state)

    def _next_round_first_player(self, state: GameState) -> int:
        return self._next_round_first_player_for_hands(state, state.hands)

    def _next_round_first_player_for_hands(
        self,
        state: GameState,
        hands: list[list[Card]],
    ) -> int:
        if not state.finish_order:
            return self.human
        next_level = self._next_round_level(state)
        result = apply_tribute_flow(
            list(state.finish_order),
            [list(hand) for hand in hands],
            level=next_level,
            wild_card=_wild_card_from_hands(next_level, hands),
        )
        return result.first_player

    def _next_round_team_levels(self, state: GameState) -> list[int]:
        return self.session.next_round_team_levels(state)

    def _visible_team_levels(self, state: GameState) -> list[int]:
        del state
        return self.session.visible_team_levels()

    def _last_player_of(self, p: Pattern) -> int:
        return self.session.last_player_of(p)

    def _current_table_players(self) -> List[int]:
        """返回当前桌面每手牌对应的玩家，顺序与 `state.table` 一致。"""
        return self.session.current_table_players()

    def _current_trick_actions(self) -> List[TurnPlayed | Pass]:
        """从事件历史尾部提取当前 trick 的出牌/过牌事件。"""
        return current_trick_actions(self._state())

    def _locked_passed_players(self) -> List[int]:
        """提取对当前桌顶已过牌的玩家，按过牌发生顺序。"""
        return self.session.locked_passed_players()

    def _table_display_actions(
        self,
        table_players: List[int],
        passed_players: List[int],
    ) -> dict[int, tuple[str, Pattern | None]]:
        """按座位保留出牌区显示，只在轮到该座位时清理其上一手。"""
        del table_players, passed_players
        return self.session.table_display_actions()

    def action_cursor_left(self) -> None:
        if not self._hand_cards:
            return
        self._hand_cursor = (self._hand_cursor - 1) % len(self._hand_cards)
        self._do_render_hand()
        self._refresh_round_actions()

    def action_cursor_right(self) -> None:
        if not self._hand_cards:
            return
        self._hand_cursor = (self._hand_cursor + 1) % len(self._hand_cards)
        self._do_render_hand()
        self._refresh_round_actions()

    def action_toggle_select(self) -> None:
        if not self._hand_cards:
            return
        self.session.reset_hint_cycle()
        if self._hand_cursor in self._hand_selected_indices:
            self._hand_selected_indices.discard(self._hand_cursor)
        else:
            self._hand_selected_indices.add(self._hand_cursor)
        self._do_render_hand()
        self._refresh_round_actions()

    def action_play(self) -> None:
        s = self._state()
        if (
            self._ai_running or self._saving or self._failed_turn is not None
            or self.session.is_next_game_pending()
            or s.finished
            or s.turn_index != self.human
        ):
            return
        sel = [
            self._hand_cards[i]
            for i in sorted(self._hand_selected_indices)
            if i < len(self._hand_cards)
        ]
        result = self.session.play_human_cards(sel)
        if result.ok:
            self._hand_selected_indices.clear()
            self._refresh_all()
            self.set_timer(0.3, self._maybe_ai_turn)
        else:
            self.sub_title = result.message
            self._refresh_all()

    def action_pass(self) -> None:
        s = self._state()
        if (
            self._ai_running or self._saving or self._failed_turn is not None
            or self.session.is_next_game_pending()
            or s.finished
            or s.turn_index != self.human
        ):
            return
        result = self.session.pass_human()
        if result.ok:
            self._refresh_all()
            self.set_timer(0.3, self._maybe_ai_turn)
        else:
            self.sub_title = result.message
            self._refresh_all()

    def action_hint(self) -> None:
        s = self._state()
        if (
            self._ai_running or self._saving or self._failed_turn is not None
            or self.session.is_next_game_pending()
            or s.finished
            or s.turn_index != self.human
        ):
            return
        result = self.session.hint_for_human()
        self._hand_selected_indices = card_indices_for_selection(
            self._hand_cards,
            result.suggested_cards,
        )
        self.sub_title = result.message
        self._refresh_all()

    def action_organize_hand(self) -> None:
        s = self._state()
        if self.session.is_next_game_pending() or s.finished or not s.hands[self.human]:
            return
        if self._hand_organizer.advance():
            self._refresh_all()

    def action_reset_organize(self) -> None:
        s = self._state()
        if self.session.is_next_game_pending() or s.finished:
            return
        self._hand_organizer.reset()
        self._refresh_all()

    def action_select_group(self) -> None:
        s = self._state()
        if self.session.is_next_game_pending() or s.finished:
            return
        result = self._hand_organizer.playable_group_at(self._hand_cursor)
        if result is None:
            return
        start, end, _ = result
        indices = set(range(start, end))
        self._hand_selected_indices = (
            set() if self._hand_selected_indices == indices else indices
        )
        self.session.reset_hint_cycle()
        self._do_render_hand()
        self._refresh_round_actions()

    def _lock_indices(self) -> set[int]:
        if self._hand_selected_indices:
            return set(self._hand_selected_indices)
        group = self._hand_organizer.playable_group_at(self._hand_cursor)
        if group is not None and group[2].locked:
            return set(range(group[0], group[1]))
        return set()

    def action_toggle_lock(self) -> None:
        s = self._state()
        if self.session.is_next_game_pending() or s.finished:
            return
        if self._hand_organizer.toggle_lock(self._lock_indices()):
            self._hand_selected_indices.clear()
            self.session.reset_hint_cycle()
            self._refresh_all()

    def action_next_game(self) -> None:
        if self._ai_running or self._saving or self.session.is_next_game_pending():
            return
        prepared = self.session.prepare_next_game()
        if not prepared.ok:
            self._refresh_all()
            return
        self._hand_selected_indices.clear()
        self._hand_cursor = 0
        self._refresh_all()
        self._tribute_timer = self.set_timer(0.5, self._begin_next_game_tribute)

    def _begin_next_game_tribute(self) -> None:
        if self._tribute_timer is not None:
            self._tribute_timer.stop()
            self._tribute_timer = None
        if self._saving:
            return
        if not self.session.is_next_game_pending():
            return
        started = self.session.begin_next_game_tribute()
        if not started.ok:
            self._refresh_all()
            return
        self._refresh_all()
        if self.session.pending_next_game_choice() is not None:
            self.call_after_refresh(self._show_tribute_choice)
            return
        self._finish_next_game(None)

    def _show_tribute_choice(self) -> None:
        choice = self.session.pending_next_game_choice()
        if choice is None:
            return
        from .confirm import TributeChoiceModal

        self.app.push_screen(
            TributeChoiceModal(choice.kind, choice.cards),
            self._finish_next_game,
        )

    def _finish_next_game(self, selected_card: Card | None) -> None:
        if self._saving:
            return
        if selected_card is None and self.session.pending_next_game_choice() is not None:
            self.session.cancel_next_game()
            self._refresh_all()
            return
        result = self.session.finalize_next_game(selected_card)
        if not result.ok:
            self._refresh_all()
            return
        self._hand_selected_indices.clear()
        self._hand_cursor = 0
        self._refresh_all()
        self.set_timer(0.3, self._maybe_ai_turn)

    def action_rules(self) -> None:
        from .rule import RuleScreen

        self.app.push_screen(RuleScreen())

    def action_back(self) -> None:
        self.request_leave()

    def request_leave(self, *, quit_app: bool = False) -> None:
        self._leave_requested = True
        self._quit_after_save = self._quit_after_save or quit_app
        if self._ai_running or self._saving:
            return
        if self._tribute_timer is not None:
            self._tribute_timer.stop()
        self._saving = True
        self._refresh_all()
        self._save_then_leave()

    @work(thread=True, exclusive=True, group="leave-save")
    def _save_then_leave(self) -> None:
        try:
            self.session.save_current()
        except SaveConflictError as exc:
            self.app.call_from_thread(self._leave_conflict, exc)
            return
        except Exception as exc:
            self.app.call_from_thread(self._leave_failed, exc)
            return
        self.app.call_from_thread(self._finish_leave)

    def _leave_conflict(self, error: SaveConflictError) -> None:
        from .error import ErrorModal

        self.app.push_screen(
            ErrorModal(f"{error}\n可在“继续上次的牌局”中恢复副本。", title="进度已另存"),
            lambda _: self._finish_leave(),
        )

    def _finish_leave(self) -> None:
        self._saving = False
        self._leave_requested = False
        if self._quit_after_save:
            self.app.exit()
        else:
            self.app.pop_screen()

    def _leave_failed(self, error: Exception) -> None:
        self._saving = False
        self._leave_requested = False
        self._quit_after_save = False
        self._refresh_all()
        from .error import ErrorModal

        self.app.push_screen(ErrorModal(str(error), title="保存失败"))

    def on_button_pressed(self, event: Button.Pressed) -> None:
        if event.button.id == "btn-organize-hand":
            self.action_organize_hand()
            event.stop()
        elif event.button.id == "btn-lock-hand":
            self.action_toggle_lock()
            event.stop()
        elif event.button.id == "btn-next-game":
            self.action_next_game()
            event.stop()
        elif event.button.id == "btn-game-back":
            self.action_back()
            event.stop()

    def _maybe_ai_turn(self) -> None:
        if self._failed_turn is not None:
            return
        if self._ai_running or self._saving or self.session.is_next_game_pending():
            return
        s = self._state()
        if s.finished:
            self._refresh_all()
            self.session.save_finished_if_needed()
            return
        if s.turn_index == self.human:
            return
        self._ai_running = True
        self._refresh_all()
        self._run_ai_worker()

    @work(thread=True, exclusive=True, group="ai-turns")
    def _run_ai_worker(self, save_only: bool = False) -> None:
        result = run_turn(self.session, save_only=save_only)
        self.app.call_from_thread(self._finish_ai_turn, result)

    def _finish_ai_turn(self, result: TurnResult) -> None:
        self._ai_running = False
        self._failed_turn = result if result.error is not None else None
        if result.error is not None:
            self._last_action = f"后台操作失败：{result.error}；按 R 重试或 Esc 返回"
        elif result.messages:
            self._last_action = "；".join(result.messages)
        self._refresh_all()
        state = self._state()
        if self._leave_requested:
            self.request_leave()
        elif not state.finished and state.turn_index != self.human and result.error is None:
            self.set_timer(0.1, self._maybe_ai_turn)

    def action_retry_background(self) -> None:
        if self._ai_running or self._saving or self._failed_turn is None:
            return
        save_only = self._failed_turn.stage == "storage"
        self._failed_turn = None
        self._ai_running = True
        self._refresh_all()
        self._run_ai_worker(save_only)

    def _describe_ai_action(self, state: GameState, player: int, history_len_before: int) -> str:
        del state
        return self.session.describe_player_action(player, history_len_before)

    def _save_game_result(self) -> None:
        """保存游戏结果（历史和统计）。"""
        self.session.save_finished_if_needed()
        if self._last_action.startswith("保存失败："):
            self.sub_title = self._last_action

    def on_unmount(self) -> None:
        if self._tribute_timer is not None:
            self._tribute_timer.stop()
            self._tribute_timer = None
