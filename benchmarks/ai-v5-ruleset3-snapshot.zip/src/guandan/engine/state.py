"""GameState：游戏对局的当前状态。

设计：可变 dataclass，所有 mutation 通过方法，便于"回放事件 → 重放状态"。

State 组成：
- level: 当前级牌点数（2..14，A=14）
- team_levels: 本局开始时两队各自级牌（0=东西，1=南北）
- wild_card: 逢人配（红心级牌）
- hands: 4 家手牌（list of list[Card]）
- turn_index: 当前轮到的玩家
- table: 本轮出牌区（按出牌顺序）
- passed_players: 对当前桌顶已过牌的玩家（旧规则局为整墩过牌玩家）
- leader: 本轮的先出者
- history: 已发生的事件
- finish_order: 已出完牌的玩家顺序（空表示未结束）
- bomb_count: 各队本局已出炸弹数
- has_played_ace: 各队本局是否出过 A
- finished: 是否结束
- tribute_state: 进贡/还贡阶段的状态
"""
from __future__ import annotations

import copy
import random
from collections import Counter
from dataclasses import dataclass, field
from typing import Optional

from .card import (
    RANK_2,
    RANK_A,
    Card,
    Suit,
)
from .deck import deal, make_deck, shuffle_deck
from .events import Event, ShuffleDeal
from .hand import Pattern, PatternType

# 队伍：0=东-西（player 0 & 2），1=南-北（player 1 & 3）
LEGACY_RULESET_VERSION = 1  # 旧局：过牌锁定至整墩结束
PASS_RESET_RULESET_VERSION = 2  # 历史局：重新询问过牌者，但一次冲 A 失败退 2
CURRENT_RULESET_VERSION = 3  # 新局：累计三次未过 A 才退 2


def team_of(player: int) -> int:
    return player % 2


def partner_of(player: int) -> int:
    """对家（队友）。座位按 东=0 南=1 西=2 北=3，对家 = (p+2) % 4。

    例如：partner_of(0) == 2（西是东的对家），partner_of(1) == 3（北是南的对家）。
    """
    return (player + 2) % 4


def is_teammate(a: int, b: int) -> bool:
    """a 和 b 是否同队。"""
    return team_of(a) == team_of(b)


# 座位名
SEAT_NAMES = ["东", "南", "西", "北"]


def next_seat_counterclockwise(player: int) -> int:
    """逆时针下一家：东 -> 北 -> 西 -> 南 -> 东。"""
    return (player - 1) % 4


@dataclass
class TributeState:
    """进贡/还贡阶段状态。"""

    pending: bool = False  # 是否在进贡/还贡阶段
    from_player: int = -1  # 进贡方
    to_player: int = -1  # 收贡方
    tribute_card: Optional[Card] = None  # 已进贡的牌（待还贡时使用）
    resisted: bool = False  # 是否抗贡


@dataclass
class GameState:
    """一局掼蛋的完整状态。"""

    level: int
    wild_card: Optional[Card]
    hands: list[list[Card]]  # 4 家手牌
    turn_index: int  # 0-3
    team_levels: list[int] = field(default_factory=list)
    table: list[Pattern] = field(default_factory=list)
    # 对当前桌顶已过牌的玩家；旧规则局中保留为整墩过牌集合。
    passed_players: set[int] = field(default_factory=set)
    leader: Optional[int] = None  # 本轮先手
    history: list[Event] = field(default_factory=list)
    finish_order: list[int] = field(default_factory=list)
    team_bomb_count: list[int] = field(default_factory=lambda: [0, 0])
    a_failure_counts: list[int] = field(default_factory=lambda: [0, 0])
    # 兼容旧存档/旧统计字段；当前过 A 只看 A 级局名次，不要求先出过 A。
    has_played_ace: list[bool] = field(default_factory=lambda: [False, False])
    finished: bool = False
    tribute_state: TributeState = field(default_factory=TributeState)
    drift: bool = False
    trick_number: int = 0  # 第几轮（一轮 = 一手出牌 + 后续过牌/压牌）
    next_trick_starter: Optional[int] = None  # 下一轮的先手
    team_levels_final: Optional[list[int]] = None
    drift_flag: bool = False
    guo_a: bool = False
    guo_a_failed: bool = False
    match_finished: bool = False
    winner_team: Optional[int] = None
    ruleset_version: int = CURRENT_RULESET_VERSION

    def hand(self, player: int) -> list[Card]:
        return self.hands[player]

    def hand_size(self, player: int) -> int:
        return len(self.hands[player])

    def is_finished(self) -> bool:
        return self.finished

    def current_player(self) -> int:
        return self.turn_index

    def to_wild_card(self) -> Optional[Card]:
        """返回本局的逢人配。"""
        return self.wild_card

    def __post_init__(self) -> None:
        if not self.team_levels:
            self.team_levels = [self.level, self.level]
        if type(self.ruleset_version) is not int or self.ruleset_version not in (
            LEGACY_RULESET_VERSION,
            PASS_RESET_RULESET_VERSION,
            CURRENT_RULESET_VERSION,
        ):
            raise ValueError("unsupported ruleset version")
        if len(self.a_failure_counts) != 2 or any(
            type(count) is not int or count not in range(3)
            for count in self.a_failure_counts
        ):
            raise ValueError("A failure counts must be two integers from 0 to 2")


# ---- 玩家行动 ----


class IllegalPlayError(Exception):
    """出牌不合法。"""


def play_pattern(state: GameState, player: int, pattern: Pattern) -> None:
    """玩家 player 出牌 pattern。

    必须满足：
    - player == state.turn_index
    - pattern.cards 全部在 player 手牌中
    - 当前 table 为空（新一轮先手）或 pattern 可压 table[-1]
    - 玩家未对当前桌顶过牌
    """
    if state.finished:
        raise IllegalPlayError("game is finished")
    if player != state.turn_index:
        raise IllegalPlayError(f"not player's turn: {player} != {state.turn_index}")
    if player in state.passed_players:
        raise IllegalPlayError(f"player {player} already passed on this top play")

    # Pattern 是跨 UI、AI 和存档边界传递的数据，不能信任调用方给出的
    # type/rank/length。必须确认实际选出的整组牌确实能按该解释构成合法牌型。
    from .rules.patterns import detect_patterns

    if not any(
        candidate.type == pattern.type
        and candidate.rank == pattern.rank
        and candidate.length == pattern.length
        and candidate.wild_used == pattern.wild_used
        and Counter(candidate.cards) == Counter(pattern.cards)
        # suit is display metadata for a straight flush. Older save files and
        # callers may omit it, but a supplied value must still be correct.
        and (pattern.suit is None or candidate.suit == pattern.suit)
        for candidate in detect_patterns(pattern.cards, state.wild_card)
    ):
        raise IllegalPlayError("pattern does not match a legal interpretation of its cards")

    # 验证 pattern 的牌都在手牌中
    hand = state.hands[player]
    hand_counts = Counter(hand)
    for c, needed in Counter(pattern.cards).items():
        if hand_counts[c] < needed:
            raise IllegalPlayError(f"card {c} not in hand")

    # 验证可压当前 table[-1]（若有）
    if state.table and pattern.can_be_played_on(state.table[-1], level=state.level) is False:
        raise IllegalPlayError(
            f"pattern {pattern} cannot beat {state.table[-1]}"
        )

    # 出牌：从手牌中删除
    for c in pattern.cards:
        hand.remove(c)

    # 更新 table
    state.table.append(pattern)

    # 记录事件
    from .events import TurnPlayed

    state.history.append(
        TurnPlayed(
            player=player,
            pattern=pattern,
            hand_remaining=len(hand),
        )
    )
    _auto_claim_if_needed(state, player)

    # 更新本轮 leader
    if state.leader is None:
        state.leader = player
    # 一次过牌只回应当时的桌顶。有人压牌后，各家重新获得回应机会。
    # 旧局保持原有锁定行为，确保旧存档与事件流可按原规则重建。
    if state.ruleset_version != LEGACY_RULESET_VERSION:
        state.passed_players.clear()

    # 累计本队炸弹数
    from .rules.comparator import is_bomb_type

    if is_bomb_type(pattern.type):
        state.team_bomb_count[team_of(player)] += 1
    # 记录出 A
    if pattern.type == PatternType.SINGLE and any(
        c.rank == RANK_A and not c.is_joker for c in pattern.cards
    ):
        state.has_played_ace[team_of(player)] = True

    # 检查是否出完
    if not hand:
        if player not in state.finish_order:
            state.finish_order.append(player)
        # 3rd finisher 产生时游戏结束（剩 1 人即末游）
        if len(state.finish_order) == 3:
            _finish_game(state)
            return
        if _all_active_non_top_passed(state):
            _end_trick_or_jiefeng(state)
            return
        # 1st / 2nd finisher：不立即触发接风，要等其他 3 人是否压牌
        # 让 turn 继续推进，下家可以选择压牌或过牌
        # 跳过已出完或对当前桌顶过牌的玩家
        state.turn_index = _next_active_player(state, player)
        return

    if _all_active_non_top_passed(state):
        _end_trick_or_jiefeng(state)
        return

    # 推进到下一个"未过牌且未出完"的玩家
    state.turn_index = _next_active_player(state, player)


def pass_turn(state: GameState, player: int) -> None:
    """玩家过牌。"""
    if state.finished:
        raise IllegalPlayError("game is finished")
    if player != state.turn_index:
        raise IllegalPlayError(f"not player's turn: {player} != {state.turn_index}")
    if not state.table:
        # 你是新一轮的先手，不能过牌
        raise IllegalPlayError("leader cannot pass")

    from .events import Pass as PassEvent

    state.history.append(
        PassEvent(player=player, hand_remaining=len(state.hands[player]))
    )

    # 记录对当前桌顶的过牌（旧局则锁定至整墩结束）
    state.passed_players.add(player)

    # 检查本轮是否结束：所有"能行动且不是当前最大牌玩家"的人都过了
    if _all_active_non_top_passed(state):
        _end_trick_or_jiefeng(state)
        return

    # 推进到下一个"未过牌且未出完"的玩家
    state.turn_index = _next_active_player(state, player)


def claim(state: GameState, player: int, count: int) -> None:
    """报牌。

    当前规则采用自动报牌；此函数只允许在玩家实际手牌数 ≤10 时记录，
    主要用于 UI/CLI 的手动补报和旧调用兼容。
    """
    actual_count = len(state.hands[player])
    if actual_count > 10:
        raise IllegalPlayError("claim is only allowed when hand size <= 10")
    if count != actual_count:
        raise IllegalPlayError(f"claim count mismatch: {count} != {actual_count}")
    from .events import Claim as ClaimEvent

    if any(
        isinstance(event, ClaimEvent) and event.player == player and event.count == count
        for event in reversed(state.history)
    ):
        return
    state.history.append(ClaimEvent(player=player, count=count))


def _auto_claim_if_needed(state: GameState, player: int) -> None:
    """手牌数 ≤ 10 时自动报牌；同一玩家同一张数只报一次。"""
    count = len(state.hands[player])
    if count > 10:
        return
    from .events import Claim as ClaimEvent

    if any(
        isinstance(event, ClaimEvent) and event.player == player and event.count == count
        for event in reversed(state.history)
    ):
        return
    claim(state, player, count)


# ---- 内部工具 ----


def _next_player(state: GameState, current: int) -> int:
    """下一个玩家（按逆时针），跳过已出完手牌的玩家。"""
    nxt = next_seat_counterclockwise(current)
    visited = 0
    while nxt in state.finish_order:
        nxt = next_seat_counterclockwise(nxt)
        visited += 1
        if visited >= 4:
            # 全部出完（理论上不该走到这里，因为 3rd 出完时会结束游戏）
            return current
    return nxt


def _next_active_player(state: GameState, current: int) -> int:
    """下一个尚未出完、且未对当前桌顶过牌的玩家（按逆时针）。

    区别于 `_next_player`：后者只跳过 finish_order，本函数同时跳过
    `passed_players`。新规则中每次压牌都会清空该集合。
    """
    nxt = next_seat_counterclockwise(current)
    visited = 0
    while nxt in state.finish_order or nxt in state.passed_players:
        nxt = next_seat_counterclockwise(nxt)
        visited += 1
        if visited >= 4:
            # 全部跳过：理论上不该走到这里，因为 pass_turn 之前已
            # 检查过"是否所有非当前最大牌玩家都过了"
            return current
    return nxt


def _current_top_player(state: GameState) -> Optional[int]:
    """当前桌面最大牌所属玩家；table 为空时返回本轮先手。"""
    from .trick import current_top_player

    return current_top_player(state)


def _active_non_top_count(state: GameState) -> int:
    """当前轮中需要回应最大牌的玩家数量（未出完且不是当前最大牌玩家）。"""
    top_player = _current_top_player(state)
    return sum(
        1 for p in range(4) if p != top_player and p not in state.finish_order
    )


def _active_non_top_set(state: GameState) -> set[int]:
    """当前轮中需要回应最大牌的玩家集合（未出完且不是当前最大牌玩家）。"""
    top_player = _current_top_player(state)
    return {p for p in range(4) if p != top_player and p not in state.finish_order}


def _all_active_non_top_passed(state: GameState) -> bool:
    """是否所有仍需回应最大牌的玩家都已过牌。"""
    return len(state.passed_players & _active_non_top_set(state)) >= _active_non_top_count(
        state
    )


def _end_trick_or_jiefeng(state: GameState) -> None:
    """所有"能行动的非当前最大牌玩家"都过牌后调用。

    规则（按文档）：
    - 若当前最大牌玩家已出完手牌 → 触发接风：
      - 新的 leader = 该玩家的对家（如果对家未出完手牌）
      - 如果对家也已出完（如头游+二游同队的极端情况）→ 找下一个未出完的玩家
    - 若当前最大牌玩家还在玩 → 正常开新轮，由其继续领出
    - 清空 table、重置 passed_players
    """
    last_leader = _current_top_player(state)
    state.table = []
    state.passed_players.clear()
    state.trick_number += 1

    if last_leader is not None and last_leader in state.finish_order:
        # 触发接风：对家成为新 leader
        partner = partner_of(last_leader)
        if partner not in state.finish_order:
            new_leader = partner
        else:
            # 对家也出完了（如头游+二游同队），找下一个 active 玩家
            new_leader = next_seat_counterclockwise(last_leader)
            while new_leader in state.finish_order:
                new_leader = next_seat_counterclockwise(new_leader)
                if new_leader == last_leader:
                    return  # 全部出完（不该发生）
    else:
        if last_leader is None:
            return
        new_leader = last_leader

    state.leader = new_leader
    state.next_trick_starter = new_leader
    state.turn_index = new_leader


def _finish_game(state: GameState) -> None:
    """结束一局。计算升级和过 A。

    文档规则：
    - 3rd finisher 产生时结束游戏，剩 1 人为末游
    - 升级：头游+二游=+3, 头游+三游=+2, 头游+末游=+1
    - 对方不降级
    - 漂牌扩展玩法不启用：保留兼容字段，但不参与升级
    - 过 A：必须"双上"（头游方队友非末游）才算成功
    """
    state.finished = True

    # finish_order = [头游, 二游, 三游]，剩 1 人是末游
    if len(state.finish_order) != 3:
        # 异常：理论上不该走到这里
        return
    head = state.finish_order[0]
    second = state.finish_order[1]
    third = state.finish_order[2]
    last = next(p for p in range(4) if p not in state.finish_order)

    # 升级：按头游方的两个名次组合
    from .rules.scoring import compute_level_change

    delta_team0, delta_team1 = compute_level_change(
        head, second, third, last, state.team_bomb_count
    )
    base_levels = (
        list(state.team_levels)
        if len(state.team_levels) == 2
        else [state.level, state.level]
    )
    new_level_0 = min(RANK_A, max(RANK_2, base_levels[0] + delta_team0))
    new_level_1 = min(RANK_A, max(RANK_2, base_levels[1] + delta_team1))
    new_levels = [new_level_0, new_level_1]

    # 兼容旧存档 / 历史 schema：漂牌扩展玩法不启用，始终不加级。
    drift = False
    state.drift = False

    # 过 A 判定：头游方 + 队友非末游（= 头游+二游 或 头游+三游）
    # 头游队伍开局级牌打到 A 才能"冲 A"。
    guo_a = False
    guo_a_failed = False
    upstream_team = team_of(head)
    upstream_partner_rank = (
        2 if (second == partner_of(head)) else (3 if (third == partner_of(head)) else 4)
    )
    if base_levels[upstream_team] == RANK_A:
        if upstream_partner_rank in (2, 3):
            # 队友是 2nd 或 3rd → 双上 → 过 A 成功
            guo_a = True
            state.match_finished = True
            state.winner_team = upstream_team
            new_levels[upstream_team] = RANK_2  # 过 A 后回到 2
            # 另一队不降级
        else:
            # 队友是末游 → 冲 A 失败
            guo_a_failed = True
            if state.ruleset_version < CURRENT_RULESET_VERSION:
                new_levels[upstream_team] = RANK_2

    if state.ruleset_version >= CURRENT_RULESET_VERSION and not guo_a:
        # 每副 A 级牌都算一次过 A 机会；未拿头游同样未能过 A。
        # 两队可以同时在 A，失败次数各自累计。第三次失败才回到 2。
        for team in (0, 1):
            if base_levels[team] != RANK_A:
                continue
            guo_a_failed = True
            state.a_failure_counts[team] += 1
            if state.a_failure_counts[team] == 3:
                new_levels[team] = RANK_2
                state.a_failure_counts[team] = 0

    state.team_levels_final = new_levels
    state.drift_flag = drift
    state.guo_a = guo_a
    state.guo_a_failed = guo_a_failed
    if guo_a:
        state.match_finished = True
        state.winner_team = upstream_team

    from .events import GameOver, LevelUp

    # 即使过 A 成功或失败也记录 LevelUp（用于显示）
    if (new_levels[0] != base_levels[0] if state.ruleset_version >= CURRENT_RULESET_VERSION
            else delta_team0 != 0 or guo_a or guo_a_failed):
        state.history.append(
            LevelUp(
                team=0,
                new_level=new_levels[0],
                delta=new_levels[0] - base_levels[0],
            )
        )
    if (new_levels[1] != base_levels[1] if state.ruleset_version >= CURRENT_RULESET_VERSION
            else delta_team1 != 0 or guo_a or guo_a_failed):
        state.history.append(
            LevelUp(
                team=1,
                new_level=new_levels[1],
                delta=new_levels[1] - base_levels[1],
            )
        )
    state.history.append(
        GameOver(
            finish_order=(head, second, third, last),
            team_levels=(new_levels[0], new_levels[1]),
            drift=drift,
            guo_a=guo_a,
            winner_team=state.winner_team,
            a_failure_counts=(state.a_failure_counts[0], state.a_failure_counts[1]),
        )
    )


def make_initial_state(
    level: int = 2,
    first_player: int = 0,
    seed: Optional[int] = None,
    team_levels: Optional[list[int] | tuple[int, int]] = None,
    ruleset_version: int = CURRENT_RULESET_VERSION,
    a_failure_counts: Optional[list[int] | tuple[int, int]] = None,
) -> GameState:
    """构造一局的初始状态（发牌完毕）。

    Args:
        level: 本局级牌点数（2..14）
        first_player: 首发起家索引
        seed: 随机种子（用于复现）
        team_levels: 本局开始时两队各自级牌。未传入时两队都视为 level。
        ruleset_version: 规则版本。旧存档重放传 1/2，新局默认 3。
        a_failure_counts: 两队此前累计的冲 A 失败次数。
    """
    if not RANK_2 <= level <= RANK_A:
        raise ValueError(f"level must be 2..14, got {level}")
    if first_player not in range(4):
        raise ValueError(f"first_player must be 0..3, got {first_player}")
    if team_levels is None:
        initial_team_levels = [level, level]
    else:
        initial_team_levels = list(team_levels)
        if len(initial_team_levels) != 2:
            raise ValueError("team_levels must contain exactly two levels")
        for team_level in initial_team_levels:
            if not RANK_2 <= team_level <= RANK_A:
                raise ValueError(f"team level must be 2..14, got {team_level}")

    resolved_seed = seed if seed is not None else random.SystemRandom().randrange(1, 2**63)
    rng = random.Random(resolved_seed)
    deck = make_deck()
    shuffled = shuffle_deck(deck, rng)
    hands = deal(shuffled, 4)

    # 确定 wild_card：红心级牌
    wild_card: Optional[Card] = None
    for p in (0, 1, 2, 3):
        for c in hands[p]:
            if c.rank == level and c.suit == Suit.HEARTS:
                wild_card = c
                break
        if wild_card is not None:
            break

    state = GameState(
        level=level,
        wild_card=wild_card,
        hands=hands,
        turn_index=first_player,
        team_levels=initial_team_levels,
        a_failure_counts=list(a_failure_counts) if a_failure_counts is not None else [0, 0],
        leader=first_player,
        ruleset_version=ruleset_version,
    )
    # 记录发牌事件
    state.history.append(
        ShuffleDeal(
            level=level,
            wild_card=wild_card,
            hand_sizes=(len(hands[0]), len(hands[1]), len(hands[2]), len(hands[3])),
            first_player=first_player,
            seed=resolved_seed,
            team_levels=(initial_team_levels[0], initial_team_levels[1]),
            a_failure_counts=(state.a_failure_counts[0], state.a_failure_counts[1]),
        )
    )
    return state


def clone_state_for_search(state: GameState) -> GameState:
    """Copy a state cheaply for simulation.

    `copy.deepcopy` is the single most expensive operation in the IS-MCTS inner
    loop, and it copies far more than the search mutates: `Card`, `Pattern` and
    the event objects are frozen and safe to share, and the event history is
    append-only (and never rewritten by simulation), so its list can be copied
    shallowly.

    Every mutable container is rebuilt one level deep — `hands` is a list of
    lists, so copying only the outer list would leave the search mutating the
    caller's hands.
    """
    shallow = copy.copy(state)
    for field_name in _SEARCH_MUTATED_CONTAINERS:
        value = getattr(shallow, field_name, None)
        if isinstance(value, list):
            setattr(
                shallow,
                field_name,
                [list(item) if isinstance(item, list) else item for item in value],
            )
        elif isinstance(value, set):
            setattr(shallow, field_name, set(value))
    if isinstance(shallow.tribute_state, TributeState):
        shallow.tribute_state = copy.copy(shallow.tribute_state)
    return shallow


# Containers `play_pattern` / `pass_turn` mutate in place.
_SEARCH_MUTATED_CONTAINERS = (
    "hands",
    "table",
    "passed_players",
    "history",
    "finish_order",
    "team_bomb_count",
    "a_failure_counts",
    "has_played_ace",
    "team_levels",
)


def sort_hand_cards(cards: list[Card]) -> list[Card]:
    """按从大到小排序。"""
    return sorted(cards, reverse=True)


def remove_cards_from_hand(hand: list[Card], cards_to_remove: list[Card]) -> None:
    """从手牌中删除 cards_to_remove（按内容匹配，不按位置）。"""
    for c in cards_to_remove:
        try:
            hand.remove(c)
        except ValueError as exc:
            raise ValueError(f"card {c} not in hand") from exc
