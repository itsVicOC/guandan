"""手牌价值评估。档 1+ 用来在多个候选出牌中选"损失最小"的那手。

启发式（不是精确期望值）：
- 出牌本身的牌型类别越大（`Pattern.weight`），出牌越"贵"
- 拆散高对子比拆散单张更贵
- 用 逢人配 出小牌 = 大亏
- 炸弹 / 同花顺 / 四王非常贵，除非能确认收掉这一轮

返回 float，越小越划算。
"""
from __future__ import annotations

from collections import Counter
from typing import List, Optional

from ..engine.card import RANK_A, Card
from ..engine.hand import Pattern, PatternType, comparison_rank, effective_rank
from ..engine.rules.comparator import bomb_strength, is_bomb_type
from ..engine.rules.patterns import detect_patterns
from ..engine.state import GameState
from .candidates import (
    enumerate_legal_patterns,
    is_bomb_pattern,
    pattern_key,
)
from .context import opponent_min_cards as context_opponent_min_cards
from .hand_plan import estimate_remaining_plays, remaining_cards


def _hand_breakdown(cards: list) -> dict:
    """按 rank 统计张数。"""
    d: dict = {}
    for c in cards:
        d[c.rank] = d.get(c.rank, 0) + 1
    return d


def _count_wild_in_pattern(p: Pattern, wild: Optional[object]) -> int:
    if wild is None:
        return 0
    return sum(1 for c in p.cards if c == wild)


_STRUCTURE_TYPES = {
    PatternType.STRAIGHT,
    PatternType.PAIR_SEQUENCE,
    PatternType.TRIPLE_SEQUENCE,
    PatternType.TRIPLE_PAIR,
}

_CardKey = tuple[tuple[int, int, int], ...]
_StructureCache = dict[_CardKey, float]

# Structure scores only depend on the card multiset and the wild card, so they
# are worth remembering between calls: candidate enumeration evaluates one
# score per candidate, and the same hands recur across simulations and even
# across decisions.
_STRUCTURE_SCORE_LIMIT = 8192
_structure_score_memo: dict[tuple[_CardKey, Card | None], float] = {}


def _cards_key(cards: list[Card]) -> _CardKey:
    counts = Counter(cards)
    return tuple(
        sorted((card.rank, int(card.suit), count) for card, count in counts.items())
    )


def _best_structure_score(cards: list, wild: Optional[Card]) -> float:
    """估算手牌中顺子/连对/钢板/三带二的保留价值。"""
    best = 0.0
    for p in detect_patterns(cards, wild):
        if p.type not in _STRUCTURE_TYPES:
            continue
        score = float(len(p.cards) + p.weight) - p.wild_used * 0.5
        if score > best:
            best = score
    return best


def _cached_structure_score(
    cards: list[Card],
    wild: Optional[Card],
    cache: Optional[_StructureCache],
) -> float:
    key = _cards_key(cards)
    if cache is not None and key in cache:
        return cache[key]
    memo_key = (key, wild)
    memo = _structure_score_memo.get(memo_key)
    if memo is None:
        memo = _best_structure_score(cards, wild)
        if len(_structure_score_memo) >= _STRUCTURE_SCORE_LIMIT:
            _structure_score_memo.clear()
        _structure_score_memo[memo_key] = memo
    if cache is not None:
        cache[key] = memo
    return memo


def estimate_pattern_cost(
    state: GameState,
    player: int,
    pattern: Pattern,
) -> float:
    """评估"出这手牌"对 player 手力的损失。

    越小越划算。档 1+ 在多个候选牌型中选 `cost` 最小者。
    """
    return _estimate_pattern_cost(state, player, pattern)


def _estimate_pattern_cost(
    state: GameState,
    player: int,
    pattern: Pattern,
    *,
    before_structure: Optional[float] = None,
    structure_cache: Optional[_StructureCache] = None,
    opponent_min_cards: Optional[int] = None,
) -> float:
    hand = state.hands[player]
    wild = state.wild_card

    # 拆分手牌 → 出牌后剩余手牌（用 multiset 避免误删）
    pat_counts = Counter(pattern.cards)
    rem_counts: Counter = Counter(hand)
    rem_counts.subtract(pat_counts)
    rem_cards = list(rem_counts.elements())

    breakdown_before = _hand_breakdown(hand)
    breakdown_after = _hand_breakdown(rem_cards)

    # ---- 1. 牌型类别基础成本 ----
    base = float(pattern.weight)

    # ---- 2. 拆对子 / 拆三张惩罚 ----
    # before=2 → after=1 是"拆对"；before=3 → after=2 是"拆三张"
    breakup = 0.0
    for r, cnt_after in breakdown_after.items():
        cnt_before = breakdown_before.get(r, 0)
        if cnt_before >= 2 and cnt_after == 1:
            breakup += 3.0
        elif cnt_before >= 3 and cnt_after == 2:
            breakup += 5.0

    # ---- 3. 浪费 逢人配 ----
    wild_used = _count_wild_in_pattern(pattern, wild)
    wild_penalty = wild_used * 8.0

    # ---- 4. 拆王 / 拆级牌 / 拆高牌的小加成 ----
    high_penalty = 0.0
    for c in pattern.cards:
        if c.is_big_joker:
            high_penalty += 4.0
        elif c.is_small_joker:
            high_penalty += 3.0
        elif c != wild and effective_rank(c.rank, state.level) > RANK_A:
            high_penalty += 2.5
        elif c.rank == RANK_A:
            high_penalty += 1.5
        elif c.rank == 13:  # K
            high_penalty += 0.5

    # ---- 5. 炸弹特别贵 ----
    bomb_premium = 0.0
    if is_bomb_type(pattern.type):
        bomb_premium = 5.0
        if pattern.type == PatternType.STRAIGHT_FLUSH:
            bomb_premium += 3.0
        elif pattern.type == PatternType.FOUR_JOKERS:
            bomb_premium += 6.0

    # ---- 6. 保留顺子/连对/钢板等结构 ----
    structure_penalty = 0.0
    if pattern.type not in _STRUCTURE_TYPES and not is_bomb_type(pattern.type):
        before_score = (
            _cached_structure_score(hand, wild, structure_cache)
            if before_structure is None
            else before_structure
        )
        after_structure = _cached_structure_score(rem_cards, wild, structure_cache)
        structure_penalty = max(0.0, before_score - after_structure) * 0.8

    # ---- 7. 收牌奖励：出完手牌 → 估值大幅降低 ----
    finish_bonus = 0.0
    if len(rem_cards) == 0:
        finish_bonus = -20.0

    # ---- 8. 领牌整理：自然结构牌能显著减少手牌轮次 ----
    lead_shedding_bonus = 0.0
    if not state.table and pattern.type in _STRUCTURE_TYPES and not is_bomb_type(pattern.type):
        lead_shedding_bonus = -min(8.0, len(pattern.cards) * 1.3)

    # ---- 9. 对手报单时避免用单张领牌 ----
    single_lead_pressure = 0.0
    if (
        not state.table
        and pattern.type == PatternType.SINGLE
        and (
            opponent_min_cards
            if opponent_min_cards is not None
            else context_opponent_min_cards(state, player)
        )
        == 1
    ):
        single_lead_pressure = 6.0

    return (
        base
        + breakup
        + wild_penalty
        + high_penalty
        + bomb_premium
        + structure_penalty
        + finish_bonus
        + lead_shedding_bonus
        + single_lead_pressure
    )


def enumerate_candidate_plays(
    state: GameState,
    player: int,
    *,
    max_candidates: int = 8,
) -> List[Pattern]:
    """生成 top-N 候选出牌，按 `estimate_pattern_cost` 升序。

    M2 策略层用：在多个"能压"的牌型里选估值最低的。

    实现：
    1. 用规则引擎枚举当前所有合法候选
    2. 按 `estimate_pattern_cost` 排序
    3. 截断到 `max_candidates`
    """
    hand = state.hands[player]
    if not hand:
        return []
    candidates = enumerate_legal_patterns(state, player)
    structure_cache: _StructureCache = {}
    before_structure = _cached_structure_score(hand, state.wild_card, structure_cache)
    min_opponent_cards = context_opponent_min_cards(state, player) if not state.table else 0
    candidates.sort(
        key=lambda p: _estimate_pattern_cost(
            state,
            player,
            p,
            before_structure=before_structure,
            structure_cache=structure_cache,
            opponent_min_cards=min_opponent_cards,
        )
    )
    return candidates[:max_candidates]


def enumerate_search_candidates(
    state: GameState,
    player: int,
    *,
    max_candidates: int = 12,
) -> List[Pattern]:
    """Build a diverse, ordered action set for tree search.

    A pure top-N cost cut is fast but systematically hides control plays,
    large shedding combinations and bombs.  This selector first reserves
    strategic representatives, then fills the remaining budget with the
    normal hand-cost ranking.  The returned order is a policy prior: earlier
    actions should be expanded first, but every returned action remains legal.
    """
    if max_candidates <= 0 or not state.hands[player]:
        return []

    hand = state.hands[player]
    candidates = enumerate_legal_patterns(state, player)
    if not candidates:
        return []

    structure_cache: _StructureCache = {}
    before_structure = _cached_structure_score(hand, state.wild_card, structure_cache)
    min_opponent_cards = context_opponent_min_cards(state, player)

    def cost(pattern: Pattern) -> float:
        return _estimate_pattern_cost(
            state,
            player,
            pattern,
            before_structure=before_structure,
            structure_cache=structure_cache,
            opponent_min_cards=min_opponent_cards,
        )

    ranked = sorted(candidates, key=cost)
    selected: dict[object, Pattern] = {}

    def reserve(pattern: Pattern | None) -> None:
        if pattern is not None and len(selected) < max_candidates:
            selected.setdefault(pattern_key(pattern), pattern)

    # Terminal actions must never be hidden by pruning.
    reserve(next((p for p in ranked if len(p.cards) == len(hand)), None))
    reserve(
        min(
            ranked[:24],
            key=lambda p: (
                3.0 * estimate_remaining_plays(
                    remaining_cards(hand, p.cards), state.wild_card, state.level, width=12
                )
                + 0.13 * cost(p)
            ),
        )
    )
    reserve(ranked[0])

    non_bombs = [p for p in candidates if not is_bomb_pattern(p)]
    bombs = [p for p in candidates if is_bomb_pattern(p)]

    if non_bombs:
        # Best immediate hand reduction and strongest legal control play.
        reserve(min(non_bombs, key=lambda p: (-len(p.cards), cost(p))))
        reserve(
            max(
                non_bombs,
                key=lambda p: (
                    p.weight,
                    p.length,
                    comparison_rank(p, state.level),
                    -p.wild_used,
                ),
            )
        )

    if bombs:
        reserve(min(bombs, key=lambda p: (*bomb_strength(p, level=state.level), p.wild_used)))
        reserve(max(bombs, key=lambda p: (*bomb_strength(p, level=state.level), -p.wild_used)))

    if non_bombs:
        # Keep one low-cost representative per normal pattern family.
        for pattern_type in PatternType:
            same_type = [p for p in non_bombs if p.type == pattern_type]
            if same_type:
                reserve(min(same_type, key=cost))

    for pattern in ranked:
        reserve(pattern)
        if len(selected) >= max_candidates:
            break
    return list(selected.values())
