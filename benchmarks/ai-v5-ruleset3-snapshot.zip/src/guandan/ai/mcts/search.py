"""MCTS 主循环：Selection、Expansion、Simulation、Backpropagation。

标准 MCTS 四个阶段：
1. Selection: 从根节点用 UCB1 选择最优路径到叶子节点
2. Expansion: 扩展一个新子节点
3. Simulation: 从新节点快速玩到游戏结束（rollout）
4. Backpropagation: 将结果回传到路径上所有节点
"""
from __future__ import annotations

import copy
import math
import time
from collections import Counter
from typing import Optional

from ...engine.card import RANK_A, Card
from ...engine.hand import Pattern, PatternType, comparison_rank
from ...engine.rules.patterns import find_complete_pattern
from ...engine.rules.scoring import compute_level_change
from ...engine.state import (
    GameState,
    IllegalPlayError,
    is_teammate,
    partner_of,
    pass_turn,
    play_pattern,
    team_of,
)
from ...engine.trick import current_top_player
from ..candidates import enumerate_legal_patterns, greedy_pattern_key, is_bomb_pattern
from ..context import PublicTacticalContext, opponent_min_cards
from ..hand_plan import estimate_remaining_plays, remaining_cards
from ..valuation import enumerate_candidate_plays
from .node import MCTSNode


def ucb1_score(node: MCTSNode, parent_visits: int, c: float = 1.41) -> float:
    """计算 UCB1 分数。

    UCB1 = exploitation + exploration
         = win_rate + C * sqrt(ln(parent_visits) / node_visits)

    Args:
        node: 子节点
        parent_visits: 父节点的访问次数
        c: 探索常数（默认 sqrt(2) ≈ 1.41）

    Returns:
        UCB1 分数，越大越优先访问
    """
    if node.visits == 0:
        return float('inf')  # 未访问节点优先

    exploit = node.win_rate()
    explore = c * math.sqrt(math.log(parent_visits) / node.visits)
    return exploit + explore


def _select(node: MCTSNode, c: float, root_player: int | None = None) -> MCTSNode:
    """Selection: 用 UCB1 选择最优路径到叶子节点。

    从根节点出发，每次选择 UCB1 分数最高的子节点，
    直到：
    1. 到达未完全展开的节点，或
    2. 到达终局节点
    """
    while not node.is_terminal():
        if not node.is_fully_expanded():
            return node
        # 如果没有子节点，说明需要先展开
        if not node.children:
            return node
        if root_player is None or team_of(node.player) == team_of(root_player):
            node = max(
                node.children,
                key=lambda child: ucb1_score(child, node.visits, c),
            )
        else:
            # Opponents minimize the root team's result while retaining the
            # same exploration pressure.  The legacy perfect-information tree
            # remains correct for external callers even though the production
            # strategy now uses information-set search.
            node = max(
                node.children,
                key=lambda child: (
                    1.0 - child.win_rate()
                    + (
                        float("inf")
                        if child.visits == 0
                        else c * math.sqrt(math.log(node.visits) / child.visits)
                    )
                ),
            )
    return node


def _get_legal_actions(
    state: GameState, player: int, max_actions: int = 5
) -> list[Optional[Pattern]]:
    """获取合法动作列表。

    Args:
        state: 当前状态
        player: 当前玩家
        max_actions: 最多返回几个候选（剪枝）

    Returns:
        合法动作列表（None 表示过牌）
    """
    # 如果不是 leader，可以过牌
    actions: list[Optional[Pattern]] = []
    if state.table:
        actions.append(None)

    # 获取候选出牌
    candidates = enumerate_candidate_plays(state, player, max_candidates=max_actions)
    actions.extend(candidates[:max_actions])

    finish = _legal_finish_pattern(state, player)
    if finish is not None and finish not in actions:
        # _expand 从列表尾部 pop；终局动作放在末尾可在低迭代搜索中优先展开。
        actions.append(finish)

    return actions


def _expand(node: MCTSNode, max_actions: int) -> MCTSNode:
    """Expansion: 从 untried_actions 中选一个，创建新子节点。

    Args:
        node: 待扩展的节点
        max_actions: 最多考虑几个候选动作

    Returns:
        新创建的子节点
    """
    if not node.untried_actions:
        # 首次展开，初始化 untried_actions
        node.untried_actions = _get_legal_actions(
            node.state, node.player, max_actions=max_actions
        )

    if not node.untried_actions:
        return node  # 无可用动作

    # 弹出一个未尝试的动作
    action = node.untried_actions.pop()

    # 应用动作，生成新状态
    new_state = copy.deepcopy(node.state)
    try:
        if action is None:
            pass_turn(new_state, node.player)
        else:
            play_pattern(new_state, node.player, action)
    except IllegalPlayError:
        # 动作非法（理论上不应该发生），跳过
        return node

    # 创建子节点
    child = MCTSNode(
        state=new_state,
        player=new_state.current_player(),
        parent=node,
        action=action,
    )

    node.children.append(child)
    return child


def _simulate(
    node: MCTSNode,
    root_player: int,
    rollout_strategy_level: int,
    max_turns: int,
) -> float:
    """Simulation: 从 node 开始快速玩到游戏结束（rollout）。

    使用快速策略（如档1）玩到结束，评估结果。

    Args:
        node: 起始节点
        root_player: 根玩家（用于评估结果）
        rollout_strategy_level: rollout 策略档位（默认1）
        max_turns: 单次 rollout 最多模拟多少手

    Returns:
        从 root_player 视角的胜率（0.0 - 1.0）
    """
    return simulate_state(
        node.state,
        root_player,
        rollout_strategy_level=rollout_strategy_level,
        max_turns=max_turns,
    )


def simulate_state(
    state: GameState,
    root_player: int,
    *,
    rollout_strategy_level: int,
    max_turns: int,
    copy_state: bool = True,
    deadline: float | None = None,
) -> float:
    """Roll out a state and return its value from ``root_player``'s team view."""
    sim_state = copy.deepcopy(state) if copy_state else state

    # 用 rollout 策略玩到结束
    turn_count = 0

    while not sim_state.finished and turn_count < max_turns:
        if deadline is not None and time.perf_counter() >= deadline:
            break
        player = sim_state.current_player()
        pattern = _rollout_select_pattern(
            sim_state,
            player,
            rollout_strategy_level=rollout_strategy_level,
        )

        try:
            if pattern is None:
                pass_turn(sim_state, player)
            else:
                play_pattern(sim_state, player, pattern)
        except IllegalPlayError:
            # 策略返回非法动作，尝试过牌
            try:
                pass_turn(sim_state, player)
            except IllegalPlayError:
                # 无法过牌，游戏可能卡住，终止模拟
                break

        turn_count += 1

    # Higher-tier continuations use a hand-plan value at the cutoff. Once
    # head place is known, retain the exact ranking/level-aware value path.
    if rollout_strategy_level >= 2 and not sim_state.finish_order:
        return planned_position_value(sim_state, root_player, team_value=rollout_strategy_level >= 3)
    # 评估结果
    return _evaluate_result(sim_state, root_player)


def _rollout_select_pattern(
    state: GameState,
    player: int,
    *,
    rollout_strategy_level: int,
) -> Optional[Pattern]:
    """MCTS rollout 的轻量出牌策略。

    Rollout 会在搜索中被调用很多次；领出、复杂响应及短手牌会枚举完整
    牌型，普通响应保留基础牌型快路径，并按局势让队友或保留炸弹。
    """
    finish = _legal_finish_pattern(state, player, max_cards=10)
    if finish is not None:
        return finish

    context = PublicTacticalContext.from_state(state, player) if rollout_strategy_level >= 3 else None
    if (
        context is not None and state.table and context.top_player == context.partner
        and not context.partner_needs_cover()
    ):
        if state.hand_size(context.partner) >= state.hand_size(player) + 5:
            return _structured_rollout_pattern(state, player, context=context, takeover_only=True)
        return None

    if context is None and rollout_strategy_level >= 1 and state.table:
        top_player = current_top_player(state)
        if (
            top_player is not None
            and is_teammate(top_player, player)
            and opponent_min_cards(state, player) != 1
        ):
            if state.hand_size(top_player) >= state.hand_size(player) + 5:
                takeover = _structured_rollout_pattern(state, player)
                if (
                    takeover is not None
                    and not is_bomb_pattern(takeover)
                    and len(takeover.cards) >= 4
                    and state.hand_size(player) - len(takeover.cards) <= 3
                ):
                    return takeover
            return None

    # A complete but bounded policy is affordable in the middle/end game and
    # keeps rollout behaviour representative of actual play.  Large hidden
    # hands retain the specialized fast path to protect the search budget.
    table_top = state.table[-1] if state.table else None
    complex_response = table_top is not None and table_top.type not in (
        PatternType.SINGLE,
        PatternType.PAIR,
        PatternType.TRIPLE,
    )
    # Normal production rollouts must be able to shed real structures, rather
    # than only singles/pairs/triples.  Keep the full enumeration to leads,
    # complex responses and short hands to protect the search budget.
    if rollout_strategy_level >= 1 and (
        not state.table or state.hand_size(player) <= 10 or complex_response
        or (context is not None and opponent_min_cards(state, player) <= 3)
    ):
        structured = _structured_rollout_pattern(state, player, context=context)
        if structured is not None:
            return structured
        if state.table:
            return None
    if state.table and opponent_min_cards(state, player) > 5:
        basic = _smallest_rollout_pattern(state, player)
        if basic is not None and is_bomb_pattern(basic):
            return None
        return basic
    return _smallest_rollout_pattern(state, player)


def _structured_rollout_pattern(
    state: GameState, player: int, *, context: PublicTacticalContext | None = None,
    takeover_only: bool = False,
) -> Optional[Pattern]:
    """One-pass full-pattern policy for complex responses and short hands."""
    candidates = enumerate_legal_patterns(state, player)
    if takeover_only:
        if context is None:
            return None
        candidates = [p for p in candidates if context.can_takeover_in_two(
            p, remaining_cards(state.hands[player], p.cards),
        )]
    if not candidates:
        return None
    non_bombs = [pattern for pattern in candidates if not is_bomb_pattern(pattern)]
    if non_bombs or context is not None:
        counts = Counter(card.rank for card in state.hands[player])
        urgency = opponent_min_cards(state, player)

        def cost(pattern: Pattern) -> float:
            value = _rollout_material_cost(pattern, counts, state.level, urgency)
            if context is not None:
                value += context.lead_adjustment(pattern) if not state.table else 12.0 * context.finish_risk(pattern)
                if is_bomb_pattern(pattern):
                    value += 3.5 if urgency > 5 else 1.2
                if not state.table and state.hand_size(player) <= 10:
                    rest = remaining_cards(state.hands[player], pattern.cards)
                    if find_complete_pattern(list(rest), state.wild_card) is not None:
                        response = max((context.response_risk(pattern, seat) for seat in context.opponents), default=0.0)
                        value -= 2.5 * (1.0 - response)
            return value

        return min(
            candidates if context is not None and (not state.table or urgency <= 5) else non_bombs or candidates,
            key=cost,
        )
    if state.table and opponent_min_cards(state, player) > 5:
        return None
    return min(
        candidates,
        key=lambda pattern: greedy_pattern_key(pattern, state.level),
    )


def _rollout_material_cost(
    pattern: Pattern, before: Counter[int], level: int, urgency: int
) -> float:
    """Cheap grouping preservation without a recursive planner per rollout."""
    used = Counter(card.rank for card in pattern.cards)
    cost = -0.85 * len(pattern.cards) + 2.5 * pattern.wild_used
    for rank, count in used.items():
        rest = before[rank] - count
        if rest == 0:
            continue
        if before[rank] >= 4:
            cost += 5.0
        elif before[rank] >= 2 and rest == 1:
            cost += 1.8
        elif before[rank] == 3 and rest == 2:
            cost += 1.2
    strength = comparison_rank(pattern, level)
    if urgency == 1 and pattern.type == PatternType.SINGLE:
        cost -= 0.16 * strength
    else:
        cost += 0.035 * strength
    return cost


def _legal_finish_pattern(
    state: GameState,
    player: int,
    *,
    max_cards: Optional[int] = None,
) -> Optional[Pattern]:
    hand = state.hands[player]
    if not hand:
        return None
    if max_cards is not None and len(hand) > max_cards:
        return None
    finish = find_complete_pattern(hand, state.wild_card)
    if finish is None:
        return None
    if state.table and not finish.can_be_played_on(state.table[-1], level=state.level):
        return None
    return finish


def _smallest_rollout_pattern(state: GameState, player: int) -> Optional[Pattern]:
    """rollout 专用快速候选：只枚举低成本基础牌型，必要时找炸弹。"""
    hand = state.hands[player]
    if not hand:
        return None

    table_top = state.table[-1] if state.table else None
    if table_top is None:
        return _smallest_basic_pattern(hand, state.wild_card, state.level)

    same_type = [
        pattern
        for pattern in _basic_patterns(hand, state.wild_card)
        if pattern.type == table_top.type
        and pattern.length == table_top.length
        and pattern.can_be_played_on(table_top, level=state.level)
    ]
    if same_type:
        counts = Counter(card.rank for card in hand)
        urgency = opponent_min_cards(state, player)
        return min(
            same_type,
            key=lambda p: _rollout_material_cost(p, counts, state.level, urgency),
        )

    bombs = [
        pattern
        for pattern in _fast_bomb_patterns(hand, state.wild_card)
        if pattern.can_be_played_on(table_top, level=state.level)
    ]
    if bombs:
        return min(bombs, key=lambda p: _rollout_pattern_key(p, state.level))
    return None


def _smallest_basic_pattern(
    hand: list[Card],
    wild_card: Optional[Card],
    level: int,
) -> Optional[Pattern]:
    basics = _basic_patterns(hand, wild_card)
    if basics:
        return min(basics, key=lambda p: _rollout_pattern_key(p, level))
    bombs = _fast_bomb_patterns(hand, wild_card)
    return min(bombs, key=lambda p: _rollout_pattern_key(p, level), default=None)


def _rollout_pattern_key(pattern: Pattern, level: int) -> tuple[int, int, int, int]:
    return (
        pattern.weight,
        pattern.length,
        comparison_rank(pattern, level),
        pattern.wild_used,
    )


def _basic_patterns(hand: list[Card], wild_card: Optional[Card]) -> list[Pattern]:
    """快速生成单张/对子/三张，供 rollout 近似使用。"""
    wild_cards = _wild_cards_in(hand, wild_card)
    wild_count = len(wild_cards)
    normal = [card for card in hand if wild_card is None or card != wild_card]
    by_rank: dict[int, list[Card]] = {}
    for card in normal:
        by_rank.setdefault(card.rank, []).append(card)

    patterns: list[Pattern] = [
        Pattern(type=PatternType.SINGLE, rank=card.rank, length=1, cards=(card,))
        for card in normal
    ]
    if wild_count >= 1 and wild_card is not None:
        patterns.append(
            Pattern(
                type=PatternType.SINGLE,
                rank=wild_card.rank,
                length=1,
                cards=(wild_cards[0],),
                wild_used=1,
            )
        )

    for rank, cards in by_rank.items():
        if len(cards) >= 2:
            patterns.append(
                Pattern(type=PatternType.PAIR, rank=rank, length=1, cards=tuple(cards[:2]))
            )
        if len(cards) >= 3 and not cards[0].is_joker:
            patterns.append(
                Pattern(type=PatternType.TRIPLE, rank=rank, length=1, cards=tuple(cards[:3]))
            )
        if wild_count >= 1 and wild_card is not None and not cards[0].is_joker:
            if len(cards) >= 1:
                patterns.append(
                    Pattern(
                        type=PatternType.PAIR,
                        rank=rank,
                        length=1,
                        cards=(cards[0], wild_cards[0]),
                        wild_used=1,
                    )
                )
            if len(cards) >= 2:
                patterns.append(
                    Pattern(
                        type=PatternType.TRIPLE,
                        rank=rank,
                        length=1,
                        cards=(cards[0], cards[1], wild_cards[0]),
                        wild_used=1,
                    )
                )
        if (
            wild_count >= 2
            and wild_card is not None
            and len(cards) >= 1
            and not cards[0].is_joker
        ):
            patterns.append(
                Pattern(
                    type=PatternType.TRIPLE,
                    rank=rank,
                    length=1,
                    cards=(cards[0], wild_cards[0], wild_cards[1]),
                    wild_used=2,
                )
            )

    if wild_count >= 2 and wild_card is not None:
        patterns.append(
            Pattern(
                type=PatternType.PAIR,
                rank=wild_card.rank,
                length=1,
                cards=(wild_cards[0], wild_cards[1]),
                wild_used=2,
            )
        )
    if wild_count >= 3 and wild_card is not None:
        patterns.append(
            Pattern(
                type=PatternType.TRIPLE,
                rank=wild_card.rank,
                length=1,
                cards=(wild_cards[0], wild_cards[1], wild_cards[2]),
                wild_used=3,
            )
        )
    return patterns


def _fast_bomb_patterns(hand: list[Card], wild_card: Optional[Card]) -> list[Pattern]:
    """快速生成普通炸弹和四王炸，供 rollout 兜底使用。"""
    wild_cards_available = _wild_cards_in(hand, wild_card)
    wild_count = len(wild_cards_available)
    normal = [card for card in hand if wild_card is None or card != wild_card]
    by_rank: dict[int, list[Card]] = {}
    for card in normal:
        if not card.is_joker:
            by_rank.setdefault(card.rank, []).append(card)
    patterns: list[Pattern] = []

    big_jokers = [card for card in normal if card.is_big_joker]
    small_jokers = [card for card in normal if card.is_small_joker]
    if len(big_jokers) >= 2 and len(small_jokers) >= 2:
        patterns.append(
            Pattern(
                type=PatternType.FOUR_JOKERS,
                rank=max(card.rank for card in [*big_jokers[:2], *small_jokers[:2]]),
                length=4,
                cards=tuple([*big_jokers[:2], *small_jokers[:2]]),
            )
        )

    for rank, same_rank in by_rank.items():
        for natural_count in range(min(len(same_rank), 10), 0, -1):
            needed_wild = max(0, 4 - natural_count)
            total = natural_count + needed_wild
            if total < 4 or total > 10 or needed_wild > wild_count:
                continue
            wild_cards = wild_cards_available[:needed_wild]
            patterns.append(
                Pattern(
                    type=PatternType.BOMB,
                    rank=rank,
                    length=total,
                    cards=tuple([*same_rank[:natural_count], *wild_cards]),
                    wild_used=needed_wild,
                )
            )
            break
    return patterns


def _wild_cards_in(hand: list[Card], wild_card: Optional[Card]) -> list[Card]:
    if wild_card is None:
        return []
    return [card for card in hand if card == wild_card]


def _evaluate_result(state: GameState, root_player: int) -> float:
    """返回根队的 0..1 收益值，兼顾获胜和升级。

    未定头游时使用局面模型；头游已定时，只估算剩余名次与升级收益，
    不再让手牌张数把已定的获胜方反转。
    """
    if not state.finish_order:
        return _evaluate_unfinished(state, root_player)

    if state.finished:
        root_team = team_of(root_player)
        if state.match_finished and state.winner_team is not None:
            return 1.0 if state.winner_team == root_team else 0.0

        full_order = list(state.finish_order)
        full_order.extend(player for player in range(4) if player not in full_order)
        head, second, third, last = full_order[:4]
        if state.team_levels[team_of(head)] == RANK_A:
            # Taking head place is not an A pass when the partner is last.
            # The first two failed attempts stay at A; the third resets to 2.
            head_succeeded = last != partner_of(head)
            return float(head_succeeded == is_teammate(head, root_player))
        deltas = compute_level_change(
            head, second, third, last, state.team_bomb_count
        )
        my_team = root_team
        opponent_team = 1 - my_team
        # 升级差只有三种取值(-3/0/+3 等)，压缩成窄带会让搜索分不清"升 1 级"
        # 和"升 3 级"。按真实收益放大：+3 是双下，收益远大于 +1。
        # The ±0.10 head bonus already encodes "won the round", so only the
        # level-delta term is stretched: without it a +1 and a +3 round are
        # nearly indistinguishable, and the whole signal stays too narrow to
        # outweigh UCB1's exploration term.
        score = 0.5 + (deltas[my_team] - deltas[opponent_team]) * _TERMINAL_LEVEL_GAIN
        if is_teammate(head, root_player):
            score += 0.10
        else:
            score -= 0.10

        final_levels = state.team_levels_final or state.team_levels
        if len(final_levels) == 2:
            if final_levels[my_team] == RANK_A:
                score += 0.04
            if final_levels[opponent_team] == RANK_A:
                score -= 0.04
        return max(0.0, min(1.0, score))

    return _evaluate_placed_race(state, root_player)


def _evaluate_placed_race(state: GameState, root_player: int) -> float:
    """Respect the irreversible head-place result in a truncated continuation.

    After head place, the only uncertainty is the partner's finishing place
    (and therefore the level gain).  A generic card-count model can otherwise
    prefer the losing team when its two players both have short hands.
    """
    head = state.finish_order[0]
    root_won_head = is_teammate(head, root_player)
    if len(state.finish_order) >= 2 and is_teammate(head, state.finish_order[1]):
        return 1.0 if root_won_head else 0.0

    remaining = [seat for seat in range(4) if seat not in state.finish_order]
    plans = {
        seat: estimate_remaining_plays(
            state.hands[seat], state.wild_card, state.level, width=6
        )
        for seat in remaining
    }

    def finishes_before(first: int, second: int) -> float:
        difference = max(-20.0, min(20.0, plans[first] - plans[second]))
        return 1.0 / (1.0 + math.exp(difference))

    if state.team_levels[team_of(head)] == RANK_A:
        partner = partner_of(head)
        last_chance = math.prod(
            1.0 - finishes_before(partner, seat)
            for seat in remaining if seat != partner
        )
        return 1.0 - last_chance if root_won_head else last_chance

    own = [seat for seat in remaining if is_teammate(seat, root_player)]
    opponents = [seat for seat in remaining if not is_teammate(seat, root_player)]
    if len(remaining) == 2:
        chance = finishes_before(own[0], opponents[0])
        return (23.0 / 30.0 if root_won_head else 1.0 / 15.0) + chance / 6.0
    if root_won_head:
        first, second = (finishes_before(own[0], opponent) for opponent in opponents)
        second_place = first * second
        last_place = (1.0 - first) * (1.0 - second)
        third_place = 1.0 - second_place - last_place
        return second_place + third_place * 14.0 / 15.0 + last_place * 23.0 / 30.0
    first, second = (finishes_before(seat, opponents[0]) for seat in own)
    last_place = first * second
    second_place = (1.0 - first) * (1.0 - second)
    third_place = 1.0 - second_place - last_place
    return last_place * 7.0 / 30.0 + third_place / 15.0


# Add 1/6 per level to the neutral value, then apply the head-place bonus.
# A one-level win is about 0.767, a two-level win 0.933, and a double-down 1.0.
_TERMINAL_LEVEL_GAIN = 1.0 / 6.0

# Logistic weights for the unfinished-position value, fitted by gradient descent
# on 632 real positions labelled by playing each one out under the rollout
# policy. 5-fold cross-validated log loss 0.573 against a 0.693 baseline.
#
# Features, in order:
#   card_diff  (opponent cards - own cards) / total   -- fewer cards is better
#   out_bal    own finishers - opponent finishers     -- irreversible progress
#   control_adv normalised joker/level/bomb strength  -- who controls the end
#   lead       1.0 when the root team holds the trick
#
# `lead` is *negative*: holding a trick while behind on cards and control is a
# bad sign, so the previous constant of +0.035 had the opposite sign to the data.
#
# Two further features were fitted and then dropped because their coefficients
# were ~0 (`opp_danger` -0.05, `round_progress` +0.11).
_POSITION_VALUE_WEIGHTS = (
    1.858,   # card_diff
    3.198,   # out_bal
    1.219,   # control_adv
    -0.370,  # lead
)
_POSITION_VALUE_INTERCEPT = 0.227


def _evaluate_unfinished(state: GameState, root_player: int) -> float:
    """rollout 未完成时的局面胜率估计（拟合模型）。"""
    weights = _POSITION_VALUE_WEIGHTS
    logit = _POSITION_VALUE_INTERCEPT
    for index, feature in enumerate(_position_features(state, root_player)):
        logit += weights[index] * feature
    logit = max(-30.0, min(30.0, logit))
    return 1.0 / (1.0 + math.exp(-logit))


def planned_position_features(state: GameState, root_player: int) -> tuple[float, ...]:
    """Sampled-world race features, accounting for groups rather than card count alone.

    This evaluator is only used on determinized continuation states. Every
    feature changes sign when the two teams are exchanged.
    """
    plans = [
        estimate_remaining_plays(hand, state.wild_card, state.level, width=6)
        for hand in state.hands
    ]
    own = [plans[seat] for seat in range(4) if is_teammate(seat, root_player)]
    other = [plans[seat] for seat in range(4) if not is_teammate(seat, root_player)]
    race = (min(other) - min(own)) / max(1.0, min(other) + min(own))
    support = (sum(other) - sum(own)) / max(1.0, sum(other) + sum(own))
    cards, _, control, _ = _position_features(state, root_player)
    top = current_top_player(state)
    lead = 0.0 if top is None else 1.0 if is_teammate(top, root_player) else -1.0
    turn = 1.0 if is_teammate(state.current_player(), root_player) else -1.0
    progress = 1.0 - sum(map(len, state.hands)) / 108.0
    own_level = state.team_levels[team_of(root_player)]
    other_level = state.team_levels[1 - team_of(root_player)]
    a_round = float(own_level == RANK_A or other_level == RANK_A)
    return (
        race, support, cards, control, lead, turn, race * progress, control * progress,
        (own_level - other_level) / 12.0, race * a_round, support * a_round,
    )


# Fitted on 576 complete sampled deals, holding out a separate 192 deals
# across 2/9/A and all starting seats. Soft-target log loss: 0.6002 versus
# 0.6879 for the old value and 0.6618 after refitting without hand-plan features.
# See scripts/fit_ai_value.py and benchmarks/ai-ladder-planned-value-fit.json.
_PLANNED_VALUE_WEIGHTS = (
    0.7596602735220546,
    3.4928646496811773,
    -2.063790535396573,
    1.626351985134949,
    0.17329406060248678,
    0.005424167641161714,
    1.6269419776540262,
    -0.1569959244228077,
)

# Fitted on 576 whole deals, 192 independent holdout deals (90000..90767),
# using the public team-aware continuation and corrected A-round utility.
# Features 8..10 add level difference and A-round race/support interactions.
# See benchmarks/ai-team-value-fit-v3.json. Used only by experimental level-3
# continuations until the separately declared paired strength gate passes.
_TEAM_VALUE_WEIGHTS = (
    1.3828467791648302, 3.104752911551853, -2.149251371612721,
    1.037728158662135, 0.12812715777954006, 0.12993121598476276,
    0.8064204940229135, -0.17850848204963007, 0.0,
    -0.22276735533081174, 0.6544864600877628,
)


def planned_position_value(state: GameState, root_player: int, *, team_value: bool = False) -> float:
    """Calibrated symmetric team utility for an unfinished sampled world."""
    logit = sum(
        weight * feature
        for weight, feature in zip(
            _TEAM_VALUE_WEIGHTS if team_value else _PLANNED_VALUE_WEIGHTS,
            planned_position_features(state, root_player),
        )
    )
    return 1.0 / (1.0 + math.exp(-max(-30.0, min(30.0, logit))))


def _position_features(state: GameState, root_player: int) -> tuple[float, float, float, float]:
    """The four features the position model consumes."""
    my_cards = sum(
        state.hand_size(player)
        for player in range(4)
        if is_teammate(player, root_player) and player not in state.finish_order
    )
    opponent_cards = sum(
        state.hand_size(player)
        for player in range(4)
        if not is_teammate(player, root_player) and player not in state.finish_order
    )
    total = my_cards + opponent_cards
    card_diff = (opponent_cards - my_cards) / total if total else 0.0

    out_bal = float(
        sum(1 if is_teammate(player, root_player) else -1 for player in state.finish_order)
    )

    root_team = team_of(root_player)
    opponent_team = 1 - root_team
    mine = _team_control_strength(state, root_team)
    theirs = _team_control_strength(state, opponent_team)
    control_total = mine + theirs
    control_adv = (mine - theirs) / control_total if control_total else 0.0

    top_player = current_top_player(state)
    lead = 1.0 if (top_player is not None and is_teammate(top_player, root_player)) else 0.0

    return card_diff, out_bal, control_adv, lead


def _team_control_strength(state: GameState, team: int) -> float:
    """Cheap sampled-world estimate of remaining control cards and bombs."""
    strength = 0.0
    for player in range(4):
        if team_of(player) != team or player in state.finish_order:
            continue
        hand = state.hands[player]
        rank_counts = Counter(card.rank for card in hand if not card.is_joker)
        for card in hand:
            if card.is_big_joker:
                strength += 2.5
            elif card.is_small_joker:
                strength += 1.7
            elif card.rank == state.level:
                strength += 1.0
            elif card.rank == RANK_A:
                strength += 0.45
        strength += sum(max(0, count - 3) * 1.4 for count in rank_counts.values())
    return strength


def _backpropagate(node: MCTSNode, result: float) -> None:
    """Backpropagation: 将结果回传到路径上所有节点。

    Args:
        node: 起始节点
        result: 模拟结果（0.0 - 1.0）
    """
    current: Optional[MCTSNode] = node
    while current is not None:
        current.visits += 1
        current.wins += result
        current = current.parent


def mcts_search(
    root: MCTSNode,
    iterations: int = 200,
    ucb_c: float = 1.41,
    max_actions: int = 5,
    rollout_strategy: int = 1,
    rollout_max_turns: int = 80,
) -> Optional[MCTSNode]:
    """MCTS 主循环。

    Args:
        root: 根节点
        iterations: 迭代次数
        ucb_c: UCB1 探索常数
        max_actions: 每个节点考虑的最大候选动作数
        rollout_strategy: rollout 策略档位
        rollout_max_turns: 单次 rollout 最多模拟多少手

    Returns:
        最佳子节点（访问次数最多）
    """
    root_player = root.player

    for _ in range(iterations):
        # 1. Selection
        node = _select(root, ucb_c, root_player)

        # 2. Expansion
        if not node.is_terminal():
            node = _expand(node, max_actions)

        # 3. Simulation
        result = _simulate(node, root_player, rollout_strategy, rollout_max_turns)

        # 4. Backpropagation
        _backpropagate(node, result)

    # 返回访问次数最多的子节点
    if not root.children:
        return None

    return max(root.children, key=lambda c: c.visits)
