"""Small-deal, deadline-bounded team search over sampled hidden worlds."""
from __future__ import annotations

import math
import random
import time
from dataclasses import dataclass, field

from ...engine.hand import Pattern
from ...engine.state import GameState, clone_state_for_search, team_of
from ...engine.trick import current_top_player
from ..candidates import enumerate_exact_small_hand_patterns, pattern_key
from ..context import PublicTacticalContext
from ..tactics import select_heuristic_action
from .determinize import determinize
from .information_set import PASS_ACTION, ActionKey, ActionStatistics, _apply_action
from .search import _evaluate_result


class _OutOfTime(Exception):
    pass


class _DepthLimit(_OutOfTime):
    pass


class _Unsolved:
    pass


@dataclass
class _Budget:
    deadline: float
    nodes_left: int
    cache: dict[tuple, float] = field(default_factory=dict)

    def consume(self) -> None:
        if self.nodes_left <= 0 or time.perf_counter() >= self.deadline:
            raise _OutOfTime
        self.nodes_left -= 1


def _key(state: GameState, depth: int) -> tuple:
    return (
        tuple(tuple(sorted(hand)) for hand in state.hands),
        tuple(state.table),
        tuple(sorted(state.passed_players)),
        state.turn_index,
        state.leader,
        current_top_player(state),
        tuple(state.finish_order),
        state.level, state.wild_card, tuple(state.team_levels),
        tuple(state.a_failure_counts), state.ruleset_version,
        depth,
    )


def _actions(state: GameState, player: int) -> list[Pattern | None]:
    candidates: dict[tuple, Pattern] = {}
    for pattern in enumerate_exact_small_hand_patterns(state, player):
        candidates.setdefault(pattern_key(pattern), pattern)
    actions: list[Pattern | None] = list(candidates.values())
    actions.sort(
        key=lambda p: (
            p is None or len(p.cards) != state.hand_size(player),
            -len(p.cards) if p is not None else 0,
        )
    )
    if state.table:
        actions.append(None)
    return actions


def _minimax(
    state: GameState,
    root_player: int,
    depth: int,
    budget: _Budget,
    alpha: float,
    beta: float,
) -> float:
    budget.consume()
    if state.finished:
        return _evaluate_result(state, root_player)
    if depth <= 0:
        # A heuristic leaf is not a solved game. Even a future caller using
        # too small a depth must not accidentally get an "exact" result.
        raise _DepthLimit
    key = _key(state, depth)
    cached = budget.cache.get(key)
    if cached is not None:
        return cached
    player = state.current_player()
    maximizing = team_of(player) == team_of(root_player)
    original_alpha, original_beta = alpha, beta
    value = 0.0 if maximizing else 1.0
    cut = False
    for action in _actions(state, player):
        child = clone_state_for_search(state)
        if not _apply_action(child, player, action):
            continue
        result = _minimax(child, root_player, depth - 1, budget, alpha, beta)
        if maximizing:
            value = max(value, result)
            alpha = max(alpha, value)
        else:
            value = min(value, result)
            beta = min(beta, value)
        if beta <= alpha:
            cut = True
            break
    # A fail-low result can be an upper bound even without a local cutoff:
    # its descendants may have pruned against the inherited alpha.  Only
    # reuse exact values, never such bounds in another search window.
    if not cut and original_alpha < value < original_beta:
        budget.cache[key] = value
    return value


@dataclass(frozen=True)
class EndgameSearchResult:
    pattern: Pattern | None
    actions: tuple[ActionStatistics, ...]
    common_samples: int
    nodes: int
    elapsed_seconds: float
    complete: bool
    exact: bool
    reason: str


def search_endgame(
    state: GameState,
    player: int,
    *,
    rng: random.Random,
    deadline: float,
    max_actions: int = 10,
    worlds: int = 8,
    min_worlds: int = 6,
    max_nodes: int = 30000,
    confidence_guard: bool = True,
    team_tactics: bool = True,
) -> EndgameSearchResult:
    """Compare terminal team values on common worlds, not heuristic leaves.

    Every root action is evaluated in the same independently sampled worlds.
    Full-information minimax is confined to those hypothetical worlds; the
    actual hands of the other players are never read.
    """
    if min(worlds, min_worlds, max_nodes, max_actions) <= 0:
        raise ValueError("endgame limits must be positive")
    if player != state.current_player():
        raise ValueError("endgame player is not to act")
    started = time.perf_counter()
    actions = _actions(state, player)
    reference = select_heuristic_action(state, player, 2, team_tactics=team_tactics)
    def key_of(action: Pattern | None) -> ActionKey:
        return PASS_ACTION if action is None else pattern_key(action)
    reference_index = next((i for i, action in enumerate(actions) if key_of(action) == key_of(reference)), 0)
    context = PublicTacticalContext.from_state(state, player)
    exact = (
        len(context.unseen) == sum(context.sizes[seat] for seat in range(4) if seat != player)
        and sum(context.sizes[seat] > len(context.known[seat]) for seat in range(4) if seat != player) <= 1
    )
    values: list[list[float]] = [[] for _ in actions]
    budget = _Budget(deadline=deadline, nodes_left=max_nodes)
    reason = "sampled"
    try:
        for _ in range(1 if exact else worlds):
            budget.consume()
            sampled = determinize(state, player, rng)
            round_values = []
            for action in actions:
                child = clone_state_for_search(sampled)
                if not _apply_action(child, player, action):
                    raise ValueError("invalid endgame root action")
                # At most three passes can separate card-removing plays;
                # this bound therefore reaches every possible terminal path.
                round_values.append(_minimax(child, player, 4 * sum(map(len, child.hands)) + 4, budget, 0.0, 1.0))
            for index, value in enumerate(round_values):
                values[index].append(value)
    except _DepthLimit:
        reason = "depth_limit"
    except _OutOfTime:
        reason = "budget_limited"
    except ValueError:
        reason = "invalid_public_state"
    common = min(map(len, values), default=0)

    def error(index: int) -> float | None:
        if common < 2:
            return None
        differences = [a - b for a, b in zip(values[index], values[reference_index])]
        mean = sum(differences) / common
        return math.sqrt(sum((d - mean) ** 2 for d in differences) / (common * (common - 1)))

    stats = tuple(ActionStatistics(
        action_key=key_of(action), pattern=action, visits=common, availability=common,
        mean_value=sum(values[index]) / common if common else 0.5, prior=1.0,
        reference_key=key_of(actions[reference_index]), paired_standard_error=error(index),
    ) for index, action in enumerate(actions))
    complete = bool(actions) and common >= (1 if exact else min_worlds)
    chosen = max(range(len(actions)), key=lambda i: (stats[i].mean_value, i == reference_index), default=reference_index)
    if complete and confidence_guard and not exact and chosen != reference_index:
        required = max(0.04, 1.64 * (error(chosen) or 0.0))
        if stats[chosen].mean_value - stats[reference_index].mean_value < required:
            chosen = reference_index
            reason = "tactical_guard"
    return EndgameSearchResult(
        actions[chosen] if actions else reference, stats, common,
        max_nodes - budget.nodes_left, time.perf_counter() - started,
        complete, exact and complete, "exact" if exact and complete else reason,
    )


def solve_endgame(
    state: GameState, player: int, *, rng: random.Random, deadline: float,
    max_actions: int = 10, worlds: int = 8, min_worlds: int = 6, max_nodes: int = 30000,
    confidence_guard: bool = True, team_tactics: bool = True,
    reports: list[EndgameSearchResult] | None = None,
) -> Pattern | _Unsolved | None:
    """Compatibility action API; reports distinguish sampling from exact play."""
    result = search_endgame(
        state, player, rng=rng, deadline=deadline, max_actions=max_actions,
        worlds=worlds, min_worlds=min_worlds, max_nodes=max_nodes,
        confidence_guard=confidence_guard, team_tactics=team_tactics,
    )
    if reports is not None:
        reports.append(result)
    return result.pattern if result.complete else UNSOLVED


UNSOLVED = _Unsolved()
