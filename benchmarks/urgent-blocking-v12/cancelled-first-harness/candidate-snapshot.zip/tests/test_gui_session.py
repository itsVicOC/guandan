"""GUI/shared session regressions."""
from __future__ import annotations

import importlib.util
import json
import os
import random
import subprocess
import sys
from contextlib import contextmanager
from pathlib import Path
from typing import Any
from unittest.mock import patch

import pytest

from guandan.engine.card import (
    RANK_2,
    RANK_3,
    RANK_4,
    RANK_5,
    RANK_6,
    RANK_7,
    RANK_8,
    RANK_A,
    RANK_BIG_JOKER,
    RANK_K,
    RANK_SMALL_JOKER,
    Card,
    Suit,
)
from guandan.engine.events import TributeResisted, TributeReturned, TributeSent
from guandan.engine.hand import Pattern, PatternType, sort_cards
from guandan.engine.state import GameState, pass_turn, play_pattern
from guandan.storage import (
    begin_settlement,
    history_exists,
    reconcile_settlements,
)
from guandan.ui.session import GameSession


def _profile_transaction(profile: dict):
    def update(mutator):
        return mutator(profile)

    return update


def test_session_selects_duplicate_jokers_by_position() -> None:
    state = GameState(
        level=2,
        wild_card=None,
        hands=[
            [
                Card(RANK_BIG_JOKER, Suit.BIG_JOKER),
                Card(RANK_BIG_JOKER, Suit.BIG_JOKER),
                Card(RANK_8, Suit.CLUBS),
            ],
            [],
            [],
            [],
        ],
        turn_index=0,
        leader=0,
    )
    session = GameSession(difficulty=0, existing_state=state, human=0)
    hand = sort_cards(state.hands[0])

    result = session.play_human_cards(hand[:2])

    assert result.ok
    assert len(state.hands[0]) == 1
    assert state.table[-1].type == PatternType.PAIR
    assert len(state.table[-1].cards) == 2


def test_session_accepts_natural_level_card_in_two_to_six_straight() -> None:
    wild = Card(RANK_5, Suit.HEARTS)
    selected = [
        Card(RANK_5, Suit.CLUBS),
        Card(RANK_6, Suit.HEARTS),
        Card(RANK_4, Suit.SPADES),
        Card(RANK_3, Suit.HEARTS),
        Card(RANK_2, Suit.CLUBS),
    ]
    state = GameState(
        level=RANK_5,
        wild_card=wild,
        hands=[list(selected), [], [], []],
        turn_index=0,
        leader=0,
    )

    result = GameSession(
        difficulty=0,
        existing_state=state,
        human=0,
    ).play_human_cards(selected)

    assert result.ok
    assert state.table[-1].type == PatternType.STRAIGHT
    assert state.table[-1].rank == RANK_6
    assert state.table[-1].wild_used == 0


def test_gui_display_sort_places_level_between_jokers_and_ace() -> None:
    if importlib.util.find_spec("PySide6") is None:
        pytest.skip("PySide6 is not installed")
    from guandan.gui.cards import sort_cards_for_display

    cards = [
        Card(RANK_2, Suit.HEARTS),
        Card(RANK_2, Suit.CLUBS),
        Card(RANK_A, Suit.HEARTS),
        Card(RANK_K, Suit.SPADES),
        Card(RANK_BIG_JOKER, Suit.BIG_JOKER),
        Card(RANK_SMALL_JOKER, Suit.SMALL_JOKER),
    ]

    displayed = sort_cards_for_display(cards, level=RANK_2)

    assert displayed == [
        Card(RANK_BIG_JOKER, Suit.BIG_JOKER),
        Card(RANK_SMALL_JOKER, Suit.SMALL_JOKER),
        Card(RANK_2, Suit.CLUBS),
        Card(RANK_2, Suit.HEARTS),
        Card(RANK_A, Suit.HEARTS),
        Card(RANK_K, Suit.SPADES),
    ]


def test_gui_display_sort_handles_other_level_and_ace_level() -> None:
    if importlib.util.find_spec("PySide6") is None:
        pytest.skip("PySide6 is not installed")
    from guandan.gui.cards import sort_cards_for_display

    cards = [
        Card(RANK_A, Suit.HEARTS),
        Card(RANK_5, Suit.CLUBS),
        Card(RANK_5, Suit.HEARTS),
        Card(RANK_K, Suit.SPADES),
        Card(RANK_BIG_JOKER, Suit.BIG_JOKER),
    ]

    assert [card.rank for card in sort_cards_for_display(cards, level=RANK_5)] == [
        RANK_BIG_JOKER,
        RANK_5,
        RANK_5,
        RANK_A,
        RANK_K,
    ]
    assert [card.rank for card in sort_cards_for_display(cards, level=RANK_A)] == [
        RANK_BIG_JOKER,
        RANK_A,
        RANK_K,
        RANK_5,
        RANK_5,
    ]


def test_session_visual_seats_match_east_perspective() -> None:
    session = GameSession(difficulty=0, human=0)

    assert session.visual_seats() == {
        "left": 1,
        "opposite": 2,
        "right": 3,
    }


def test_partner_hand_reveals_after_going_out_and_hides_for_next_round() -> None:
    partner_card = Card(RANK_7, Suit.CLUBS)
    state = GameState(
        level=RANK_2,
        wild_card=None,
        hands=[
            [Card(RANK_3, Suit.HEARTS)],
            [Card(RANK_4, Suit.SPADES)],
            [partner_card],
            [Card(RANK_5, Suit.DIAMONDS)],
        ],
        turn_index=0,
        leader=0,
    )
    session = GameSession(difficulty=0, existing_state=state, human=0)
    assert session.visible_partner_hand() is None

    state.hands[0].clear()
    state.finish_order.append(0)
    assert session.visible_partner_hand() == (partner_card,)

    state.finished = True
    state.finish_order.extend((1, 3))
    state.team_levels_final = [3, 2]
    session.game_saved = True
    assert session.prepare_next_game().ok
    assert session.visible_partner_hand() is None

    session.cancel_next_game()
    assert session.visible_partner_hand() == (partner_card,)


def test_gui_partner_hand_visibility_offscreen() -> None:
    if importlib.util.find_spec("PySide6") is None:
        pytest.skip("PySide6 is not installed")
    code = """
from PySide6.QtWidgets import QApplication
from guandan.engine.card import Card, Suit
from guandan.engine.state import GameState
from guandan.gui.window import GuandanMainWindow
from guandan.ui.session import GameSession

app = QApplication([])
state = GameState(
    level=2, wild_card=None,
    hands=[[Card(3, Suit.HEARTS)], [Card(4, Suit.SPADES)],
           [Card(7, Suit.CLUBS)], [Card(5, Suit.DIAMONDS)]],
    turn_index=0, leader=0,
)
session = GameSession(difficulty=0, existing_state=state, human=0)
window = GuandanMainWindow()
window.start_game(session)
page = window.game_page
assert page is not None
assert page.hand_stack.currentWidget() is page.hand
assert not page.result_partner_cards._cards

state.hands[0].clear()
state.finish_order.append(0)
page.refresh()
assert page.hand_stack.currentWidget() is page.partner_hand
assert page.partner_hand._cards == [Card(7, Suit.CLUBS)]
assert '对家剩余手牌' in page.hand_title.text()

state.finished = True
state.finish_order.extend((1, 3))
state.team_levels_final = [3, 2]
page.refresh()
assert page.hand_stack.currentWidget() is page.result_panel
assert page.result_partner_cards._cards == (Card(7, Suit.CLUBS),)

session.game_saved = True
assert session.prepare_next_game().ok
page.refresh()
assert page.hand_stack.currentWidget() is page.hand
assert not page.result_partner_cards._cards
assert '对家剩余手牌' not in page.hand_title.text()
"""
    env = dict(os.environ, QT_QPA_PLATFORM="offscreen")
    result = subprocess.run(
        [sys.executable, "-c", code], env=env, capture_output=True, text=True,
        timeout=30,
    )
    assert result.returncode == 0, result.stdout + result.stderr


def test_completed_trick_stays_visible_until_the_next_lead() -> None:
    cards = [
        Card(RANK_4, Suit.HEARTS),
        Card(RANK_5, Suit.HEARTS),
        Card(RANK_6, Suit.HEARTS),
        Card(RANK_7, Suit.HEARTS),
    ]
    state = GameState(
        level=RANK_2,
        wild_card=None,
        hands=[
            [cards[0], Card(RANK_8, Suit.CLUBS)],
            [cards[1], Card(RANK_8, Suit.DIAMONDS)],
            [cards[2], Card(RANK_8, Suit.SPADES)],
            [cards[3], Card(RANK_8, Suit.HEARTS)],
        ],
        turn_index=0,
        leader=0,
    )
    session = GameSession(difficulty=0, existing_state=state, human=0)

    play_pattern(
        state,
        0,
        Pattern(PatternType.SINGLE, rank=RANK_4, length=1, cards=(cards[0],)),
    )
    session.table_display_actions(preserve_completed_trick=True)
    for player in (3, 2):
        pass_turn(state, player)
        session.table_display_actions(preserve_completed_trick=True)
    pass_turn(state, 1)

    visible = session.table_display_actions(preserve_completed_trick=True)

    assert state.table == []
    assert state.trick_number == 1
    assert visible[0][0] == "play"
    assert visible[3] == ("pass", None)
    assert visible[2] == ("pass", None)
    assert visible[1] == ("pass", None)

    next_card = state.hands[0][0]
    next_pattern = Pattern(
        PatternType.SINGLE,
        rank=next_card.rank,
        length=1,
        cards=(next_card,),
    )
    play_pattern(state, 0, next_pattern)
    next_visible = session.table_display_actions(preserve_completed_trick=True)

    assert next_visible[0] == ("play", next_pattern)
    assert 3 not in next_visible


def test_session_hint_cycles_through_distinct_legal_responses() -> None:
    table_top = Pattern(
        PatternType.SINGLE,
        rank=RANK_5,
        length=1,
        cards=(Card(RANK_5, Suit.SPADES),),
    )
    state = GameState(
        level=RANK_2,
        wild_card=None,
        hands=[
            [
                Card(RANK_8, Suit.CLUBS),
                Card(RANK_8, Suit.CLUBS),
                Card(RANK_K, Suit.HEARTS),
            ],
            [],
            [],
            [],
        ],
        turn_index=0,
        leader=1,
        table=[table_top],
    )
    session = GameSession(difficulty=0, existing_state=state, human=0)

    first = session.hint_for_human()
    second = session.hint_for_human()
    wrapped = session.hint_for_human()

    assert first.ok and second.ok and wrapped.ok
    assert first.suggested_cards != second.suggested_cards
    assert wrapped.suggested_cards == first.suggested_cards
    assert "提示 1/2" in first.message
    assert "提示 2/2" in second.message
    for result in (first, second):
        pattern = Pattern(
            PatternType.SINGLE,
            rank=result.suggested_cards[0].rank,
            length=1,
            cards=result.suggested_cards,
        )
        assert pattern.can_be_played_on(table_top, level=state.level)


def test_session_hint_suggests_pass_when_table_cannot_be_beaten() -> None:
    four_jokers = Pattern(
        PatternType.FOUR_JOKERS,
        rank=RANK_BIG_JOKER,
        length=4,
        cards=(
            Card(RANK_BIG_JOKER, Suit.BIG_JOKER),
            Card(RANK_BIG_JOKER, Suit.BIG_JOKER),
            Card(RANK_SMALL_JOKER, Suit.SMALL_JOKER),
            Card(RANK_SMALL_JOKER, Suit.SMALL_JOKER),
        ),
    )
    state = GameState(
        level=RANK_2,
        wild_card=None,
        hands=[[Card(RANK_K, Suit.HEARTS)], [], [], []],
        turn_index=0,
        leader=1,
        table=[four_jokers],
    )

    result = GameSession(difficulty=0, existing_state=state, human=0).hint_for_human()

    assert result.ok
    assert result.suggested_cards == ()
    assert result.message == "提示：建议过牌"


def test_session_hint_includes_bomb_over_straight_with_unrelated_joker() -> None:
    table_top = Pattern(
        PatternType.STRAIGHT,
        rank=RANK_7,
        length=5,
        cards=(
            Card(RANK_3, Suit.HEARTS),
            Card(RANK_4, Suit.DIAMONDS),
            Card(RANK_5, Suit.SPADES),
            Card(RANK_6, Suit.CLUBS),
            Card(RANK_7, Suit.HEARTS),
        ),
    )
    bomb_cards = (
        Card(RANK_8, Suit.HEARTS),
        Card(RANK_8, Suit.DIAMONDS),
        Card(RANK_8, Suit.SPADES),
        Card(RANK_8, Suit.CLUBS),
    )
    state = GameState(
        level=RANK_2,
        wild_card=None,
        hands=[
            [*bomb_cards, Card(RANK_BIG_JOKER, Suit.BIG_JOKER)],
            [],
            [],
            [],
        ],
        turn_index=0,
        leader=1,
        table=[table_top],
    )

    result = GameSession(difficulty=0, existing_state=state, human=0).hint_for_human()

    assert result.ok
    assert result.suggested_cards == bomb_cards
    assert "炸弹" in result.message


def test_session_game_ids_are_unique_and_filesystem_safe() -> None:
    first = GameSession(difficulty=0)
    second = GameSession(difficulty=0)

    assert first.game_id != second.game_id
    assert first.game_id.startswith("game_")
    assert first.game_id.replace("_", "").isalnum()


def test_session_next_game_uses_selected_human_return_and_records_events() -> None:
    finished = GameState(
        level=2,
        wild_card=None,
        hands=[[], [], [], []],
        turn_index=0,
        leader=0,
        finish_order=[0, 1, 2],
        finished=True,
    )
    finished.team_levels_final = [5, 2]
    fixed_hands = [
        [Card(RANK_3, Suit.HEARTS), Card(RANK_4, Suit.HEARTS)],
        [Card(RANK_4, Suit.SPADES), Card(RANK_8, Suit.SPADES)],
        [Card(RANK_5, Suit.CLUBS), Card(RANK_8, Suit.CLUBS)],
        [Card(RANK_BIG_JOKER, Suit.BIG_JOKER), Card(RANK_8, Suit.DIAMONDS)],
    ]

    def fake_initial_state(**kwargs) -> GameState:
        return GameState(
            level=kwargs["level"],
            wild_card=Card(RANK_5, Suit.HEARTS),
            hands=[list(hand) for hand in fixed_hands],
            turn_index=kwargs["first_player"],
            leader=kwargs["first_player"],
            team_levels=list(kwargs["team_levels"]),
        )

    session = GameSession(difficulty=0, existing_state=finished, human=0)
    session.game_saved = True
    with patch("guandan.ui.session.make_initial_state", fake_initial_state):
        prepared = session.prepare_next_game()
        assert session.state is finished
        dealt_state = session.display_state()
        assert dealt_state is not finished
        assert dealt_state.hands[0] == fixed_hands[0]
        assert session.tribute_events() == ()

        started = session.begin_next_game_tribute()
        choice = session.pending_next_game_choice()
        assert choice is not None
        assert choice.kind == "return"
        assert Card(RANK_4, Suit.HEARTS) in choice.cards
        return_state = session.display_state()
        assert len(return_state.hands[0]) == 3
        assert Card(RANK_BIG_JOKER, Suit.BIG_JOKER) in return_state.hands[0]
        assert len(session.tribute_events()) == 1
        assert isinstance(session.tribute_events()[0], TributeSent)
        result = session.finalize_next_game(Card(RANK_4, Suit.HEARTS))

    assert result.ok
    assert session.state is not None
    assert session.state.level == 5
    assert session.state.turn_index == 3
    assert all(len(hand) == 2 for hand in session.state.hands)
    assert Card(RANK_BIG_JOKER, Suit.BIG_JOKER) in session.state.hands[0]
    assert Card(RANK_4, Suit.HEARTS) in session.state.hands[3]
    assert Card(RANK_3, Suit.HEARTS) in session.state.hands[0]
    assert any(isinstance(event, TributeSent) for event in session.state.history)
    assert any(isinstance(event, TributeReturned) for event in session.state.history)
    assert prepared.ok
    assert started.ok
    assert len(session.tribute_events()) == 2


def test_tribute_notice_covers_no_exchange_ai_only_exchange_and_resistance() -> None:
    first = GameSession(difficulty=0, level=RANK_2, human=0)
    assert first.tribute_notice() == "本局贡还牌 · 首局无需贡还牌"

    state = GameState(
        level=RANK_5,
        wild_card=None,
        hands=[[], [], [], []],
        turn_index=0,
        history=[
            TributeSent(3, 1, Card(RANK_BIG_JOKER, Suit.BIG_JOKER)),
            TributeReturned(1, 3, Card(RANK_4, Suit.HEARTS)),
        ],
    )
    session = GameSession(difficulty=0, existing_state=state, human=0, round_index=2)
    assert session.tribute_notice() == (
        "本局贡还牌 · 北家→南家进贡 大王；南家→北家还贡 红4♥；你未参与贡还牌"
    )

    state.history = [TributeResisted(player=3, team=1, reason="single")]
    assert session.tribute_notice() == "本局贡还牌 · 北家抗贡，本局没有换牌；你未参与贡还牌"


def test_session_cancel_prepared_next_game_keeps_completed_round() -> None:
    finished = GameState(
        level=2,
        wild_card=None,
        hands=[[], [], [], []],
        turn_index=0,
        leader=0,
        finish_order=[0, 1, 2],
        finished=True,
        team_levels_final=[5, 2],
    )
    session = GameSession(
        difficulty=0,
        existing_state=finished,
        human=0,
        game_id="finished-round",
        match_id="same-match",
        round_index=2,
    )
    session.game_saved = True

    assert session.prepare_next_game().ok
    assert session.display_state() is not finished
    assert session.cancel_next_game().ok

    assert session.state is finished
    assert session.display_state() is finished
    assert session.game_id == "finished-round"
    assert session.match_id == "same-match"
    assert session.round_index == 2


@pytest.mark.parametrize("ruleset,failures", [(2, [0, 0]), (3, [2, 0])])
def test_session_next_round_keeps_ruleset_and_a_failure_count(ruleset, failures) -> None:
    finished = GameState(
        level=RANK_A, wild_card=None, hands=[[], [], [], []],
        turn_index=0, finish_order=[0, 1, 3], finished=True,
        team_levels=[RANK_A, 2],
        team_levels_final=[2, 2] if ruleset == 2 else [RANK_A, 2],
        ruleset_version=ruleset, a_failure_counts=failures,
    )
    session = GameSession(difficulty=0, existing_state=finished, human=0)
    session.game_saved = True
    assert session.prepare_next_game().ok
    next_state = session.display_state()
    assert next_state.ruleset_version == ruleset
    assert next_state.a_failure_counts == failures
    assert next_state.history[0].a_failure_counts == tuple(failures)


def test_session_keeps_match_id_and_advances_round_and_game_ids() -> None:
    finished = GameState(
        level=2,
        wild_card=None,
        hands=[[], [], [], []],
        turn_index=0,
        leader=0,
        finish_order=[0, 1, 2],
        finished=True,
        team_levels_final=[5, 2],
    )
    session = GameSession(
        difficulty=0,
        existing_state=finished,
        game_id="old-round",
        match_id="same-match",
        round_index=4,
    )
    session.game_saved = True

    result = session.start_next_game()

    assert result.ok
    assert session.game_id != "old-round"
    assert session.match_id == "same-match"
    assert session.round_index == 5


def test_session_keeps_finished_state_when_persistence_fails() -> None:
    finished = GameState(
        level=2,
        wild_card=None,
        hands=[[], [], [], []],
        turn_index=0,
        leader=0,
        finish_order=[0, 1, 2],
        finished=True,
        team_levels_final=[5, 2],
    )
    session = GameSession(difficulty=0, existing_state=finished, human=0)

    with patch.object(session, "save_finished_if_needed", return_value=False):
        session.last_action = "保存失败：disk full"
        result = session.start_next_game()

    assert result.ok is False
    assert "保存失败" in result.message
    assert session.state is finished


def _finished_round_state() -> GameState:
    return GameState(
        level=2,
        wild_card=None,
        hands=[[], [], [], []],
        turn_index=0,
        leader=0,
        finish_order=[0, 1, 2],
        finished=True,
        team_levels_final=[5, 2],
    )


def test_pending_next_round_is_saved_so_an_exit_does_not_lose_it() -> None:
    """The freshly dealt round must reach disk while its tribute phase pends.

    `prepare_next_game()` deletes the finished round's save and keeps the new
    round in memory only, so `save_unfinished()` has to persist the pending
    state instead of the finished one it is still pointing at.
    """
    session = GameSession(difficulty=0, existing_state=_finished_round_state(), human=0)
    session.game_saved = True  # the finished round was already settled

    with patch.object(session, "save_finished_if_needed", return_value=True):
        assert session.prepare_next_game().ok is True
    assert session.is_next_game_pending() is True
    pending_game_id = session._pending_next_game.game_id

    with patch("guandan.ui.session.save_game") as save_game_mock:
        session.save_unfinished()

    assert save_game_mock.call_count == 1
    kwargs = save_game_mock.call_args.kwargs
    assert kwargs["game_id"] == pending_game_id
    assert kwargs["round_index"] == 2
    assert kwargs["state"].finished is False
    assert [len(hand) for hand in kwargs["state"].hands] == [27, 27, 27, 27]


def test_save_unfinished_skips_an_already_settled_round() -> None:
    """Without a pending round the original guard still applies."""
    session = GameSession(difficulty=0, existing_state=_finished_round_state(), human=0)
    session.game_saved = True

    with patch("guandan.ui.session.save_game") as save_game_mock:
        session.save_unfinished()

    assert save_game_mock.call_count == 0


def test_save_unfinished_persists_a_live_round() -> None:
    session = GameSession(difficulty=0, human=0, seed=99)
    session.ensure_started()

    with patch("guandan.ui.session.save_game") as save_game_mock:
        session.save_unfinished()

    assert save_game_mock.call_count == 1
    kwargs = save_game_mock.call_args.kwargs
    assert kwargs["game_id"] == session.game_id
    assert kwargs["round_index"] == session.round_index
    assert kwargs["state"] is session.state


@contextmanager
def _real_storage(tmp_path: Path):
    """Point every storage path at `tmp_path` so settlement does real I/O.

    These tests used to stub `update_profile` with an in-memory dict, which
    meant the locking transaction and the settlement bookkeeping were never
    actually executed.
    """
    profile_path = tmp_path / "profile.json"
    savegame_path = tmp_path / "savegame.json"
    history_dir = tmp_path / "history"
    history_dir.mkdir(parents=True, exist_ok=True)
    with patch("guandan.storage.profile.get_profile_path", return_value=profile_path), patch(
        "guandan.storage.savegame.get_savegame_path", return_value=savegame_path
    ), patch("guandan.storage.history.get_history_dir", return_value=history_dir):
        yield profile_path


def _load_profile_from(path: Path) -> dict:
    return json.loads(path.read_text(encoding="utf-8"))


def _played_round(seed: int = 5) -> GameState:
    """Play one real round so the finished state has a genuine event stream.

    save_history() requires a GameOver event, so a hand-built GameState cannot
    drive the settlement path.
    """
    from guandan.ai.play import play_or_pass
    from guandan.ai.strategies.novice import NoviceStrategy

    session = GameSession(difficulty=0, human=0, seed=seed)
    state = session.ensure_started()
    strategy = NoviceStrategy()
    rng = random.Random(seed)
    turns = 0
    while not state.finished and turns < 3000:
        play_or_pass(state, state.current_player(), strategy, rng)
        turns += 1
    assert state.finished and len(state.finish_order) == 3
    return state


def test_session_records_round_head_without_counting_a_match(tmp_path: Path) -> None:
    finished = _played_round(seed=5)
    # 末游 is never 头游, so this human records no round head.
    human = next(player for player in range(4) if player not in finished.finish_order)
    session = GameSession(
        difficulty=0, existing_state=finished, human=human, game_id="team-loss"
    )

    with _real_storage(tmp_path):
        assert session.save_finished_if_needed() is True

    statistics = _load_profile_from(tmp_path / "profile.json")["statistics"]
    assert statistics["total_rounds"] == 1
    assert statistics["head_rounds"] == 0
    assert statistics["total_matches"] == 0
    # The settlement marker must be cleared once every write completed.
    assert statistics["pending_settlements"] == []


def test_session_records_match_result_only_after_passing_ace(tmp_path: Path) -> None:
    finished = _played_round(seed=11)
    human = finished.finish_order[0]  # head, so the round head is recorded
    # Force the pass-of-A settlement: the winning team is the human's own.
    finished.match_finished = True
    finished.winner_team = human % 2
    session = GameSession(
        difficulty=0,
        existing_state=finished,
        human=human,
        game_id="final-round",
        match_id="completed-match",
    )

    with _real_storage(tmp_path):
        assert session.save_finished_if_needed() is True

    statistics = _load_profile_from(tmp_path / "profile.json")["statistics"]
    assert statistics["total_rounds"] == 1
    assert statistics["head_rounds"] == 1
    assert statistics["total_matches"] == 1
    assert statistics["match_wins"] == 1
    assert statistics["recorded_match_ids"] == ["completed-match"]


def test_session_retries_finished_save_without_double_counting(tmp_path: Path) -> None:
    finished = _played_round(seed=17)
    session = GameSession(
        difficulty=0, existing_state=finished, human=finished.finish_order[0], game_id="retry-game"
    )

    with _real_storage(tmp_path), patch(
        "guandan.ui.session.delete_savegame", side_effect=[OSError("busy"), None]
    ):
        assert session.save_finished_if_needed() is False
        assert session.game_saved is False
        assert session.save_finished_if_needed() is True

    statistics = _load_profile_from(tmp_path / "profile.json")["statistics"]
    assert statistics["total_rounds"] == 1
    assert statistics["recorded_game_ids"] == ["retry-game"]
    assert statistics["pending_settlements"] == []


def test_interrupted_settlement_is_repaired_on_next_start(tmp_path: Path) -> None:
    """A crash between the history write and the statistics update self-heals."""
    finished = _played_round(seed=23)
    session = GameSession(
        difficulty=0, existing_state=finished, human=finished.finish_order[0], game_id="crash-game"
    )

    def explode(*args: Any, **kwargs: Any) -> None:
        raise OSError("power loss")

    with _real_storage(tmp_path):
        # The intent marker is persisted for real; only the statistics update
        # dies, which is exactly the crash window this protocol must survive.
        with patch("guandan.ui.session.record_round_statistics", side_effect=explode):
            assert session.save_finished_if_needed() is False

        statistics = _load_profile_from(tmp_path / "profile.json")["statistics"]
        assert statistics["total_rounds"] == 0
        # The marker survived, so the next start knows a settlement is open.
        assert [item["game_id"] for item in statistics["pending_settlements"]] == ["crash-game"]

        # Simulate the next start: reconciliation must count the round.
        repaired = reconcile_settlements(
            history_has_game=lambda game_id: history_exists(game_id)
        )

    assert repaired == 1
    statistics = _load_profile_from(tmp_path / "profile.json")["statistics"]
    assert statistics["total_rounds"] == 1
    assert statistics["recorded_game_ids"] == ["crash-game"]
    assert statistics["pending_settlements"] == []


def test_reconciliation_drops_a_round_whose_history_was_never_written(tmp_path: Path) -> None:
    """No history entry means the user never saw the round; do not invent it."""
    with _real_storage(tmp_path):
        begin_settlement(game_id="never-shown", got_head=True, difficulty=2)
        repaired = reconcile_settlements(
            history_has_game=lambda game_id: history_exists(game_id)
        )

    assert repaired == 0
    statistics = _load_profile_from(tmp_path / "profile.json")["statistics"]
    assert statistics["total_rounds"] == 0
    assert statistics["pending_settlements"] == []


def test_session_restored_elapsed_time_is_accumulated_when_saving() -> None:
    state = GameState(
        level=2,
        wild_card=None,
        hands=[[], [], [], []],
        turn_index=0,
        leader=0,
    )
    with patch("guandan.ui.session.time.time", return_value=100.0):
        session = GameSession(
            difficulty=0,
            existing_state=state,
            elapsed_seconds=75,
        )
    with patch("guandan.ui.session.time.time", return_value=125.9), patch(
        "guandan.ui.session.save_game"
    ) as save:
        session.save_unfinished()

    assert save.call_args.kwargs["elapsed_seconds"] == 100


def test_gui_window_smoke_offscreen() -> None:
    if importlib.util.find_spec("PySide6") is None:
        pytest.skip("PySide6 is not installed")
    env = dict(os.environ)
    env["QT_QPA_PLATFORM"] = "offscreen"
    code = (
        "from PySide6.QtWidgets import QApplication; "
        "from guandan.engine.card import Card, Suit; "
        "from guandan.engine.state import make_initial_state; "
        "from guandan.gui.cards import BLACK_SUIT_COLOR, NORMAL_SUIT_FONT_SIZE, RED_SUIT_COLOR, card_palette, gui_suit_name; "
        "from guandan.gui.window import APP_QSS, GuandanMainWindow; "
        "from guandan.ui.session import GameSession; "
        "assert card_palette(Card(5, Suit.HEARTS))[0] == RED_SUIT_COLOR; "
        "assert card_palette(Card(5, Suit.DIAMONDS))[0] == RED_SUIT_COLOR; "
        "assert card_palette(Card(5, Suit.SPADES))[0] == BLACK_SUIT_COLOR; "
        "assert card_palette(Card(5, Suit.CLUBS))[0] == BLACK_SUIT_COLOR; "
        "assert gui_suit_name(Suit.DIAMONDS) == '方片'; "
        "assert NORMAL_SUIT_FONT_SIZE >= 44; "
        "app = QApplication([]); app.setStyleSheet(APP_QSS); "
        "window = GuandanMainWindow(); "
        "assert window.minimumWidth() >= 1080; "
        "assert window.windowTitle().startswith('掼蛋 GUI'); "
        "state = make_initial_state(level=2, first_player=0, seed=1); "
        "window.start_game(GameSession(difficulty=0, existing_state=state, human=0)); "
        "page = window.game_page; "
        "assert page is not None; "
        "assert page.left.title.text().startswith('南家'); "
        "assert page.opposite.title.text().startswith('西家'); "
        "assert page.right.title.text().startswith('北家'); "
        "assert len(page.hand_cards) == 27; "
        "assert 100 <= page.hand.minimumHeight() <= 150; "
        "assert page.play_button.isEnabled() is False; "
        "page.hint(); "
        "first_hint = set(page.selected_indices); "
        "assert first_hint; "
        "assert page.play_button.isEnabled() is True; "
        "page.hint(); "
        "assert page.selected_indices; "
        "assert page.selected_indices != first_hint; "
        "page.clear_selection(); "
        "page.toggle_card(0); "
        "assert page.play_button.isEnabled() is True; "
        "page.play_selected(); "
        "assert len(state.table) == 1; "
        "assert len(state.hands[0]) == 26; "
        "assert '单张' in page.table.rows[0].text(); "
        "window.show_replay({'played_at': '2026-07-23T12:00:00', 'events': state.history}); "
        "replay = window.stack.currentWidget(); "
        "assert replay.__class__.__name__ == 'ReplayPage'; "
        "assert replay.event_index == len(state.history) - 1; "
        "replay.set_event_index(0); "
        "assert replay.event_index == 0; "
        "window.game_page = None; "
        "window.close(); "
        "app.processEvents(); "
        "app.quit(); "
        "print('ok')"
    )
    result = subprocess.run(
        [sys.executable, "-c", code],
        cwd=os.getcwd(),
        env=env,
        capture_output=True,
        text=True,
        check=False,
    )
    assert result.returncode == 0, result.stderr
    assert "ok" in result.stdout


def test_gui_difficulty_click_starts_selected_game() -> None:
    if importlib.util.find_spec("PySide6") is None:
        pytest.skip("PySide6 is not installed")
    env = dict(os.environ)
    env["QT_QPA_PLATFORM"] = "offscreen"
    code = """
from unittest.mock import patch
from PySide6.QtCore import Qt
from PySide6.QtTest import QTest
from PySide6.QtWidgets import QApplication, QPushButton
from guandan.gui.window import GuandanMainWindow

app = QApplication([])
window = GuandanMainWindow()
window.show_difficulty()
window.show()
app.processEvents()

difficulty_buttons = window.stack.currentWidget().findChildren(
    QPushButton, "difficultyCard"
)
assert len(difficulty_buttons) == 5
with patch("guandan.gui.window.has_savegame", return_value=False):
    QTest.mouseClick(difficulty_buttons[1], Qt.MouseButton.LeftButton)

assert window.stack.currentWidget() is window.game_page
assert window.game_page is not None
assert window.game_page.session.difficulty == 1
window.game_page.deactivate()
window.game_page = None

window.show_difficulty()
error_page = window.stack.currentWidget()
difficulty_buttons = error_page.findChildren(QPushButton, "difficultyCard")
with patch(
    "guandan.gui.window.make_strategy", side_effect=ImportError("strategy missing")
), patch("guandan.gui.window.QMessageBox.warning") as warning:
    QTest.mouseClick(difficulty_buttons[0], Qt.MouseButton.LeftButton)
assert window.stack.currentWidget() is error_page
warning.assert_called_once()

window.close()
app.quit()
print("ok")
"""
    result = subprocess.run(
        [sys.executable, "-c", code],
        cwd=os.getcwd(),
        env=env,
        capture_output=True,
        text=True,
        check=False,
    )
    assert result.returncode == 0, result.stderr
    assert "ok" in result.stdout


def test_gui_next_round_shows_deal_before_public_tribute_cards() -> None:
    if importlib.util.find_spec("PySide6") is None:
        pytest.skip("PySide6 is not installed")
    env = dict(os.environ)
    env["QT_QPA_PLATFORM"] = "offscreen"
    code = """
from unittest.mock import patch
from PySide6.QtWidgets import QApplication
from guandan.engine.card import RANK_3, RANK_4, RANK_5, RANK_8, RANK_A, RANK_BIG_JOKER, Card, Suit
from guandan.engine.events import TributeReturned, TributeSent
from guandan.engine.state import GameState
from guandan.gui.window import GuandanMainWindow
from guandan.ui.session import GameSession

app = QApplication([])
window = GuandanMainWindow()
with patch("guandan.ui.session.random.randint", return_value=0):
    opening = GameSession(difficulty=0, level=RANK_A, human=0, seed=7)
    window.start_game(opening)
opening_page = window.game_page
assert opening_page is not None
assert opening_page.round_phase.text() == "第 1 局 · 本局开始"
assert opening_page.round_level.text() == "本局级牌 A"
assert "本局级牌 A" in opening.last_action
assert opening_page.table.tribute_banner.isHidden() is False
assert "首局无需贡还牌" in opening_page.table.tribute_text.text()
assert "逢人配" in opening_page.status.text()
assert opening_page.table.tribute_banner.parent() is opening_page.status.parent()

ai_exchange = GameState(
    level=RANK_5,
    wild_card=None,
    hands=[[], [], [], []],
    turn_index=0,
    history=[
        TributeSent(3, 1, Card(RANK_BIG_JOKER, Suit.BIG_JOKER)),
        TributeReturned(1, 3, Card(RANK_4, Suit.HEARTS)),
    ],
)
window.start_game(GameSession(difficulty=0, existing_state=ai_exchange, human=0, round_index=2))
ai_page = window.game_page
assert ai_page is not None
assert "北家→南家进贡 大王" in ai_page.table.tribute_text.text()
assert "南家→北家还贡 红4♥" in ai_page.table.tribute_text.text()
assert "你未参与贡还牌" in ai_page.table.tribute_text.text()
assert "逢人配" in ai_page.status.text()

finished = GameState(
    level=2,
    wild_card=None,
    hands=[[], [], [], []],
    turn_index=0,
    leader=0,
    finish_order=[0, 1, 2],
    finished=True,
    team_levels_final=[5, 2],
)
session = GameSession(difficulty=0, existing_state=finished, human=0)
session.game_saved = True
window.start_game(session)
page = window.game_page
assert page is not None
assert page.round_phase.text() == "第 1 局 · 本局结束"
assert page.round_level.text() == "本局级牌 2"
assert page.hand_stack.currentWidget() is page.result_panel
assert "头游 东家" in page.result_places.text()
assert "升级 3 级" in page.result_scores.text()
assert "本局级牌 2" in page.status.text()
assert "下一局级牌 5" in page.status.text()
assert "级牌 5" in page.next_button.text()
assert page.turn_label.text() == "本局结束"

fixed_hands = [
    [Card(RANK_3, Suit.HEARTS), Card(RANK_4, Suit.HEARTS)],
    [Card(RANK_4, Suit.SPADES), Card(RANK_8, Suit.SPADES)],
    [Card(RANK_5, Suit.CLUBS), Card(RANK_8, Suit.CLUBS)],
    [Card(RANK_BIG_JOKER, Suit.BIG_JOKER), Card(RANK_8, Suit.DIAMONDS)],
]

def fake_initial_state(**kwargs):
    return GameState(
        level=kwargs["level"],
        wild_card=Card(RANK_5, Suit.HEARTS),
        hands=[list(hand) for hand in fixed_hands],
        turn_index=kwargs["first_player"],
        leader=kwargs["first_player"],
        team_levels=list(kwargs["team_levels"]),
    )

with patch("guandan.ui.session.make_initial_state", fake_initial_state):
    page.next_game()
    assert session.state is finished
    assert set(page.hand_cards) == set(fixed_hands[0])
    assert "手牌已发放" in page.status.text()
    assert page.round_phase.text() == "第 2 局 · 发牌中"
    assert page.round_level.text() == "本局级牌 5"
    assert page.table.tribute_banner.isHidden() is False
    assert "正在确认" in page.table.tribute_text.text()

    page._begin_next_game_tribute()
    choice = session.pending_next_game_choice()
    assert choice is not None and choice.kind == "return"
    assert len(page.hand_cards) == 3
    assert Card(RANK_BIG_JOKER, Suit.BIG_JOKER) in page.hand_cards
    assert page.table.tribute_banner.isHidden() is False
    assert "进贡" in page.table.tribute_text.text()
    assert "待确认最终结果" in page.table.tribute_text.text()
    assert page.hand_stack.currentWidget() is page.hand
    assert page.play_button.text() == "确认还贡"
    assert not page.play_button.isEnabled()
    assert any(not card.isEnabled() for card in page.hand._buttons)

    page.toggle_card(page.hand_cards.index(Card(RANK_4, Suit.HEARTS)))
    assert page.play_button.isEnabled()
    assert "红4♥" in page.selection_preview.text()
    page.play_selected()

assert session.state is not finished
assert page.round_phase.text() == "第 2 局 · 本局开始"
assert page.round_level.text() == "本局级牌 5"
assert "进贡" in page.table.tribute_text.text()
assert "还贡" in page.table.tribute_text.text()
assert "你参与了贡还牌" in page.table.tribute_text.text()
assert len(page.table.tribute_cards._cards) == 2
page.refresh()
assert page.table.tribute_banner.isHidden() is False
assert len(page.table.tribute_cards._cards) == 2

page.deactivate()
window.game_page = None
window.close()
app.quit()
print("ok")
"""
    result = subprocess.run(
        [sys.executable, "-c", code],
        cwd=os.getcwd(),
        env=env,
        capture_output=True,
        text=True,
        check=False,
    )
    assert result.returncode == 0, result.stderr
    assert "ok" in result.stdout


def test_gui_compact_table_selection_and_previous_trick() -> None:
    if importlib.util.find_spec("PySide6") is None:
        pytest.skip("PySide6 is not installed")
    env = dict(os.environ)
    env["QT_QPA_PLATFORM"] = "offscreen"
    code = """
from PySide6.QtCore import QPoint
from PySide6.QtWidgets import QApplication
from guandan.engine.rules.patterns import find_complete_pattern
from guandan.engine.state import make_initial_state, pass_turn, play_pattern
from guandan.gui.window import GuandanMainWindow
from guandan.ui.session import GameSession

app = QApplication([])
state = make_initial_state(level=2, first_player=0, seed=7)
window = GuandanMainWindow()
window.start_game(GameSession(difficulty=0, existing_state=state, human=0))
window.resize(1080, 760)
window.show()
app.processEvents()
page = window.game_page
assert page is not None
south = page.table.trick_rows[1]
assert south.mapToGlobal(QPoint(0, south.height())).y() < page.me.mapToGlobal(QPoint(0, 0)).y()
assert page.table.activity_popup.isHidden()
page.table.show_activity()
app.processEvents()
assert page.table.activity_popup.isVisible()
page.table.activity_popup.hide()

first = next(i for i, card in enumerate(page.hand_cards) if card != state.wild_card)
page.toggle_card(first)
assert page.play_button.isEnabled()
assert "可出牌" in page.selection_preview.text()
second = next(i for i, card in enumerate(page.hand_cards) if card.rank != page.hand_cards[first].rank and card != state.wild_card)
page.toggle_card(second)
assert not page.play_button.isEnabled()
assert "不是完整牌型" in page.selection_preview.text()
page.clear_selection()

pattern = find_complete_pattern([state.hands[0][0]], state.wild_card)
play_pattern(state, 0, pattern)
for seat in (3, 2, 1):
    pass_turn(state, seat)
page.refresh()
assert page.previous_trick_button.isVisible()
assert len(page.session.previous_completed_trick()) == 4
page.show_previous_trick()
assert page._previous_trick_dialog.isVisible()
page._previous_trick_dialog.close()
ai_state = make_initial_state(level=2, first_player=3, seed=7)
window.start_game(GameSession(difficulty=0, existing_state=ai_state, human=0))
assert "思考中" in window.game_page.turn_label.text()
window.game_page.deactivate()
window.game_page = None
window.close()
app.quit()
print("ok")
"""
    result = subprocess.run(
        [sys.executable, "-c", code],
        cwd=os.getcwd(),
        env=env,
        capture_output=True,
        text=True,
        check=False,
    )
    assert result.returncode == 0, result.stderr
    assert "ok" in result.stdout


def test_gui_stops_ai_when_table_is_hidden_or_ai_fails() -> None:
    if importlib.util.find_spec("PySide6") is None:
        pytest.skip("PySide6 is not installed")
    env = dict(os.environ)
    env["QT_QPA_PLATFORM"] = "offscreen"
    code = """
from unittest.mock import Mock
from PySide6.QtCore import QEventLoop, QTimer
from PySide6.QtWidgets import QApplication
from guandan.engine.state import make_initial_state
from guandan.gui.window import GuandanMainWindow
from guandan.ui.session import GameSession, SessionAction

app = QApplication([])
window = GuandanMainWindow()


def wait_until(predicate, timeout_ms=5000, interval_ms=20):
    \"\"\"Pump the event loop until `predicate()` holds or the timeout expires.

    A fixed singleShot(timeout) silently races the AI worker's thread-pool
    scheduling; polling makes a slow machine fail loudly instead of flakily.
    \"\"\"
    waited = 0
    while not predicate() and waited < timeout_ms:
        loop = QEventLoop()
        QTimer.singleShot(interval_ms, loop.quit)
        loop.exec()
        waited += interval_ms
    return predicate()


state = make_initial_state(level=2, first_player=3, seed=9)
session = GameSession(difficulty=0, existing_state=state, human=0)
session.save_unfinished = Mock()
window.start_game(session)
before = len(state.history)
window.game_page.back_to_menu()
loop = QEventLoop()
QTimer.singleShot(500, loop.quit)
loop.exec()
assert len(state.history) == before

failed_state = make_initial_state(level=2, first_player=3, seed=10)
failed_session = GameSession(difficulty=0, existing_state=failed_state, human=0)
failed_session.step_ai = Mock(return_value=SessionAction(False, "AI 错误：invalid"))
window.start_game(failed_session)
assert wait_until(lambda: failed_session.step_ai.call_count >= 1), "AI worker never ran"
assert wait_until(lambda: not window.game_page._ai_running), "AI worker never finished"
assert failed_session.step_ai.call_count == 1
assert not window.game_page._ai_timer.isActive()

window.game_page = None
window.close()
app.quit()
print("ok")
"""
    result = subprocess.run(
        [sys.executable, "-c", code],
        cwd=os.getcwd(),
        env=env,
        capture_output=True,
        text=True,
        check=False,
    )
    assert result.returncode == 0, result.stderr
    assert "ok" in result.stdout


def test_gui_empty_history_and_new_game_conflict_states() -> None:
    if importlib.util.find_spec("PySide6") is None:
        pytest.skip("PySide6 is not installed")
    env = dict(os.environ)
    env["QT_QPA_PLATFORM"] = "offscreen"
    code = """
from unittest.mock import patch
from PySide6.QtWidgets import QApplication, QMessageBox
from guandan.engine.state import make_initial_state
from guandan.gui.window import GuandanMainWindow
from guandan.ui.session import GameSession

app = QApplication([])
window = GuandanMainWindow()

with patch("guandan.gui.window.load_history_list", return_value=[]):
    window.show_history()
    history = window.stack.currentWidget()
    assert history.table.isVisible() is False
    assert history.empty.isHidden() is False
    assert history.replay_button.isEnabled() is False

with patch("guandan.gui.window.load_history_list", side_effect=OSError("storage busy")):
    history.refresh()
    assert "无法读取历史记录" in history.empty.text()
    assert "storage busy" in history.empty.text()

with patch.object(
    QMessageBox, "question", return_value=QMessageBox.StandardButton.Yes
), patch("guandan.gui.window.has_savegame", return_value=False), patch(
    "guandan.gui.window.delete_savegame", side_effect=OSError("storage busy")
), patch.object(
    QMessageBox, "warning"
) as delete_warning:
    window.show_load()
    load_page = window.stack.currentWidget()
    load_page._delete_save()
    delete_warning.assert_called_once()
    assert window.stack.currentWidget() is load_page

with patch("guandan.gui.window.has_savegame", return_value=True), patch.object(
    QMessageBox, "warning", return_value=QMessageBox.StandardButton.Cancel
):
    assert window.confirm_start_new_game() is False

with patch("guandan.gui.window.has_savegame", return_value=True), patch(
    "guandan.gui.window.load_game", return_value={"game_id": "game_current"}
), patch("guandan.gui.window.delete_savegame") as delete, patch.object(
    QMessageBox, "warning", return_value=QMessageBox.StandardButton.Discard
):
    assert window.confirm_start_new_game() is True
    # Overwrite must only discard the save the user was shown.
    delete.assert_called_once_with(expected_game_id="game_current", expected_revision=0)

state = make_initial_state(level=2, first_player=0, seed=7)
session = GameSession(difficulty=0, existing_state=state, human=0)
window.start_game(session)
with patch.object(session, "save_unfinished", side_effect=OSError("disk full")), patch.object(
    QMessageBox, "warning"
) as warning:
    window.game_page.back_to_menu()
    from PySide6.QtCore import QEventLoop, QTimer
    for _ in range(200):
        if warning.call_count:
            break
        loop = QEventLoop()
        QTimer.singleShot(10, loop.quit)
        loop.exec()
    assert window.stack.currentWidget() is window.game_page
    warning.assert_called_once()

window.game_page = None
window.close()
app.quit()
print("ok")
"""
    result = subprocess.run(
        [sys.executable, "-c", code],
        cwd=os.getcwd(),
        env=env,
        capture_output=True,
        text=True,
        check=False,
    )
    assert result.returncode == 0, result.stderr
    assert "ok" in result.stdout


def test_evicting_the_game_page_clears_the_window_reference(tmp_path: Path) -> None:
    """The window must not keep a pointer to an evicted table.

    `_replace_page` drops the oldest page once the stack exceeds its limit;
    leaving `game_page` pointing at it means `save_current_game()` and
    `closeEvent()` dereference off-screen Qt objects.
    """
    if importlib.util.find_spec("PySide6") is None:
        pytest.skip("PySide6 is not installed")
    env = dict(os.environ)
    env["QT_QPA_PLATFORM"] = "offscreen"
    code = """
import sys
from PySide6.QtWidgets import QApplication
from guandan.gui.window import GuandanMainWindow
from guandan.ui.session import GameSession

app = QApplication([])
window = GuandanMainWindow()
window.show_difficulty()
window.start_game(GameSession(difficulty=0, human=0))
assert window.game_page is not None

# Push past the 3-page limit so the table gets evicted.
window.show_menu()
window.show_history()
window.show_menu()
app.processEvents()

assert window.game_page is None, "evicted table is still referenced"
# Tearing the window down must therefore be safe.
window.close()
app.quit()
print("ok")
"""
    result = subprocess.run(
        [sys.executable, "-c", code],
        cwd=os.getcwd(),
        env=env,
        capture_output=True,
        text=True,
        check=False,
        timeout=60,
    )
    assert result.returncode == 0, result.stderr
    assert "ok" in result.stdout


def test_gui_organizes_hand_without_losing_selected_cards() -> None:
    if importlib.util.find_spec("PySide6") is None:
        pytest.skip("PySide6 is not installed")
    env = dict(os.environ)
    env["QT_QPA_PLATFORM"] = "offscreen"
    code = """
from PySide6.QtWidgets import QApplication
from PySide6.QtTest import QTest
from PySide6.QtCore import Qt
from guandan.engine.card import Card, Suit
from guandan.engine.state import GameState
from guandan.gui.window import GuandanMainWindow
from guandan.ui.session import GameSession

selected = Card(3, Suit.DIAMONDS)
hand = [
    Card(3, Suit.HEARTS), selected,
    Card(4, Suit.HEARTS), Card(5, Suit.HEARTS),
    Card(6, Suit.HEARTS), Card(7, Suit.HEARTS),
    Card(8, Suit.CLUBS),
]
state = GameState(level=2, wild_card=None, hands=[hand, [], [], []], turn_index=0, leader=0)
app = QApplication([])
window = GuandanMainWindow()
window.start_game(GameSession(difficulty=0, existing_state=state, human=0))
page = window.game_page
assert page is not None
assert page.organize_button.isEnabled()
page.toggle_card(page.hand_cards.index(selected))
page.organize_hand()
assert page.selected_cards() == [selected]
assert page.hand_title.text().startswith('我的手牌 · 同花顺优先 1/')
assert page.hand._group_starts
assert page.hand._group_ranges[0][2].label
first_end = page.hand._group_ranges[0][1]
buttons = page.hand._buttons
assert buttons[1].x() - buttons[0].x() < buttons[first_end].x() - buttons[first_end - 1].x()
assert buttons[1].y() > buttons[0].y()
group = page.hand_organizer.playable_group_at(0)
assert group is not None
QTest.mouseDClick(page.hand._buttons[0], Qt.MouseButton.LeftButton)
app.processEvents()
assert len(page.selected_cards()) == len(group[2].cards)
QTest.mouseDClick(page.hand._buttons[0], Qt.MouseButton.LeftButton)
app.processEvents()
assert not page.selected_cards()
page.toggle_card(page.hand_cards.index(selected))
page.organize_hand()
rank_index = next(i for i, item in enumerate(page.hand_organizer.arrangements) if item.kind == 'rank')
page.choose_organization(rank_index)
assert page.hand_title.text().startswith('我的手牌 · 点数理 ')
assert page.selected_cards() == [selected]
suit_index = next(i for i, item in enumerate(page.hand_organizer.arrangements) if item.kind == 'suit')
page.choose_organization(suit_index)
assert '花色理' in page.hand_title.text()
page.reset_organization()
assert page.hand_organizer.status == ''
state.turn_index = 1
page.refresh()
assert page.organize_button.isEnabled()
page.organize_hand()
assert page.selected_cards() == [selected]
state.turn_index = 0
page.refresh()
page.play_selected()
assert state.table[-1].cards == (selected,)
window.game_page = None
window.close()
app.quit()
print('ok')
"""
    result = subprocess.run(
        [sys.executable, "-c", code],
        cwd=os.getcwd(),
        env=env,
        capture_output=True,
        text=True,
        check=False,
        timeout=60,
    )
    assert result.returncode == 0, result.stderr
    assert "ok" in result.stdout


def test_gui_manual_pattern_lock_survives_sort_and_unlocks_after_play() -> None:
    if importlib.util.find_spec("PySide6") is None:
        pytest.skip("PySide6 is not installed")
    env = dict(os.environ)
    env["QT_QPA_PLATFORM"] = "offscreen"
    code = """
from PySide6.QtWidgets import QApplication
from guandan.engine.card import Card, Suit
from guandan.engine.hand import PatternType
from guandan.engine.state import GameState
from guandan.gui.window import GuandanMainWindow
from guandan.ui.session import GameSession

pair = [Card(3, Suit.HEARTS), Card(3, Suit.DIAMONDS)]
hand = [*pair, Card(4, Suit.HEARTS), Card(5, Suit.HEARTS),
        Card(6, Suit.HEARTS), Card(7, Suit.HEARTS), Card(8, Suit.CLUBS)]
state = GameState(level=2, wild_card=None, hands=[hand, [], [], []], turn_index=0, leader=0)
app = QApplication([])
window = GuandanMainWindow()
window.start_game(GameSession(difficulty=0, existing_state=state, human=0))
page = window.game_page
assert page is not None
state.turn_index = 1
page.refresh()
for card in pair:
    page.toggle_card(page.hand_cards.index(card))
assert page.lock_button.isEnabled()
page.toggle_lock()
assert page.hand_organizer.locked_count == 1
assert page.hand._group_ranges[0][2].locked
assert not page.selected_cards()
page.organize_hand()
assert page.hand_organizer.display_groups[0].locked
page.toggle_group(0)
assert page.lock_button.text() == '解除锁定'
page.toggle_lock()
assert page.hand_organizer.locked_count == 0

for card in pair:
    page.toggle_card(page.hand_cards.index(card))
page.toggle_lock()
page.toggle_group(0)
state.turn_index = 0
page.refresh()
page.play_selected()
assert state.table[-1].type == PatternType.PAIR
assert page.hand_organizer.locked_count == 0
window.game_page = None
window.close()
app.quit()
print('ok')
"""
    result = subprocess.run(
        [sys.executable, "-c", code], cwd=os.getcwd(), env=env,
        capture_output=True, text=True, check=False, timeout=60,
    )
    assert result.returncode == 0, result.stderr
    assert "ok" in result.stdout


def test_gui_drag_selects_and_deselects_contiguous_cards() -> None:
    if importlib.util.find_spec("PySide6") is None:
        pytest.skip("PySide6 is not installed")
    env = dict(os.environ)
    env["QT_QPA_PLATFORM"] = "offscreen"
    code = """
from PySide6.QtCore import QEvent, QPoint, QPointF, Qt
from PySide6.QtGui import QMouseEvent
from PySide6.QtTest import QTest
from PySide6.QtWidgets import QApplication
from guandan.engine.card import Card, Suit
from guandan.engine.state import GameState
from guandan.gui.window import GuandanMainWindow
from guandan.ui.session import GameSession

app = QApplication([])
hand = [Card(rank, Suit.CLUBS) for rank in range(3, 10)]
state = GameState(level=2, wild_card=None, hands=[hand, [], [], []], turn_index=0, leader=0)
window = GuandanMainWindow()
window.start_game(GameSession(difficulty=0, existing_state=state, human=0))
page = window.game_page
assert page is not None

def drag(start, *targets):
    source = page.hand._buttons[start]
    QTest.mousePress(source, Qt.MouseButton.LeftButton, pos=QPoint(4, 40))
    for index in targets:
        target = page.hand._buttons[index]
        point = QPoint(target.x() + 4, target.y() + 40)
        global_point = page.hand.mapToGlobal(point)
        local_point = source.mapFromGlobal(global_point)
        move = QMouseEvent(
            QEvent.Type.MouseMove, QPointF(local_point), QPointF(global_point),
            Qt.MouseButton.NoButton, Qt.MouseButton.LeftButton, Qt.KeyboardModifier.NoModifier,
        )
        app.sendEvent(source, move)
    target = page.hand._buttons[targets[-1]]
    release_point = source.mapFromGlobal(
        page.hand.mapToGlobal(QPoint(target.x() + 4, target.y() + 40))
    )
    QTest.mouseRelease(source, Qt.MouseButton.LeftButton, pos=release_point)
    app.processEvents()

QTest.mouseClick(page.hand._buttons[0], Qt.MouseButton.LeftButton, pos=QPoint(4, 40))
assert page.selected_indices == {0}
drag(1, 4)
assert page.selected_indices == {0, 1, 2, 3, 4}
drag(4, 2)
assert page.selected_indices == {0, 1}
drag(2, 5, 3)
assert page.selected_indices == {0, 1, 2, 3}
QTest.mouseClick(page.hand._buttons[6], Qt.MouseButton.LeftButton, pos=QPoint(4, 40))
assert page.selected_indices == {0, 1, 2, 3, 6}
QTest.mouseClick(page.hand._buttons[2], Qt.MouseButton.LeftButton, pos=QPoint(35, 40))
assert page.selected_indices == {0, 1, 3, 6}
page.clear_selection()
drag(6, 3)
assert page.selected_indices == {3, 4, 5, 6}
window.game_page = None
window.close()
app.quit()
print('ok')
"""
    result = subprocess.run(
        [sys.executable, "-c", code], cwd=os.getcwd(), env=env,
        capture_output=True, text=True, check=False, timeout=60,
    )
    assert result.returncode == 0, result.stderr
    assert "ok" in result.stdout
