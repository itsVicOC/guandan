"""Production-clock trial fairness, isolation, lineage and promotion checks."""
from __future__ import annotations

import random
from pathlib import Path

import pytest

from guandan.ai.strategy import make_strategy
from guandan.engine.state import make_initial_state
from scripts.ai_budget_refinement_trial import seed_for as previous_seed
from scripts.ai_team_trial import public_request
from scripts.ai_urgent_blocking_trial import (
    COUNTS,
    ROOT,
    Client,
    development_passed,
    promotion_passed,
    seed_for,
)
from scripts.fit_action_ranker import derived_seed


def test_seeds_disjoint_from_previous_studies_and_full_rounds():
    inputs = [(f'{stage}-{tier}', i) for stage, count in COUNTS.items() for tier in (3, 4) for i in range(count)]
    current = {seed_for(stage, i) for stage, i in inputs}
    old = {previous_seed(stage, i) for stage, i in inputs} | {derived_seed(stage, i) for stage, i in inputs}
    assert len(current) == len(inputs) and not current.intersection(old)
    full = [seed_for('full-deal', seed_for(f'full-{tier}', i), j) for tier in (3, 4) for i in range(48) for j in range(64)]
    assert len(set(full)) == len(full) and not current.intersection(full)


def clock_fixture():
    return {'records': [{'tier': tier, 'budget_passed': True} for tier in (3, 4) for _ in range(21)]}


def test_development_requires_both_gains_and_timing():
    good = {'pairs': 32, 'mean_paired_gain': .01, 'budget_gate_passed': True}
    assert development_passed(good, good, clock_fixture(), 3)
    assert not development_passed(good, {**good, 'mean_paired_gain': 0}, clock_fixture(), 3)
    assert not development_passed({**good, 'budget_gate_passed': False}, good, clock_fixture(), 3)
    clock = clock_fixture()
    clock['records'][0]['budget_passed'] = False
    assert not development_passed(good, good, clock, 3)


def acceptance_fixture():
    one = {'pairs': 240, 'gain_confidence_95': [.01, .03], 'budget_gate_passed': True,
           'observations': [{'strict_replay_passed': True}]}
    mixed = {**one, 'by_companion': {str(t): {'mean_paired_gain': .01} for t in range(3)}}
    full = {**one, 'pairs': 48, 'match_win_confidence_95': [.51, .70]}
    return [one, mixed, full]


@pytest.mark.parametrize('failure', ['team', 'partner', 'full', 'quality', 'replay', 'regression', 'clock'])
def test_no_failed_endpoint_can_promote(failure):
    reports, clock = acceptance_fixture(), clock_fixture()
    regression, replay, quality = {'passed': True}, {'passed': True, 'completed_branches': 1152}, {'passed': True}
    assert promotion_passed(reports, clock, regression, replay, quality, 3)
    if failure == 'team':
        reports[0]['gain_confidence_95'] = [-.01, .03]
    elif failure == 'partner':
        reports[1]['by_companion']['0']['mean_paired_gain'] = -.001
    elif failure == 'full':
        reports[2]['match_win_confidence_95'] = [.49, .70]
    elif failure == 'clock':
        clock['records'][0]['budget_passed'] = False
    else:
        {'quality': quality, 'replay': replay, 'regression': regression}[failure]['passed'] = False
    assert not promotion_passed(reports, clock, regression, replay, quality, 3)


def test_isolated_worker_and_direct_lower_tier_have_same_action_and_rng():
    client = Client(ROOT, 0)
    try:
        state = make_initial_state(seed=930400)
        actor = state.current_player()
        rng = random.Random(9)
        request = public_request(state, actor, 3)
        request.update(difficulty=2, mode='fixed', fixed_iterations=256, rng_state=rng.getstate())
        result = client.query(request)
        from guandan.storage.serialization import _dict_to_pattern
        policy = make_strategy(2)
        assert _dict_to_pattern(result['pattern']) == policy.select_pattern(state, actor)
        assert result['urgent'] is None
        assert result['budget_passed']
    finally:
        client.close()


def test_frozen_baseline_worker_accepts_public_request_without_new_options():
    baseline = Path('/tmp/guandan-urgent-v12-baseline')
    if not baseline.exists():
        pytest.skip('local frozen snapshot is not part of portable test setup')
    client = Client(baseline, 0)
    try:
        state = make_initial_state(seed=930401)
        request = public_request(state, state.current_player(), 3)
        request.update(difficulty=3, mode='fixed', fixed_iterations=16, rng_state=random.Random(9).getstate())
        result = client.query(request)
        assert result['urgent'] is None
        assert result['simulations'] <= 16
    finally:
        client.close()
