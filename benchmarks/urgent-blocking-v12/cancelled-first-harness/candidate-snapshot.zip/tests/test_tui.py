"""TUI interaction regressions."""
from __future__ import annotations

import asyncio
import random
from collections import Counter
from unittest.mock import patch

from rich.cells import cell_len
from rich.text import Text
from textual.widgets import Button, Static

from guandan.engine.card import (
    RANK_2,
    RANK_3,
    RANK_4,
    RANK_5,
    RANK_6,
    RANK_7,
    RANK_8,
    RANK_BIG_JOKER,
    RANK_J,
    RANK_SMALL_JOKER,
    Card,
    Suit,
)
from guandan.engine.events import Pass, TributeResisted, TributeReturned, TributeSent, TurnPlayed
from guandan.engine.hand import Pattern, PatternType
from guandan.engine.rules.patterns import find_complete_pattern
from guandan.engine.state import (
    GameState,
    make_initial_state,
    next_seat_counterclockwise,
    pass_turn,
    play_pattern,
)
from guandan.tui.app import GuandanApp
from guandan.tui.layout import (
    RECOMMENDED_COLUMNS,
    RECOMMENDED_LINES,
    should_request_terminal_resize,
    terminal_resize_disabled,
)
from guandan.tui.screens.confirm import ConfirmModal, TributeChoiceModal
from guandan.tui.screens.game import GameScreen, TableWidget, _tui_card
from guandan.tui.screens.history import HistoryScreen
from guandan.tui.screens.load_save import LoadSaveScreen
from guandan.tui.screens.replay import ReplayScreen


def _plain(markup: str) -> str:
    return Text.from_markup(markup).plain


def test_ai_completion_does_not_refresh_a_detached_screen() -> None:
    from guandan.ui.background import TurnResult

    screen = GameScreen(difficulty=0)
    screen._ai_running = True
    with patch.object(screen, "_refresh_all") as refresh:
        screen._finish_ai_turn(TurnResult())
        screen._maybe_ai_turn()
    assert not screen._ai_running
    refresh.assert_not_called()


def _single(card: Card) -> Pattern:
    return Pattern(PatternType.SINGLE, card.rank, 1, (card,), 0)


def _triple_pair(triple_rank: int, pair_rank: int) -> Pattern:
    cards = (
        Card(triple_rank, Suit.HEARTS),
        Card(triple_rank, Suit.DIAMONDS),
        Card(triple_rank, Suit.SPADES),
        Card(pair_rank, Suit.HEARTS),
        Card(pair_rank, Suit.DIAMONDS),
    )
    return Pattern(PatternType.TRIPLE_PAIR, triple_rank, 1, cards, 0)


def test_app_quit_from_tribute_modal_persists_pending_round() -> None:
    from contextlib import suppress

    from textual.worker import WorkerCancelled

    from guandan.storage import load_game
    from guandan.ui.session import GameSession
    from tests.test_reliability import finished_round

    async def run() -> None:
        state = finished_round()
        session = GameSession(difficulty=0, existing_state=state, human=state.finish_order[0])
        with patch("guandan.ui.session.random.randint", return_value=9):
            assert session.prepare_next_game().ok
        assert session.begin_next_game_tribute().ok
        app = GuandanApp()
        async with app.run_test() as pilot:
            screen = GameScreen(session=session)
            app.push_screen(screen)
            await pilot.pause()
            choice = session.pending_next_game_choice()
            assert choice is not None
            if not isinstance(app.screen, TributeChoiceModal):
                screen._begin_next_game_tribute()
            await pilot.pause()
            assert isinstance(app.screen, TributeChoiceModal)
            await app.action_quit()
            # Textual cancels the leaving worker as app.exit tears down the app.
            with suppress(WorkerCancelled):
                await app.workers.wait_for_complete()
        restored = GameSession.from_savegame(load_game())
        assert restored.is_next_game_pending()
        assert restored.pending_next_game_choice() == session.pending_next_game_choice()
        assert restored.display_state() == session.display_state()

    asyncio.run(run())


def test_conflict_copy_allows_leaving_tui_table() -> None:
    from guandan.storage import load_game
    from guandan.storage.savegame import list_recovery_games
    from guandan.tui.screens.error import ErrorModal
    from guandan.ui.session import GameSession

    async def run() -> None:
        owner = GameSession(difficulty=0, seed=9)
        owner.save_unfinished()
        session = GameSession(difficulty=0, existing_state=make_initial_state(seed=10, first_player=0))
        app = GuandanApp()
        async with app.run_test() as pilot:
            screen = GameScreen(session=session)
            app.push_screen(screen)
            await pilot.pause()
            screen.action_back()
            await app.workers.wait_for_complete()
            assert isinstance(app.screen, ErrorModal)
            await pilot.press("enter")
            await pilot.pause()
            assert screen not in app.screen_stack
            assert load_game()["game_id"] == owner.game_id
            assert session.game_id in {row["game_id"] for row in list_recovery_games()}

    asyncio.run(run())


def test_partner_cards_appear_after_human_finishes_and_hide_on_next_deal() -> None:
    async def run() -> None:
        partner_card = Card(RANK_7, Suit.CLUBS)
        state = GameState(
            level=2,
            wild_card=None,
            hands=[
                [Card(RANK_3, Suit.HEARTS)],
                [Card(RANK_4, Suit.SPADES)],
                [partner_card],
                [Card(RANK_5, Suit.DIAMONDS)],
            ],
            turn_index=0,
            leader=0,
        )
        app = GuandanApp()
        async with app.run_test() as pilot:
            screen = GameScreen(difficulty=0, existing_state=state, human=0)
            with patch.object(screen, "_maybe_ai_turn"):
                app.push_screen(screen)
                await pilot.pause()
                hand = screen.query_one("#my-hand", Static)
                assert "对家剩余手牌" not in _plain(hand.content)

                state.hands[0].clear()
                state.finish_order.append(0)
                screen._refresh_all()
                assert "对家剩余手牌 · 1 张" in _plain(hand.content)
                assert "梅7♣" in _plain(hand.content)

                state.finished = True
                state.finish_order.extend((1, 3))
                state.team_levels_final = [3, 2]
                screen._game_saved = True
                assert screen.session.prepare_next_game().ok
                screen._refresh_all()
                assert "对家剩余手牌" not in _plain(hand.content)

    asyncio.run(run())


def test_tribute_choice_modal_renders_and_returns_selected_card() -> None:
    async def run() -> None:
        cards = (
            Card(RANK_3, Suit.HEARTS),
            Card(RANK_4, Suit.SPADES),
        )
        selected: list[Card | None] = []
        app = GuandanApp()

        async with app.run_test(size=(140, 48)) as pilot:
            await pilot.pause()
            modal = TributeChoiceModal("return", cards)
            app.push_screen(modal, selected.append)
            await pilot.pause()

            assert modal.query_one("#tribute-choice-title").region.height > 0
            assert modal.query_one("#tribute-card-0", Button).region.height > 0
            assert modal.query_one("#tribute-cancel", Button).region.height > 0

            await pilot.click("#tribute-card-1")
            await pilot.pause()

            assert selected == [cards[1]]

    asyncio.run(run())


def test_tui_new_game_conflict_can_overwrite_existing_save() -> None:
    async def run() -> None:
        app = GuandanApp()
        with patch("guandan.storage.has_savegame", return_value=True), patch(
            "guandan.storage.load_game", return_value={"game_id": "game_shown"}
        ), patch("guandan.storage.delete_savegame") as delete:
            async with app.run_test(size=(140, 48)) as pilot:
                await pilot.pause()

                await pilot.click("#btn-new")
                await pilot.pause()
                assert isinstance(app.screen, ConfirmModal)

                await pilot.click("#confirm-overwrite")
                await pilot.pause()

                # Overwrite must not delete a save written after this dialog
                # was opened (GUI/TUI may run in parallel).
                delete.assert_called_once_with(expected_game_id="game_shown", expected_revision=0)
                assert app.screen.__class__.__name__ == "DifficultySelectScreen"

    asyncio.run(run())


def test_tui_can_delete_a_corrupt_save_after_confirmation() -> None:
    async def run() -> None:
        app = GuandanApp()
        with patch("guandan.tui.screens.load_save.has_savegame", return_value=True), patch(
            "guandan.tui.screens.load_save.load_game", return_value=None
        ), patch("guandan.storage.delete_savegame") as delete:
            async with app.run_test(size=(140, 48)) as pilot:
                await pilot.pause()
                app.push_screen(LoadSaveScreen())
                await pilot.pause()

                assert app.screen.query_one("#btn-delete", Button).region.height > 0
                await pilot.click("#btn-delete")
                await pilot.pause()
                assert isinstance(app.screen, ConfirmModal)

                await pilot.click("#confirm-delete")
                await pilot.pause()

                # A corrupt save has no game_id, so the delete stays unscoped.
                delete.assert_called_once_with(expected_game_id=None, expected_revision=None)
                assert app.screen.__class__.__name__ == "MainMenuScreen"

    asyncio.run(run())


def test_tui_load_error_stays_on_save_screen() -> None:
    async def run() -> None:
        summary = {
            "saved_at": "2026-07-27T12:00:00",
            "metadata": {
                "level": 2,
                "player_seat": 0,
                "ai_difficulties": [None, 0, 0, 0],
            },
            "current_state_snapshot": {
                "turn_index": 0,
                "hand_sizes": [27, 27, 27, 27],
            },
            "events": [],
        }
        app = GuandanApp()
        with patch("guandan.tui.screens.load_save.has_savegame", return_value=True), patch(
            "guandan.tui.screens.load_save.load_game",
            side_effect=[summary, OSError("storage busy")],
        ):
            async with app.run_test(size=(140, 48)) as pilot:
                await pilot.pause()
                screen = LoadSaveScreen()
                app.push_screen(screen)
                await pilot.pause()

                await pilot.click("#btn-continue")
                await pilot.pause()

                assert app.screen.__class__.__name__ == "ErrorModal"
                assert screen in app.screen_stack
                assert app.screen.query_one("#error-box").region.height > 0

    asyncio.run(run())


def test_tui_save_failure_keeps_game_screen_open() -> None:
    async def run() -> None:
        state = make_initial_state(level=RANK_2, first_player=0, seed=7)
        app = GuandanApp()

        async with app.run_test(size=(140, 48)) as pilot:
            await pilot.pause()
            screen = GameScreen(difficulty=0, existing_state=state)
            app.push_screen(screen)
            await pilot.pause()

            with patch.object(screen.session, "save_unfinished", side_effect=OSError("disk full")):
                screen.action_back()
                await pilot.pause()

            assert app.screen.__class__.__name__ == "ErrorModal"
            assert screen in app.screen_stack
            app.pop_screen()
            await pilot.pause()
            assert app.screen is screen

    asyncio.run(run())


def test_tui_card_uses_chinese_suit_labels() -> None:
    assert "红5" in _plain(_tui_card(Card(5, Suit.HEARTS)))
    assert "方10" in _plain(_tui_card(Card(10, Suit.DIAMONDS)))
    assert "黑A" in _plain(_tui_card(Card(14, Suit.SPADES)))
    assert "梅K" in _plain(_tui_card(Card(13, Suit.CLUBS)))
    assert "大王" in _plain(_tui_card(Card(RANK_BIG_JOKER, Suit.BIG_JOKER)))
    assert "小王" in _plain(_tui_card(Card(RANK_SMALL_JOKER, Suit.SMALL_JOKER)))


def test_tui_card_marks_cursor_selection_and_wild() -> None:
    card = Card(5, Suit.HEARTS)

    assert "▶" in _plain(_tui_card(card, cursor=True))
    assert "✓" in _plain(_tui_card(card, selected=True))
    assert "配" in _plain(_tui_card(card, wild=True))
    assert "▶" in _plain(_tui_card(card, selected=True, cursor=True))
    assert "✓" in _plain(_tui_card(card, selected=True, cursor=True))


def test_tui_history_opens_event_replay_and_steps_between_events() -> None:
    async def run() -> None:
        state = make_initial_state(level=RANK_2, first_player=0, seed=7)
        played_card = state.hands[0][0]
        pattern = find_complete_pattern([played_card], state.wild_card)
        assert pattern is not None
        play_pattern(state, 0, pattern)
        entry = {
            "game_id": "replay-demo",
            "played_at": "2026-07-23T12:00:00",
            "duration_seconds": 12,
            "metadata": {"ai_difficulties": [None, 1, 1, 1]},
            "result": {"player_rank": 1, "guo_a": False},
        }
        detail = {**entry, "events": state.history}

        app = GuandanApp()
        with patch("guandan.tui.screens.history.load_history_list", return_value=[entry]), patch(
            "guandan.tui.screens.history.load_history_detail", return_value=detail
        ):
            async with app.run_test() as pilot:
                history = HistoryScreen()
                app.push_screen(history)
                await pilot.pause()

                history.action_replay()
                await pilot.pause()

                replay = app.screen
                assert isinstance(replay, ReplayScreen)
                assert replay._event_index == 1
                assert "东家出 单张" in _plain(
                    replay.query_one("#replay-timeline").content
                )

                replay.action_first()
                assert replay._event_index == 0
                assert replay.query_one("#btn-replay-previous", Button).disabled
                assert "发牌" in _plain(replay.query_one("#replay-timeline").content)

                replay.action_last()
                assert replay._event_index == 1
                assert replay.query_one("#btn-replay-next", Button).disabled

    asyncio.run(run())


def test_tui_startup_requests_larger_terminal_when_space_is_small() -> None:
    class FakeTTY:
        def isatty(self) -> bool:
            return True

    env = {"TERM": "xterm-256color"}

    assert should_request_terminal_resize(
        RECOMMENDED_COLUMNS - 1,
        RECOMMENDED_LINES,
        env=env,
        stream=FakeTTY(),  # type: ignore[arg-type]
    )
    assert should_request_terminal_resize(
        RECOMMENDED_COLUMNS,
        RECOMMENDED_LINES - 1,
        env=env,
        stream=FakeTTY(),  # type: ignore[arg-type]
    )
    assert not should_request_terminal_resize(
        RECOMMENDED_COLUMNS,
        RECOMMENDED_LINES,
        env=env,
        stream=FakeTTY(),  # type: ignore[arg-type]
    )


def test_tui_startup_resize_can_be_disabled_for_managed_terminals() -> None:
    class FakeTTY:
        def isatty(self) -> bool:
            return True

    assert terminal_resize_disabled({"GUANDAN_TUI_NO_RESIZE": "1"})
    assert not should_request_terminal_resize(
        80,
        24,
        env={"TERM": "xterm-256color", "TMUX": "1"},
        stream=FakeTTY(),  # type: ignore[arg-type]
    )
    assert not should_request_terminal_resize(
        80,
        24,
        env={"TERM": "xterm-256color", "GUANDAN_TUI_NO_RESIZE": "true"},
        stream=FakeTTY(),  # type: ignore[arg-type]
    )


def test_duplicate_cards_are_selected_by_position() -> None:
    """Two equal cards from different decks must not toggle together."""
    async def run() -> None:
        duplicate = Card(5, Suit.HEARTS)
        state = GameState(
            level=2,
            wild_card=None,
            hands=[
                [Card(7, Suit.SPADES), duplicate, duplicate],
                [],
                [],
                [],
            ],
            turn_index=0,
            leader=0,
        )

        app = GuandanApp()
        async with app.run_test() as pilot:
            screen = GameScreen(difficulty=0, existing_state=state)
            app.push_screen(screen)
            await pilot.pause()

            await pilot.press("right")
            await pilot.press("space")
            await pilot.pause()

            assert screen._hand_selected_indices == {1}

    asyncio.run(run())


def test_tui_hint_selects_and_cycles_legal_responses() -> None:
    async def run() -> None:
        table_top = _single(Card(RANK_5, Suit.SPADES))
        state = GameState(
            level=RANK_2,
            wild_card=None,
            hands=[
                [Card(RANK_8, Suit.CLUBS), Card(RANK_J, Suit.HEARTS)],
                [],
                [],
                [],
            ],
            turn_index=0,
            leader=1,
            table=[table_top],
        )

        app = GuandanApp()
        async with app.run_test() as pilot:
            screen = GameScreen(difficulty=0, existing_state=state)
            app.push_screen(screen)
            await pilot.pause()

            screen.action_hint()
            first = set(screen._hand_selected_indices)
            screen.action_hint()
            second = set(screen._hand_selected_indices)

            assert len(first) == 1
            assert len(second) == 1
            assert first != second
            for selected in (first, second):
                pattern = find_complete_pattern(
                    [screen._hand_cards[index] for index in selected],
                    state.wild_card,
                )
                assert pattern is not None
                assert pattern.can_be_played_on(table_top, level=state.level)

    asyncio.run(run())


def test_tui_organizes_during_ai_turn_and_keeps_selection_and_cursor() -> None:
    async def run() -> None:
        selected_card = Card(RANK_3, Suit.DIAMONDS)
        hand = [
            Card(RANK_3, Suit.HEARTS), selected_card,
            Card(RANK_4, Suit.HEARTS), Card(RANK_5, Suit.HEARTS),
            Card(RANK_6, Suit.HEARTS), Card(RANK_7, Suit.HEARTS),
            Card(RANK_8, Suit.CLUBS),
        ]
        state = GameState(
            level=RANK_2,
            wild_card=None,
            hands=[hand, [Card(RANK_8, Suit.SPADES)], [], []],
            turn_index=1,
            leader=1,
        )
        app = GuandanApp()
        async with app.run_test(size=(80, 48)) as pilot:
            screen = GameScreen(difficulty=0, existing_state=state)
            app.push_screen(screen)
            screen._ai_running = True
            await pilot.pause()

            sort_button = screen.query_one("#btn-organize-hand", Button)
            assert not sort_button.disabled
            selected_index = screen._hand_cards.index(selected_card)
            screen._hand_selected_indices = {selected_index}
            screen._hand_cursor = selected_index
            screen._do_render_hand()

            await pilot.click("#btn-organize-hand")
            await pilot.pause()
            assert [screen._hand_cards[index] for index in screen._hand_selected_indices] == [
                selected_card
            ]
            assert screen._hand_cards[screen._hand_cursor] == selected_card
            assert screen._hand_organizer.status.startswith("同花顺优先 ")
            assert screen._hand_group_starts
            assert sort_button.region.width > 0
            hand_text = _plain(str(screen.query_one("#my-hand", Static).content))
            assert "│" not in hand_text and "散牌" not in hand_text
            assert max(cell_len(row) for row in hand_text.splitlines()[2:]) <= 70

            for _ in screen._hand_organizer.arrangements:
                await pilot.press("s")
                await pilot.pause()
                if screen._hand_organizer.current.kind == "rank":
                    break
            assert screen._hand_organizer.status.startswith("点数理 ")
            assert [screen._hand_cards[index] for index in screen._hand_selected_indices] == [
                selected_card
            ]
            state.turn_index = 0
            screen._ai_running = False
            screen.action_play()
            assert state.table[-1].cards == (selected_card,)

    asyncio.run(run())


def test_tui_can_select_and_play_a_whole_organized_group() -> None:
    async def run() -> None:
        hand = [
            Card(RANK_3, Suit.HEARTS), Card(RANK_3, Suit.DIAMONDS),
            Card(RANK_4, Suit.HEARTS), Card(RANK_5, Suit.HEARTS),
            Card(RANK_6, Suit.HEARTS), Card(RANK_7, Suit.HEARTS),
            Card(RANK_8, Suit.CLUBS),
        ]
        state = GameState(
            level=RANK_2, wild_card=None,
            hands=[hand, [], [], []], turn_index=0, leader=0,
        )
        app = GuandanApp()
        async with app.run_test(size=(80, 48)) as pilot:
            screen = GameScreen(difficulty=0, existing_state=state)
            app.push_screen(screen)
            await pilot.pause()
            await pilot.press("s")
            await pilot.pause()
            screen._hand_cursor = next(
                index for index in range(len(screen._hand_cards))
                if screen._hand_organizer.playable_group_at(index) is not None
            )
            group = screen._hand_organizer.playable_group_at(screen._hand_cursor)
            assert group is not None
            await pilot.press("g")
            assert Counter(
                screen._hand_cards[index] for index in screen._hand_selected_indices
            ) == Counter(group[2].cards)
            await pilot.press("g")
            assert not screen._hand_selected_indices
            await pilot.press("g")
            screen.action_play()
            assert Counter(state.table[-1].cards) == Counter(group[2].cards)

    asyncio.run(run())


def test_tui_manual_lock_works_during_ai_turn_and_releases_after_play() -> None:
    async def run() -> None:
        pair = [Card(RANK_3, Suit.HEARTS), Card(RANK_3, Suit.DIAMONDS)]
        hand = [*pair, Card(RANK_4, Suit.HEARTS), Card(RANK_5, Suit.HEARTS),
                Card(RANK_6, Suit.HEARTS), Card(RANK_7, Suit.HEARTS)]
        state = GameState(
            level=RANK_2, wild_card=None,
            hands=[hand, [Card(RANK_8, Suit.SPADES)], [], []],
            turn_index=1, leader=1,
        )
        app = GuandanApp()
        async with app.run_test(size=(80, 48)) as pilot:
            screen = GameScreen(difficulty=0, existing_state=state)
            app.push_screen(screen)
            screen._ai_running = True
            await pilot.pause()
            for card in pair:
                screen._hand_cursor = screen._hand_cards.index(card)
                screen.action_toggle_select()
            lock_button = screen.query_one("#btn-lock-hand", Button)
            assert not lock_button.disabled
            for button_id in (
                "btn-organize-hand", "btn-lock-hand", "btn-next-game", "btn-game-back"
            ):
                button = screen.query_one(f"#{button_id}", Button)
                assert button.region.x + button.region.width <= 80
            await pilot.click("#btn-lock-hand")
            await pilot.pause()
            assert screen._hand_organizer.locked_count == 1
            assert screen._hand_organizer.display_groups[0].locked
            assert "🔒" in _plain(str(screen.query_one("#my-hand", Static).content))
            assert not screen._hand_selected_indices

            await pilot.press("s")
            assert screen._hand_organizer.display_groups[0].locked
            screen._hand_cursor = 0
            await pilot.press("k")
            assert screen._hand_organizer.locked_count == 0

            for card in pair:
                screen._hand_cursor = screen._hand_cards.index(card)
                screen.action_toggle_select()
            await pilot.press("k")
            assert screen._hand_organizer.locked_count == 1
            screen._hand_cursor = 0
            screen.action_select_group()
            assert Counter(screen._hand_cards[i] for i in screen._hand_selected_indices) == Counter(pair)
            state.turn_index = 0
            screen._ai_running = False
            screen.action_play()
            assert state.table[-1].type == PatternType.PAIR
            assert screen._hand_organizer.locked_count == 0

    asyncio.run(run())


def test_old_passes_clear_from_table_after_later_play() -> None:
    """A new top play must stop showing previous passes as active responses."""
    async def run() -> None:
        state = GameState(
            level=2,
            wild_card=None,
            hands=[
                [Card(RANK_4, Suit.HEARTS), Card(RANK_6, Suit.HEARTS)],
                [Card(RANK_7, Suit.HEARTS)],
                [Card(RANK_8, Suit.HEARTS)],
                [Card(RANK_J, Suit.HEARTS)],
            ],
            turn_index=0,
            leader=0,
        )
        play_pattern(state, 0, _single(Card(RANK_4, Suit.HEARTS)))
        pass_turn(state, 3)
        pass_turn(state, 2)
        play_pattern(state, 1, _single(Card(RANK_7, Suit.HEARTS)))

        app = GuandanApp()
        async with app.run_test() as pilot:
            screen = GameScreen(difficulty=0, existing_state=state)
            app.push_screen(screen)
            await pilot.pause()

            assert screen._locked_passed_players() == []
            table = screen.query_one("#table")
            table_text = _plain(table.content)
            assert "北: 过牌" not in table_text
            assert "西: 过牌" not in table_text

    asyncio.run(run())


def test_ai_leader_continues_until_human_turn() -> None:
    """AI 新一轮领出后，应继续推进后续 AI，直到轮到真人。"""

    async def run() -> None:
        state = GameState(
            level=2,
            wild_card=None,
            hands=[
                [Card(9, Suit.HEARTS)],
                [Card(5, Suit.SPADES)],
                [Card(4, Suit.DIAMONDS)],
                [Card(3, Suit.CLUBS), Card(10, Suit.CLUBS)],
            ],
            turn_index=3,
            leader=3,
        )

        app = GuandanApp()
        async with app.run_test() as pilot:
            screen = GameScreen(difficulty=0, existing_state=state)
            screen._ai_rng = random.Random(0)
            app.push_screen(screen)
            await pilot.pause()

            screen._maybe_ai_turn()
            for _ in range(100):
                await asyncio.sleep(0.01)
                await pilot.pause()
                if state.turn_index == 0:
                    break

            assert state.turn_index == 0
            assert len(state.table) >= 3
            assert [screen._last_player_of(p) for p in state.table[-3:]] == [3, 2, 1]

    asyncio.run(run())


def test_ai_turn_loop_uses_counterclockwise_order_for_every_human_seat() -> None:
    """任意真人座位下，AI 新 leader 都应按逆时针行动到真人。"""

    async def run_case(human: int) -> None:
        leader = next_seat_counterclockwise(human)
        second = next_seat_counterclockwise(leader)
        third = next_seat_counterclockwise(second)
        hands = [[] for _ in range(4)]
        hands[human] = [Card(9, Suit.HEARTS)]
        hands[leader] = [Card(3, Suit.CLUBS), Card(10, Suit.CLUBS)]
        hands[second] = [Card(4, Suit.DIAMONDS)]
        hands[third] = [Card(5, Suit.SPADES)]
        state = GameState(
            level=2,
            wild_card=None,
            hands=hands,
            turn_index=leader,
            leader=leader,
        )

        app = GuandanApp()
        async with app.run_test() as pilot:
            screen = GameScreen(difficulty=0, human=human, existing_state=state)
            screen._ai_rng = random.Random(0)
            app.push_screen(screen)
            await pilot.pause()

            screen._maybe_ai_turn()
            for _ in range(100):
                await asyncio.sleep(0.01)
                await pilot.pause()
                if state.turn_index == human:
                    break

            played_players = [
                ev.player for ev in state.history if isinstance(ev, TurnPlayed)
            ]
            assert state.turn_index == human
            assert played_players[-3:] == [leader, second, third]

    async def run() -> None:
        for human in range(4):
            await run_case(human)

    asyncio.run(run())


def test_tui_current_pass_order_ignores_previous_tricks() -> None:
    """当前轮过牌显示不能被旧轮次同玩家过牌顺序污染。"""

    async def run() -> None:
        first = _single(Card(RANK_4, Suit.HEARTS))
        press = _single(Card(RANK_7, Suit.HEARTS))
        state = GameState(
            level=2,
            wild_card=None,
            hands=[
                [Card(RANK_6, Suit.HEARTS)],
                [],
                [],
                [],
            ],
            turn_index=0,
            table=[first, press],
            passed_players={2, 3},
            leader=0,
            history=[
                Pass(player=2, hand_remaining=3),
                Pass(player=3, hand_remaining=3),
                TurnPlayed(player=0, pattern=first, hand_remaining=1),
                Pass(player=3, hand_remaining=1),
                Pass(player=2, hand_remaining=1),
                TurnPlayed(player=1, pattern=press, hand_remaining=0),
                Pass(player=3, hand_remaining=0),
                Pass(player=2, hand_remaining=0),
            ],
        )

        app = GuandanApp()
        async with app.run_test() as pilot:
            screen = GameScreen(difficulty=0, existing_state=state)
            app.push_screen(screen)
            await pilot.pause()

            assert screen._locked_passed_players() == [3, 2]
            table = screen.query_one("#table")
            lines = _plain(table.content).splitlines()
            assert lines.index("  北: 过牌") < lines.index("  西: 过牌")

    asyncio.run(run())


def test_table_display_renders_all_seat_actions_in_current_trick() -> None:
    """当前轮东/北/西/南的出牌或过牌都应稳定出现在出牌区。"""

    async def run() -> None:
        east_play = _triple_pair(RANK_6, RANK_7)
        north_press = _triple_pair(RANK_J, RANK_8)
        state = GameState(
            level=2,
            wild_card=None,
            hands=[
                [Card(RANK_5, Suit.HEARTS)],
                [],
                [],
                [],
            ],
            turn_index=0,
            table=[east_play, north_press],
            passed_players={2, 1},
            leader=0,
            history=[
                TurnPlayed(player=0, pattern=east_play, hand_remaining=1),
                TurnPlayed(player=3, pattern=north_press, hand_remaining=1),
                Pass(player=2, hand_remaining=1),
                Pass(player=1, hand_remaining=1),
            ],
        )

        app = GuandanApp()
        async with app.run_test() as pilot:
            screen = GameScreen(difficulty=0, existing_state=state)
            app.push_screen(screen)
            await pilot.pause()

            table = screen.query_one("#table")
            lines = _plain(table.content).splitlines()

            assert len(lines) == 6
            assert "最大 北家" in lines[0]
            assert "首局无需贡还牌" in lines[1]
            assert any(line.startswith("  东:") and "三带二" in line for line in lines)
            assert any(line.startswith("  北: 最大") and "三带二" in line for line in lines)
            assert any(line == "  西: 过牌" for line in lines)
            assert any(line == "  南: 过牌" for line in lines)

    asyncio.run(run())


def test_table_display_clears_only_current_player_previous_action() -> None:
    """出牌区只在轮到某玩家时清理该玩家上一轮次展示。"""

    async def run() -> None:
        old_actions = {
            0: ("play", _single(Card(RANK_4, Suit.HEARTS))),
            3: ("play", _single(Card(RANK_6, Suit.HEARTS))),
            2: ("pass", None),
            1: ("play", _single(Card(RANK_8, Suit.HEARTS))),
        }
        state = GameState(
            level=2,
            wild_card=None,
            hands=[[Card(RANK_J, Suit.HEARTS)], [], [], []],
            turn_index=0,
            leader=0,
            table=[],
        )

        app = GuandanApp()
        async with app.run_test() as pilot:
            screen = GameScreen(difficulty=0, existing_state=state)
            app.push_screen(screen)
            await pilot.pause()

            screen._displayed_table_actions = dict(old_actions)
            screen._last_display_turn = 3
            screen._refresh_all()

            table = screen.query_one("#table")
            table_text = _plain(table.content)
            assert "东: --" in table_text
            assert "红4" not in table_text
            assert "北:" in table_text
            assert "西: 过牌" in table_text
            assert "南:" in table_text

    asyncio.run(run())


def test_jokers_remain_visible_after_cursor_moves() -> None:
    """Cursor highlighting must not hide joker labels during hand redraw."""
    async def run() -> None:
        state = GameState(
            level=2,
            wild_card=None,
            hands=[
                [
                    Card(RANK_BIG_JOKER, Suit.BIG_JOKER),
                    Card(RANK_SMALL_JOKER, Suit.SMALL_JOKER),
                    Card(14, Suit.SPADES),
                ],
                [],
                [],
                [],
            ],
            turn_index=0,
            leader=0,
        )

        app = GuandanApp()
        async with app.run_test() as pilot:
            screen = GameScreen(difficulty=0, existing_state=state)
            app.push_screen(screen)
            await pilot.pause()

            hand = screen.query_one("#my-hand")
            assert "大王" in _plain(hand.content)
            assert "小王" in _plain(hand.content)

            await pilot.press("right")
            await pilot.pause()

            assert "大王" in _plain(hand.content)
            assert "小王" in _plain(hand.content)

            await pilot.press("right")
            await pilot.pause()

            assert "大王" in _plain(hand.content)
            assert "小王" in _plain(hand.content)

    asyncio.run(run())


def test_two_big_jokers_selected_in_tui_play_as_pair() -> None:
    """Duplicate jokers must be played together as a pair, not collapsed to one."""
    async def run() -> None:
        state = GameState(
            level=2,
            wild_card=None,
            hands=[
                [
                    Card(RANK_BIG_JOKER, Suit.BIG_JOKER),
                    Card(RANK_BIG_JOKER, Suit.BIG_JOKER),
                    Card(RANK_SMALL_JOKER, Suit.SMALL_JOKER),
                ],
                [],
                [],
                [],
            ],
            turn_index=0,
            leader=0,
        )

        app = GuandanApp()
        async with app.run_test() as pilot:
            screen = GameScreen(difficulty=0, existing_state=state)
            app.push_screen(screen)
            await pilot.pause()

            screen.action_toggle_select()
            screen.action_cursor_right()
            screen.action_toggle_select()
            screen.action_play()

            assert len(state.hands[0]) == 1
            assert state.table[-1].type == PatternType.PAIR
            assert state.table[-1].rank == RANK_BIG_JOKER
            assert len(state.table[-1].cards) == 2

    asyncio.run(run())


def test_tui_triple_pair_can_press_lower_triple_pair() -> None:
    """Human JJJ+88 must be playable over 666+77 when 6 is not level."""

    async def run() -> None:
        hand = [
            Card(RANK_J, Suit.HEARTS),
            Card(RANK_J, Suit.DIAMONDS),
            Card(RANK_J, Suit.SPADES),
            Card(RANK_8, Suit.HEARTS),
            Card(RANK_8, Suit.DIAMONDS),
        ]
        state = GameState(
            level=2,
            wild_card=None,
            hands=[hand, [], [], []],
            turn_index=0,
            leader=3,
            table=[_triple_pair(RANK_6, RANK_7)],
        )

        app = GuandanApp()
        async with app.run_test() as pilot:
            screen = GameScreen(difficulty=0, existing_state=state)
            app.push_screen(screen)
            await pilot.pause()

            screen._hand_selected_indices = set(range(5))
            screen.action_play()

            assert len(state.hands[0]) == 0
            assert state.table[-1].type == PatternType.TRIPLE_PAIR
            assert state.table[-1].rank == RANK_J
            assert "你出牌" in screen._last_action

    asyncio.run(run())


def test_tui_reject_message_explains_level_triple_pair_comparison() -> None:
    """When 6 is level, 666+77 is stronger than natural JJJ+88."""

    async def run() -> None:
        hand = [
            Card(RANK_J, Suit.HEARTS),
            Card(RANK_J, Suit.DIAMONDS),
            Card(RANK_J, Suit.SPADES),
            Card(RANK_8, Suit.HEARTS),
            Card(RANK_8, Suit.DIAMONDS),
        ]
        state = GameState(
            level=RANK_6,
            wild_card=Card(RANK_6, Suit.HEARTS),
            hands=[hand, [], [], []],
            turn_index=0,
            leader=3,
            table=[_triple_pair(RANK_6, RANK_7)],
        )

        app = GuandanApp()
        async with app.run_test() as pilot:
            screen = GameScreen(difficulty=0, existing_state=state)
            app.push_screen(screen)
            await pilot.pause()

            screen._hand_selected_indices = set(range(5))
            screen.action_play()

            assert len(state.hands[0]) == 5
            assert len(state.table) == 1
            assert "不能压过桌面" in screen._last_action
            assert "当前级牌 6" in screen._last_action
            assert "666" not in screen._last_action

    asyncio.run(run())


def test_enter_plays_card_even_when_back_button_has_focus() -> None:
    """Enter should remain the play-card shortcut while the game screen is active."""

    async def run() -> None:
        state = GameState(
            level=2,
            wild_card=None,
            hands=[
                [Card(RANK_4, Suit.HEARTS), Card(RANK_8, Suit.CLUBS)],
                [],
                [],
                [],
            ],
            turn_index=0,
            leader=0,
        )

        app = GuandanApp()
        async with app.run_test() as pilot:
            screen = GameScreen(difficulty=0, existing_state=state)
            app.push_screen(screen)
            await pilot.pause()

            screen.query_one("#btn-game-back", Button).focus()
            await pilot.press("space")
            await pilot.press("enter")
            await pilot.pause()

            assert app.screen is screen
            played = [
                ev for ev in state.history if isinstance(ev, TurnPlayed) and ev.player == 0
            ]
            assert played
            assert played[-1].pattern.type == PatternType.SINGLE
            assert len(state.hands[0]) == 1

    asyncio.run(run())


def test_four_jokers_selected_in_tui_play_as_four_joker_bomb() -> None:
    async def run() -> None:
        state = GameState(
            level=2,
            wild_card=None,
            hands=[
                [
                    Card(RANK_BIG_JOKER, Suit.BIG_JOKER),
                    Card(RANK_BIG_JOKER, Suit.BIG_JOKER),
                    Card(RANK_SMALL_JOKER, Suit.SMALL_JOKER),
                    Card(RANK_SMALL_JOKER, Suit.SMALL_JOKER),
                ],
                [],
                [],
                [],
            ],
            turn_index=0,
            leader=0,
        )

        app = GuandanApp()
        async with app.run_test() as pilot:
            screen = GameScreen(difficulty=0, existing_state=state)
            app.push_screen(screen)
            await pilot.pause()

            for _ in range(4):
                screen.action_toggle_select()
                screen.action_cursor_right()
            screen.action_play()

            assert len(state.hands[0]) == 0
            assert state.table[-1].type == PatternType.FOUR_JOKERS
            assert len(state.table[-1].cards) == 4

    asyncio.run(run())


def test_finished_game_can_start_next_round_from_head_team_level() -> None:
    """下一局应以头游所在队伍的最终级牌重新发牌。"""
    async def run() -> None:
        state = GameState(
            level=2,
            wild_card=None,
            hands=[[], [], [], []],
            turn_index=0,
            leader=0,
            finish_order=[1, 3, 0],
            finished=True,
        )
        state.team_levels_final = [2, 5]  # type: ignore[attr-defined]

        app = GuandanApp()
        async with app.run_test() as pilot:
            screen = GameScreen(difficulty=0, existing_state=state, human=0)
            screen._game_saved = True
            with patch.object(screen, "_maybe_ai_turn"):
                app.push_screen(screen)
                await pilot.pause()

                next_button = screen.query_one("#btn-next-game", Button)
                assert next_button.disabled is False
                assert "级牌 5" in str(next_button.label)
                assert "第 1 局 · 本局结束 · 本局级牌 2" in str(
                    screen.query_one("#status-bar", Static).render()
                )
                assert "本局级牌 2" in screen.sub_title
                assert "下一局级牌 5" in screen.sub_title

                screen.action_next_game()
                # This test advances the tribute stage explicitly below;
                # CPU load must not let its animation timer race the assertion.
                assert screen._tribute_timer is not None
                screen._tribute_timer.stop()
                await pilot.pause()
                assert screen.state is state
                dealt_state = screen._state()
                assert dealt_state is not state
                assert dealt_state.level == 5
                assert len(dealt_state.hands[0]) == 27
                assert "手牌已发放" in screen.sub_title
                assert "第 2 局 · 发牌中 · 本局级牌 5" in str(
                    screen.query_one("#status-bar", Static).render()
                )

                screen._begin_next_game_tribute()
                choice = screen.session.pending_next_game_choice()
                if choice is not None:
                    screen._finish_next_game(choice.cards[0])

                assert screen.state is not state
                assert screen.state is not None
                assert screen.state.level == 5
                assert screen.state.team_levels == [2, 5]
                assert screen.state.finished is False
                assert len(screen.state.hands[0]) == 27
                assert screen._game_saved is False
                assert "局开始" in screen._last_action
                assert "第 2 局 · 本局开始 · 本局级牌 5" in str(
                    screen.query_one("#status-bar", Static).render()
                )

    asyncio.run(run())


def test_next_round_applies_tribute_card_swaps_and_records_events() -> None:
    """下一局开始时应真实执行进贡/还贡，而不是只计算先手。"""

    async def run() -> None:
        state = GameState(
            level=2,
            wild_card=None,
            hands=[[], [], [], []],
            turn_index=0,
            leader=0,
            finish_order=[0, 1, 2],
            finished=True,
        )
        state.team_levels_final = [5, 2]

        app = GuandanApp()
        async with app.run_test() as pilot:
            screen = GameScreen(difficulty=0, existing_state=state, human=0)
            screen._game_saved = True
            with patch.object(screen, "_maybe_ai_turn"):
                app.push_screen(screen)
                await pilot.pause()

                fixed_hands = [
                    [Card(RANK_3, Suit.HEARTS), Card(RANK_4, Suit.HEARTS)],
                    [Card(RANK_4, Suit.SPADES), Card(RANK_6, Suit.SPADES)],
                    [Card(RANK_5, Suit.CLUBS), Card(RANK_7, Suit.CLUBS)],
                    [Card(RANK_BIG_JOKER, Suit.BIG_JOKER), Card(RANK_8, Suit.CLUBS)],
                ]

                def fake_initial_state(**kwargs) -> GameState:
                    return GameState(
                        level=kwargs["level"],
                        wild_card=Card(RANK_5, Suit.HEARTS),
                        hands=[list(hand) for hand in fixed_hands],
                        turn_index=kwargs["first_player"],
                        leader=kwargs["first_player"],
                        team_levels=list(kwargs["team_levels"]),
                    )

                with patch("guandan.ui.session.make_initial_state", fake_initial_state):
                    screen.action_next_game()
                    await pilot.pause()
                    assert screen.state is state
                    assert screen._state().hands[0] == fixed_hands[0]
                    assert screen.session.tribute_events() == ()

                    screen._begin_next_game_tribute()
                    choice = screen.session.pending_next_game_choice()
                    assert choice is not None
                    assert len(screen._state().hands[0]) == 3
                    assert Card(RANK_BIG_JOKER, Suit.BIG_JOKER) in screen._state().hands[0]
                    table = screen.query_one("#table", TableWidget)
                    assert "本局贡还牌" in str(table.content)
                    assert "进贡" in str(table.content)
                    screen._finish_next_game(choice.cards[0])

                assert screen.state is not None
                assert screen.state.turn_index == 3
                assert all(len(hand) == 2 for hand in screen.state.hands)
                assert Card(RANK_BIG_JOKER, Suit.BIG_JOKER) in screen.state.hands[0]
                assert Card(RANK_3, Suit.HEARTS) in screen.state.hands[3]
                assert any(isinstance(event, TributeSent) for event in screen.state.history)
                assert any(isinstance(event, TributeReturned) for event in screen.state.history)
                table = screen.query_one("#table", TableWidget)
                assert "本局贡还牌" in str(table.content)
                assert "进贡" in str(table.content)
                assert "还贡" in str(table.content)

    asyncio.run(run())


def test_tui_shows_tribute_result_when_human_did_not_participate() -> None:
    async def run() -> None:
        state = GameState(
            level=RANK_5,
            wild_card=None,
            hands=[[], [], [], []],
            turn_index=0,
            history=[
                TributeSent(3, 1, Card(RANK_BIG_JOKER, Suit.BIG_JOKER)),
                TributeReturned(1, 3, Card(RANK_4, Suit.HEARTS)),
            ],
        )
        app = GuandanApp()
        async with app.run_test() as pilot:
            screen = GameScreen(difficulty=0, existing_state=state, human=0, round_index=2)
            with patch.object(screen, "_maybe_ai_turn"):
                app.push_screen(screen)
                await pilot.pause()
                table = screen.query_one("#table", TableWidget)
                assert "北家→南家进贡 大王" in str(table.content)
                assert "南家→北家还贡 红4♥" in str(table.content)
                assert "你未参与贡还牌" in str(table.content)

                state.history = [TributeResisted(player=3, team=1, reason="single")]
                screen._refresh_all()
                assert "北家抗贡，本局没有换牌" in str(table.content)

    asyncio.run(run())


def test_match_finished_disables_next_round_button() -> None:
    async def run() -> None:
        state = GameState(
            level=14,
            wild_card=None,
            hands=[[], [], [], []],
            turn_index=0,
            leader=0,
            finish_order=[0, 2, 1],
            finished=True,
            match_finished=True,
            winner_team=0,
        )
        state.team_levels_final = [2, 14]

        app = GuandanApp()
        async with app.run_test() as pilot:
            screen = GameScreen(difficulty=0, existing_state=state, human=0)
            app.push_screen(screen)
            await pilot.pause()

            next_button = screen.query_one("#btn-next-game", Button)
            assert next_button.disabled is True
            assert "比赛已结束" in str(next_button.label)
            assert "本局级牌 A" in screen.sub_title
            assert "下一局级牌" not in screen.sub_title

    asyncio.run(run())


def test_next_round_first_player_uses_last_when_third_and_last_different_teams() -> None:
    async def run() -> None:
        state = GameState(
            level=2,
            wild_card=None,
            hands=[[], [], [], []],
            turn_index=0,
            leader=0,
            finish_order=[0, 1, 2],  # 三游西，末游北，不同队
            finished=True,
        )
        hands = [
            [Card(RANK_4, Suit.HEARTS)],
            [Card(RANK_BIG_JOKER, Suit.BIG_JOKER)],
            [Card(RANK_4, Suit.SPADES)],
            [Card(RANK_6, Suit.CLUBS)],
        ]

        app = GuandanApp()
        async with app.run_test() as pilot:
            screen = GameScreen(difficulty=0, existing_state=state, human=0)
            app.push_screen(screen)
            await pilot.pause()
            assert screen._next_round_first_player_for_hands(state, hands) == 3

    asyncio.run(run())


def test_next_round_first_player_compares_double_tribute_cards() -> None:
    async def run() -> None:
        state = GameState(
            level=2,
            wild_card=None,
            hands=[[], [], [], []],
            turn_index=0,
            leader=0,
            finish_order=[0, 2, 1],  # 三游南，末游北，同为下游方
            finished=True,
        )
        hands = [
            [Card(RANK_4, Suit.HEARTS)],
            [Card(RANK_BIG_JOKER, Suit.BIG_JOKER)],
            [Card(RANK_4, Suit.SPADES)],
            [Card(RANK_8, Suit.CLUBS)],
        ]

        app = GuandanApp()
        async with app.run_test() as pilot:
            screen = GameScreen(difficulty=0, existing_state=state, human=0)
            app.push_screen(screen)
            await pilot.pause()
            assert screen._next_round_first_player_for_hands(state, hands) == 1

    asyncio.run(run())


def test_next_round_first_player_uses_next_level_wild_card() -> None:
    async def run() -> None:
        state = GameState(
            level=2,
            wild_card=None,
            hands=[[], [], [], []],
            turn_index=0,
            leader=0,
            finish_order=[0, 2, 1],  # 三游南，末游北，同为下游方
            finished=True,
        )
        state.team_levels_final = [5, 2]
        hands = [
            [Card(RANK_4, Suit.HEARTS)],
            [Card(RANK_5, Suit.HEARTS), Card(RANK_7, Suit.CLUBS)],
            [Card(RANK_4, Suit.SPADES)],
            [Card(RANK_8, Suit.CLUBS)],
        ]

        app = GuandanApp()
        async with app.run_test() as pilot:
            screen = GameScreen(difficulty=0, existing_state=state, human=0)
            app.push_screen(screen)
            await pilot.pause()
            assert screen._next_round_first_player_for_hands(state, hands) == 3

    asyncio.run(run())
