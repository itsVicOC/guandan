"""GameState 集成测试。"""
from __future__ import annotations

import pytest

from guandan.engine.card import (
    RANK_2,
    RANK_3,
    RANK_4,
    RANK_5,
    RANK_6,
    RANK_7,
    RANK_8,
    RANK_9,
    RANK_A,
    RANK_BIG_JOKER,
    RANK_J,
    RANK_SMALL_JOKER,
    Card,
    Suit,
)
from guandan.engine.events import Claim, TurnPlayed
from guandan.engine.hand import Pattern, PatternType
from guandan.engine.state import (
    GameState,
    IllegalPlayError,
    make_initial_state,
    next_seat_counterclockwise,
    pass_turn,
    play_pattern,
)


def c(rank, suit="H"):
    s_map = {"H": Suit.HEARTS, "D": Suit.DIAMONDS, "S": Suit.SPADES, "C": Suit.CLUBS}
    return Card(rank, s_map[suit])


def single_pattern(card):
    return Pattern(PatternType.SINGLE, card.rank, 1, (card,), 0)


class TestInitialState:
    def test_initial_state(self):
        state = make_initial_state(level=2, first_player=0, seed=42)
        assert state.level == 2
        assert len(state.hands) == 4
        for h in state.hands:
            assert len(h) == 27
        assert state.turn_index == 0
        assert state.leader == 0
        assert not state.finished
        assert len(state.history) == 1  # ShuffleDeal
        assert state.wild_card is not None

    def test_seed_reproducibility(self):
        s1 = make_initial_state(level=5, first_player=0, seed=42)
        s2 = make_initial_state(level=5, first_player=0, seed=42)
        for h1, h2 in zip(s1.hands, s2.hands):
            assert h1 == h2

    @pytest.mark.parametrize("first_player", [-1, 4])
    def test_rejects_invalid_first_player(self, first_player):
        with pytest.raises(ValueError, match="first_player"):
            make_initial_state(level=2, first_player=first_player, seed=42)


class TestPlayPattern:
    def test_first_play(self):
        state = make_initial_state(level=2, first_player=0, seed=42)
        p = single_pattern(state.hands[0][0])
        play_pattern(state, 0, p)
        assert state.table == [p]
        assert state.hand_size(0) == 26
        assert state.turn_index == 3

    def test_auto_claim_when_hand_reaches_ten(self):
        state = GameState(
            level=2,
            wild_card=None,
            hands=[
                [c(RANK_3)] * 11,
                [c(RANK_4)],
                [c(RANK_5)],
                [c(RANK_6)],
            ],
            turn_index=0,
            leader=0,
        )

        play_pattern(state, 0, single_pattern(c(RANK_3)))

        assert isinstance(state.history[-1], Claim)
        assert state.history[-1].player == 0
        assert state.history[-1].count == 10
        assert any(isinstance(event, TurnPlayed) for event in state.history)

    def test_manual_claim_rejects_more_than_ten_cards(self):
        from guandan.engine.state import claim

        state = GameState(
            level=2,
            wild_card=None,
            hands=[
                [c(RANK_3)] * 11,
                [c(RANK_4)],
                [c(RANK_5)],
                [c(RANK_6)],
            ],
            turn_index=0,
            leader=0,
        )

        with pytest.raises(IllegalPlayError, match="hand size <= 10"):
            claim(state, 0, 11)

    def test_leader_play_advances_counterclockwise_from_every_seat(self):
        for leader in range(4):
            lead_card = c(RANK_3, "H")
            hands = [[c(RANK_8, "S")] for _ in range(4)]
            hands[leader] = [lead_card, c(RANK_A, "C")]
            state = GameState(
                level=RANK_2,
                wild_card=None,
                hands=hands,
                turn_index=leader,
                leader=leader,
            )

            play_pattern(state, leader, single_pattern(lead_card))

            assert state.turn_index == next_seat_counterclockwise(leader)

    def test_press(self):
        state = make_initial_state(level=2, first_player=0, seed=42)
        state.wild_card = None
        state.hands[0] = [c(RANK_3, "H"), c(RANK_6, "H")]
        state.hands[3] = [c(RANK_4, "H"), c(RANK_7, "H")]
        p0 = single_pattern(c(RANK_3, "H"))
        p3 = single_pattern(c(RANK_4, "H"))
        play_pattern(state, 0, p0)
        play_pattern(state, 3, p3)
        assert state.table[-1] == p3
        assert state.turn_index == 2

    def test_cannot_press_smaller(self):
        state = make_initial_state(level=2, first_player=0, seed=42)
        p0_hand = state.hands[0]
        p1_hand = state.hands[3]
        c_big = max(p0_hand, key=lambda c: (c.rank, c.is_joker))
        c_small = min(p1_hand, key=lambda c: (c.rank, not c.is_joker))
        p_big = single_pattern(c_big)
        p_small = single_pattern(c_small)
        play_pattern(state, 0, p_big)
        with pytest.raises(IllegalPlayError):
            play_pattern(state, 3, p_small)

    def test_cannot_play_out_of_turn(self):
        state = make_initial_state(level=2, first_player=0, seed=42)
        c = state.hands[2][0]
        p = single_pattern(c)
        with pytest.raises(IllegalPlayError):
            play_pattern(state, 2, p)

    def test_rejects_forged_pattern(self):
        cards = [c(RANK_3), c(RANK_4), c(RANK_5), c(RANK_6)]
        state = GameState(
            level=RANK_2,
            wild_card=None,
            hands=[cards, [], [], []],
            turn_index=0,
            leader=0,
        )
        forged_bomb = Pattern(PatternType.BOMB, RANK_6, 4, tuple(cards))

        with pytest.raises(IllegalPlayError, match="legal interpretation"):
            play_pattern(state, 0, forged_bomb)

        assert state.hands[0] == cards
        assert state.table == []

    def test_level_card_single_can_press_higher_natural_rank(self):
        state = GameState(
            level=RANK_2,
            wild_card=c(RANK_2, "H"),
            hands=[
                [c(RANK_2, "D")],
                [],
                [],
                [],
            ],
            turn_index=0,
            table=[single_pattern(c(RANK_8, "S"))],
            leader=3,
        )

        play_pattern(state, 0, single_pattern(c(RANK_2, "D")))

        assert state.table[-1].rank == RANK_2

    def test_bomb_count_tracks_straight_flush_and_four_jokers(self):
        state = GameState(
            level=RANK_2,
            wild_card=None,
            hands=[
                [
                    c(RANK_3, "H"),
                    c(RANK_4, "H"),
                    c(RANK_5, "H"),
                    c(RANK_6, "H"),
                    c(RANK_7, "H"),
                ],
                [],
                [
                    Card(101, Suit.BIG_JOKER),
                    Card(101, Suit.BIG_JOKER),
                    Card(100, Suit.SMALL_JOKER),
                    Card(100, Suit.SMALL_JOKER),
                ],
                [],
            ],
            turn_index=0,
            leader=0,
        )
        straight_flush = Pattern(
            PatternType.STRAIGHT_FLUSH,
            RANK_7,
            5,
            tuple(state.hands[0]),
            0,
        )
        play_pattern(state, 0, straight_flush)
        state.table.clear()
        state.leader = 2
        state.turn_index = 2
        four_jokers = Pattern(
            PatternType.FOUR_JOKERS,
            101,
            4,
            tuple(state.hands[2]),
            0,
        )
        play_pattern(state, 2, four_jokers)

        assert state.team_bomb_count == [2, 0]

    def test_duplicate_card_count_must_exist_in_hand(self):
        big_joker = Card(RANK_BIG_JOKER, Suit.BIG_JOKER)
        state = GameState(
            level=RANK_2,
            wild_card=None,
            hands=[[big_joker], [], [], []],
            turn_index=0,
            leader=0,
        )
        malformed = Pattern(
            PatternType.PAIR,
            RANK_BIG_JOKER,
            1,
            (big_joker, big_joker),
            0,
        )

        with pytest.raises(IllegalPlayError):
            play_pattern(state, 0, malformed)


class TestPassTurn:
    def test_leader_cannot_pass(self):
        state = make_initial_state(level=2, first_player=0, seed=42)
        with pytest.raises(IllegalPlayError):
            pass_turn(state, 0)

    def test_three_passes_ends_trick(self):
        state = make_initial_state(level=2, first_player=0, seed=42)
        c = state.hands[0][0]
        play_pattern(state, 0, single_pattern(c))
        pass_turn(state, 3)
        pass_turn(state, 2)
        pass_turn(state, 1)
        # 第 3 次 pass 后，trick 应结束，leader 继续
        assert state.table == []
        assert state.turn_index == 0
        assert state.leader == 0

    def test_current_top_player_leads_after_all_others_pass(self):
        """后手压牌后，下一轮应由当前最大牌玩家领出，而不是原始先手。"""
        state = make_initial_state(level=RANK_5, first_player=0, seed=42)
        state.wild_card = None
        state.hands[0] = [c(RANK_2, "H"), c(RANK_6, "H")]
        state.hands[1] = [c(RANK_7, "H")]
        state.hands[2] = [c(RANK_8, "H")]
        state.hands[3] = [c(RANK_J, "H"), c(RANK_A, "H")]

        play_pattern(state, 0, single_pattern(c(RANK_2, "H")))
        play_pattern(state, 3, single_pattern(c(RANK_J, "H")))
        pass_turn(state, 2)
        pass_turn(state, 1)
        pass_turn(state, 0)

        assert state.table == []
        assert state.passed_players == set()
        assert state.turn_index == 3
        assert state.leader == 3

    def test_new_leader_keeps_counterclockwise_order_after_winning_trick(self):
        """AI/后手拿到牌权再领出时，仍按逆时针推进。"""
        state = make_initial_state(level=RANK_2, first_player=0, seed=42)
        state.wild_card = None
        state.hands[0] = [c(RANK_3, "H"), c(RANK_4, "H")]
        state.hands[1] = [c(RANK_5, "H")]
        state.hands[2] = [c(RANK_8, "H"), c(RANK_9, "H")]
        state.hands[3] = [c(RANK_6, "H")]

        play_pattern(state, 0, single_pattern(c(RANK_3, "H")))
        pass_turn(state, 3)
        play_pattern(state, 2, single_pattern(c(RANK_8, "H")))
        pass_turn(state, 1)
        pass_turn(state, 0)
        # 3 曾在更早的桌顶过牌，但西家压牌后必须再次询问。
        assert state.turn_index == 3
        pass_turn(state, 3)

        assert state.table == []
        assert state.leader == 2
        assert state.turn_index == 2

        play_pattern(state, 2, single_pattern(c(RANK_9, "H")))

        assert state.turn_index == 1

    def test_trick_ends_immediately_when_press_leaves_no_responder(self):
        """压牌后若其他可行动玩家已全过，本轮应立即结束。"""
        state = make_initial_state(level=RANK_5, first_player=0, seed=42)
        state.wild_card = None
        state.hands[0] = [c(RANK_2, "H")]
        state.hands[1] = [c(RANK_7, "H")]
        state.hands[2] = [c(RANK_8, "H")]
        state.hands[3] = [c(RANK_J, "H"), c(RANK_A, "H")]

        play_pattern(state, 0, single_pattern(c(RANK_2, "H")))
        play_pattern(state, 3, single_pattern(c(RANK_J, "H")))
        pass_turn(state, 2)
        pass_turn(state, 1)

        assert state.table == []
        assert state.passed_players == set()
        assert state.turn_index == 3
        assert state.leader == 3


class TestJiefeng_Document:
    """按文档规则：接风只发生在"出完手牌 + 无人压牌"的双重条件下。"""

    def test_finisher_then_press_no_jiefeng(self):
        """玩家 A 出完最后一手后，B 立即压牌 → 不接风，本轮继续。"""
        state = make_initial_state(level=2, first_player=0, seed=42)
        # 强制让 player 0 一手出完
        state.hands[0] = [c(RANK_5)]
        state.turn_index = 0
        play_pattern(state, 0, single_pattern(c(RANK_5)))
        # player 0 已出完
        assert 0 in state.finish_order
        # leader 仍是 0（trick 还没结束）
        assert state.leader == 0
        # turn 按逆时针推进到 3
        assert state.turn_index == 3
        # 现在 player 3 压牌
        p1_card = state.hands[3][0]
        play_pattern(state, 3, single_pattern(p1_card))
        # 接风未触发，leader 仍为 0（trick 中）
        assert state.leader == 0
        # 轮到 2
        assert state.turn_index == 2
        # player 0 仍在 finish_order
        assert 0 in state.finish_order

    def test_finisher_then_all_pass_triggers_jiefeng(self):
        """玩家 A 出完最后一手后，其他可行动玩家全过 → 触发接风，对家领出。"""
        state = make_initial_state(level=2, first_player=0, seed=42)
        state.hands[0] = [c(RANK_5)]
        state.turn_index = 0
        play_pattern(state, 0, single_pattern(c(RANK_5)))
        # player 0 已出完；leader 仍是 0；turn 逆时针推进到 3
        assert 0 in state.finish_order
        assert state.leader == 0
        assert state.turn_index == 3
        # 3, 2, 1 都过
        pass_turn(state, 3)
        pass_turn(state, 2)
        pass_turn(state, 1)
        # 触发接风：leader 切到对家 (0+2)%4 = 2
        assert state.leader == 2
        assert state.turn_index == 2
        assert state.table == []

    def test_two_finishers_jiefeng_uses_active_count(self):
        """两个 finisher 时，active_non_leader = 2，2 次 pass 就触发接风。"""
        state = make_initial_state(level=2, first_player=0, seed=42)
        # 直接构造一个 0+2 都已 finished 的状态
        state.finish_order = [0, 2]
        state.leader = 0
        state.turn_index = 1
        state.table = [single_pattern(c(RANK_5))]
        state.pass_count = 0

        # 1 + 3 pass → 触发接风（active non-leader = 2, 即 1 和 3）
        pass_turn(state, 1)
        pass_turn(state, 3)

        # 接风触发：0 的对家 = 2，但 2 已 finished → 找下一个 active
        assert state.leader in (1, 3)
        assert state.leader not in state.finish_order


class TestGameCompletion_Document:
    """按文档：3rd 出完才结束，剩 1 人是末游。"""

    def test_three_finishers_ends_game(self):
        """3 个玩家出完手牌后游戏结束。"""
        state = make_initial_state(level=2, first_player=0, seed=42)

        def play_all(player):
            for c in list(state.hands[player]):
                if state.finished:
                    break
                while state.turn_index != player and not state.finished:
                    pass_turn(state, state.turn_index)
                # 检查是否能压当前桌牌
                top = state.table[-1] if state.table else None
                if top and c.rank <= top.rank:
                    # 不能压：让别人过牌再出
                    while state.turn_index != player and not state.finished:
                        pass_turn(state, state.turn_index)
                    if state.table and c.rank <= state.table[-1].rank:
                        # 还是不能压，跳过这张牌
                        state.hands[player].remove(c)
                        # 但这会让 hand 数量对不上... 简化：直接 break
                        break
                play_pattern(state, player, single_pattern(c))

        # 简化方案：让 0 一直出完，然后让剩余玩家都过牌，逼 1 也出完
        # 但这不可行，因为 0 出完手牌后，1 必须能压
        # 改用更稳健的方式：直接构造状态
        from guandan.engine.state import _finish_game

        state = make_initial_state(level=2, first_player=0, seed=42)
        state.finish_order = [0, 1, 2]  # 头游 0, 二游 1, 三游 2
        # 给末游 3 留一些牌
        from guandan.engine.card import RANK_5

        state.hands[3] = [c(RANK_5), c(RANK_6), c(RANK_7)]
        state.team_bomb_count = [0, 0]
        _finish_game(state)

        assert state.finished
        assert state.finish_order == [0, 1, 2]
        # 末游 = 3
        assert 3 not in state.finish_order

    def test_level_up_per_document(self):
        """按文档：头游+二游(同队) → +3 级；头游+三游(同队) → +2；头游+末游(同队) → +1。"""
        from guandan.engine.state import _finish_game

        # 场景 1：头游+二游同队 → team0 +3
        state = make_initial_state(level=2, first_player=0, seed=42)
        state.finish_order = [0, 2, 1]
        state.hands[3] = [c(RANK_5)]  # 末游
        state.team_bomb_count = [0, 0]
        _finish_game(state)
        assert state.finished
        assert state.team_levels_final[0] == 5  # 2 + 3
        assert state.team_levels_final[1] == 2  # 对方不变

        # 场景 2：头游+三游同队 → team0 +2
        state = make_initial_state(level=2, first_player=0, seed=42)
        state.finish_order = [0, 1, 2]
        state.hands[3] = [c(RANK_5)]
        state.team_bomb_count = [0, 0]
        _finish_game(state)
        assert state.team_levels_final[0] == 4  # 2 + 2
        assert state.team_levels_final[1] == 2  # 对方不变

        # 场景 3：头游+末游同队 → team0 +1
        state = make_initial_state(level=2, first_player=0, seed=42)
        state.finish_order = [0, 1, 3]
        state.hands[2] = [c(RANK_5)]
        state.team_bomb_count = [0, 0]
        _finish_game(state)
        assert state.team_levels_final[0] == 3  # 2 + 1
        assert state.team_levels_final[1] == 2  # 对方不变

    def test_level_up_uses_each_team_starting_level(self):
        """连续多局时，头游方按本队级牌升级，对方保持自己的最终级牌。"""
        from guandan.engine.state import _finish_game

        state = make_initial_state(
            level=2,
            first_player=0,
            seed=42,
            team_levels=[2, 5],
        )
        state.finish_order = [0, 2, 1]  # 东西双下
        state.hands[3] = [c(RANK_5)]
        _finish_game(state)

        assert state.team_levels_final == [5, 5]

        next_state = make_initial_state(
            level=state.team_levels_final[0],
            first_player=state.finish_order[0],
            seed=43,
            team_levels=state.team_levels_final,
        )
        assert next_state.level == 5
        assert next_state.team_levels == [5, 5]
        assert next_state.turn_index == 0

    def test_guo_a_requires_shuangshang(self):
        """过 A 必须"双上"：队友是 2nd/3rd（即头游+二游 或 头游+三游）才算成功。"""
        from guandan.engine.state import _finish_game

        # 在 A 这一局：头游+二游（同队）→ 过 A 成功
        state = make_initial_state(level=RANK_A, first_player=0, seed=42)
        state.finish_order = [0, 2, 1]  # 头游+二游同队
        state.hands[3] = [c(RANK_5)]
        state.team_bomb_count = [3, 0]  # +3 双上 + 0 炸弹 = +3
        _finish_game(state)
        assert state.guo_a is True
        assert state.match_finished is True
        assert state.winner_team == 0
        # 头游方回到 2
        assert state.team_levels_final[0] == 2

        # 在 A 这一局：头游+末游（同队）→ 冲 A 失败
        state = make_initial_state(level=RANK_A, first_player=0, seed=42)
        state.finish_order = [0, 1, 3]  # 头游+末游同队
        state.hands[2] = [c(RANK_5)]
        state.team_bomb_count = [1, 0]  # +1
        _finish_game(state)
        assert state.guo_a is False
        assert state.guo_a_failed is True
        assert state.match_finished is False
        assert state.winner_team is None
        # 第一次未过 A 仍打 A；第三次才退回 2。
        assert state.team_levels_final[0] == RANK_A
        assert state.a_failure_counts == [1, 1]

    @pytest.mark.parametrize("prior_failures,expected_level,expected_count", [
        (0, RANK_A, 1), (1, RANK_A, 2), (2, RANK_2, 0),
    ])
    def test_three_a_failures_before_reset(self, prior_failures, expected_level, expected_count):
        from guandan.engine.state import _finish_game

        state = make_initial_state(
            level=RANK_A, seed=42, a_failure_counts=[prior_failures, 0],
        )
        state.finish_order = [0, 1, 3]  # A 队头游、队友末游
        _finish_game(state)
        assert state.guo_a_failed and not state.match_finished
        assert state.team_levels_final == [expected_level, RANK_A]
        assert state.a_failure_counts == [expected_count, 1]

    @pytest.mark.parametrize("prior_failures,expected_level,expected_count", [
        (0, RANK_A, 1), (1, RANK_A, 2), (2, RANK_2, 0),
    ])
    def test_a_team_losing_head_also_counts_as_failed_pass(
        self, prior_failures, expected_level, expected_count,
    ):
        from guandan.engine.state import _finish_game

        state = make_initial_state(
            level=RANK_A, seed=42, team_levels=[RANK_A, 5],
            a_failure_counts=[prior_failures, 0],
        )
        state.finish_order = [1, 0, 3]  # 非 A 队头游、队友三游
        _finish_game(state)
        assert state.guo_a_failed and not state.match_finished
        assert state.team_levels_final == [expected_level, 7]
        assert state.a_failure_counts == [expected_count, 0]

    def test_a_success_ends_match_after_two_prior_failures(self):
        from guandan.engine.state import _finish_game

        state = make_initial_state(level=RANK_A, seed=42, a_failure_counts=[2, 0])
        state.finish_order = [0, 2, 1]
        _finish_game(state)
        assert state.guo_a and state.match_finished and state.winner_team == 0
        assert state.a_failure_counts == [2, 0]

    def test_historical_v2_failure_keeps_original_single_reset_for_replay(self):
        from guandan.ai.benchmark import _prepare_next_round
        from guandan.engine.state import _finish_game

        state = make_initial_state(level=RANK_A, seed=42, ruleset_version=2)
        state.finish_order = [0, 1, 3]
        _finish_game(state)
        assert state.team_levels_final == [RANK_2, RANK_A]
        assert state.a_failure_counts == [0, 0]
        next_state = _prepare_next_round(state, 43)
        assert next_state.ruleset_version == 2 and next_state.level == RANK_2

    def test_a_failure_count_carries_into_next_round_and_replays(self):
        from guandan.ai.benchmark import _prepare_next_round
        from guandan.engine.replay import replay_events
        from guandan.engine.state import _finish_game

        state = make_initial_state(
            level=RANK_A, seed=42, team_levels=[RANK_A, 2],
            a_failure_counts=[1, 0],
        )
        state.finish_order = [0, 1, 3]
        _finish_game(state)
        next_state = _prepare_next_round(state, 43)
        assert next_state.level == RANK_A
        assert next_state.a_failure_counts == [2, 0]
        assert replay_events(next_state.history).a_failure_counts == [2, 0]

    def test_bomb_finish_does_not_add_extra_level(self):
        """漂牌扩展玩法不启用：5 张以上含级牌炸弹也不额外升级。"""
        from guandan.engine.state import _finish_game

        state = make_initial_state(level=RANK_5, first_player=0, seed=42)
        cards = [
            c(RANK_5, "H"),
            c(RANK_5, "D"),
            c(RANK_5, "S"),
            c(RANK_5, "C"),
            c(RANK_5, "H"),
            c(RANK_5, "D"),
        ]
        pattern = Pattern(PatternType.BOMB, RANK_5, 6, tuple(cards), 0)
        state.history.append(TurnPlayed(player=0, pattern=pattern, hand_remaining=0))
        state.finish_order = [0, 2, 1]
        state.hands[3] = [c(RANK_7)]

        _finish_game(state)

        assert state.drift_flag is False
        assert state.drift is False
        assert state.team_levels_final[0] == RANK_5 + 3


class TestPassResponseWindow:
    """过牌只回应当前桌顶；每次压牌都会重新开放其他玩家的机会。"""

    @staticmethod
    def _state(*, ruleset_version: int = 2) -> GameState:
        return GameState(
            level=RANK_5,
            wild_card=None,
            hands=[
                [c(RANK_2, "H"), c(RANK_6, "H"), c(RANK_9, "H")],
                [c(RANK_7, "H"), c(RANK_9, "H")],
                [c(RANK_3, "H"), c(RANK_8, "H")],
                [c(RANK_4, "H"), c(RANK_J, "H")],
            ],
            turn_index=0,
            leader=0,
            ruleset_version=ruleset_version,
        )

    def test_old_pass_does_not_skip_player_after_new_top(self):
        state = self._state()
        play_pattern(state, 0, single_pattern(c(RANK_2, "H")))
        pass_turn(state, 3)
        assert state.passed_players == {3}
        play_pattern(state, 2, single_pattern(c(RANK_3, "H")))
        assert state.passed_players == set()
        pass_turn(state, 1)
        assert state.passed_players == {1}
        play_pattern(state, 0, single_pattern(c(RANK_6, "H")))
        assert state.passed_players == set()
        assert state.turn_index == 3
        play_pattern(state, 3, single_pattern(c(RANK_J, "H")))
        assert state.turn_index == 2

    def test_same_player_can_pass_twice_before_trick_ends(self):
        state = self._state()
        play_pattern(state, 0, single_pattern(c(RANK_2, "H")))
        pass_turn(state, 3)
        play_pattern(state, 2, single_pattern(c(RANK_3, "H")))
        pass_turn(state, 1)
        play_pattern(state, 0, single_pattern(c(RANK_6, "H")))
        pass_turn(state, 3)
        assert state.turn_index == 2
        pass_turn(state, 2)
        assert state.turn_index == 1
        pass_turn(state, 1)
        assert state.table == []
        assert state.turn_index == 0

    def test_joker_requires_south_and_east_to_answer_after_west_passes(self):
        joker = Card(RANK_SMALL_JOKER, Suit.SMALL_JOKER)
        state = GameState(
            level=RANK_5,
            wild_card=None,
            hands=[
                [c(RANK_7), c(RANK_8)],
                [c(RANK_5), c(RANK_6)],
                [c(RANK_3), c(RANK_4)],
                [joker, c(RANK_J)],
            ],
            turn_index=2,
            leader=2,
        )
        play_pattern(state, 2, single_pattern(c(RANK_3)))
        pass_turn(state, 1)
        pass_turn(state, 0)
        play_pattern(state, 3, single_pattern(joker))
        pass_turn(state, 2)
        assert state.turn_index == 1
        assert state.table[-1].cards == (joker,)
        pass_turn(state, 1)
        assert state.turn_index == 0
        pass_turn(state, 0)
        assert state.table == []
        assert state.turn_index == 3

    def test_legacy_game_keeps_old_lockout_for_replay(self):
        state = self._state(ruleset_version=1)
        play_pattern(state, 0, single_pattern(c(RANK_2, "H")))
        pass_turn(state, 3)
        play_pattern(state, 2, single_pattern(c(RANK_3, "H")))
        assert state.passed_players == {3}
        pass_turn(state, 1)
        play_pattern(state, 0, single_pattern(c(RANK_6, "H")))
        assert state.turn_index == 2
        state.turn_index = 3
        with pytest.raises(IllegalPlayError, match="already passed"):
            play_pattern(state, 3, single_pattern(c(RANK_J, "H")))

    def test_passed_players_cleared_on_new_trick(self):
        """其他可行动玩家全过 → trick 结束，passed_players 清空，3 可在新 trick 再行动。"""
        state = make_initial_state(level=RANK_5, first_player=0, seed=42)
        state.wild_card = None
        state.hands[0] = [c(RANK_2, "H"), c(RANK_6, "H")]
        state.hands[1] = [c(RANK_7, "H")]
        state.hands[2] = [c(RANK_3, "H")]
        state.hands[3] = [c(RANK_J, "H")]

        play_pattern(state, 0, single_pattern(c(RANK_2, "H")))
        pass_turn(state, 3)
        pass_turn(state, 2)
        pass_turn(state, 1)  # 3, 2, 1 都过 → trick ends
        assert state.table == []
        assert state.passed_players == set()
        # 0 重新领出 → 3 重新能动
        play_pattern(state, 0, single_pattern(c(RANK_6, "H")))
        play_pattern(state, 3, single_pattern(c(RANK_J, "H")))  # 不抛异常
        assert state.table[-1].rank == RANK_J
